var REK = "6NitGRUTASKAAM1kxXLJ1YSzLokPtx8XGCHj8_VV",
    isVarLoginUser = (
        /* 
         * Used for Anonymous User.
         */
        //remove readonly from Student login/register/forgot password form input
        $(window).load(function() {
            "undefined" != typeof runAutoLoadJs && $.isFunction(runAutoLoadJs) && runAutoLoadJs(), void 0 !== jsVars.FULL_URL && ("undefined" == typeof prepareAjaxRequest && ($.getScript(jsVars.FULL_URL + "/js/lib/cryptojs.min.js"), $.getScript(jsVars.FULL_URL + "/js/lib/json.js")), "undefined" == typeof send_ajax_request) && $.getScript(jsVars.FULL_URL + "/js/ajax_request.js")
        }), $(document).ready(function() {
            //    console.log('autosave:'+jsVars.widgetAutoSave);
            $(".msg_success").length && $(".msg_success").show().delay(1e4).fadeOut(), $('[data-toggle="popover"]').length && (968 < document.documentElement.clientWidth ? $('[data-toggle="popover"]').popover({
                    placement: "left"
                }) : $('[data-toggle="popover"]').popover({
                    placement: "top"
                })), void 0 !== jsVars.enable_ilearn && 1 == jsVars.enable_ilearn && ($("form#registerForm #registerBtn").length && $("form#registerForm #registerBtn").attr("disabled", "disabled"), $("#Name").length && $("#Name").parents(".reg_name_div").hide(), $("#Mobile").length && $("#Mobile").parents(".merge_field_div").hide(), $("#fetchProfileFromILearnLink").show()), $(".sumo-select").length && $(".sumo-select").each(function() {
                    $(this).SumoSelect({
                        search: !0,
                        placeholder: $(this).data("placeholder"),
                        captionFormatAllSelected: "All Selected.",
                        searchText: $(this).data("placeholder"),
                        floatWidth: 200,
                        triggerChangeCombined: !0,
                        forceCustomRendering: !0
                    }), $(this).data("prev", $(this).val()), void 0 !== $(this).data("limit") && 0 < parseInt($(this).data("limit")) && $(this).on("change", function(e) {
                        var r, t;
                        null != $(this).val() && $(this).val().length > parseInt($(this).data("limit")) ? (alert("Max " + parseInt($(this).data("limit")) + " selections allowed!"), r = $(this), t = $(this).data("prev"), r[0].sumo.unSelectAll(), $.each(t, function(e, t) {
                            r[0].sumo.selectItem(r.find('option[value="' + t + '"]').index())
                        }), last_valid_selection = t) : null != $(this).val() && $(this).data("prev", $(this).val())
                    })
                }),
                //hide image coming in SRM
                $("img[src*='//bat.bing.com/action/0']").css("display", "none"),
                //only for desktop
                //    if(typeof jsVars.isMobileDevice == 'undefined'){
                //        //Student login form
                //        $('#loginForm input[type=\'email\'],#loginForm input[type=\'password\']').attr('readonly','readonly');
                //        $(document).on('focus','#loginForm input[type=\'email\'],#loginForm input[type=\'password\']',function(){
                //            $(this).removeAttr('readonly');
                //        });
                //        //Student register form
                //        $('#registerForm input[type=\'email\'],#registerForm input[type=\'password\'],#registerForm input[type=\'mobile\']').attr('readonly','readonly');
                //        $(document).on('focus','#registerForm input[type=\'email\'],#registerForm input[type=\'password\'],#registerForm input[type=\'mobile\']',function(){
                //            $(this).removeAttr('readonly');
                //        });
                //        //Student forgot password form
                //        $('#forgotForm input[type=\'email\']').attr('readonly','readonly');
                //        $(document).on('focus','#forgotForm input[type=\'email\']',function(){
                //            $(this).removeAttr('readonly');
                //        });
                //    }
                //refresh page if success pop up is closed
                $(document).on("click", "#SuccessPopupArea button.npf-close,#SuccessPopupArea  a.npf-close", function(e) {
                    e.preventDefault(),
                        //setTimeout(function(){ window.location.href=window.location.href; }, 10000);
                        window.location.href = window.location.href
                }),
                //Career Utsav Area of Interest
                $(document).on("change", "input[name='career_utsav_id[]']", function() {
                    getAreaOfInterestForList()
                }),
                //add sumo class on seminar/mock preference select
                0 < $("select#SeminarPreferenceId").length && $("select#SeminarPreferenceId").SumoSelect({
                    placeholder: "Seminar Preference Name",
                    search: !0,
                    searchText: "Seminar Preference Name",
                    captionFormatAllSelected: "All Selected.",
                    triggerChangeCombined: !0
                }), 0 < $("select#MockPreferenceId").length && $("select#MockPreferenceId").SumoSelect({
                    placeholder: "Mock Preference Name",
                    search: !0,
                    searchText: "Mock Preference Name",
                    captionFormatAllSelected: "All Selected.",
                    triggerChangeCombined: !0
                }), $("#Password").keyup(function() {
                    validateUsersPassword("Password")
                }), $("#Password").focus(function() {
                    validateUsersPassword("Password")
                }), $("#forgot-new-password").keyup(function() {
                    validateUsersPassword("forgot-new-password")
                }), $("#forgot-new-password").focus(function() {
                    validateUsersPassword("forgot-new-password")
                }), loadCustomDateTime(),
                //restrict special character for input
                0 < $("#Email,#email").length && $("#Email,#email").keyup(function() {
                    var e = $(this).val();
                    (re = /[`~!#$%^&*()|+\=?;:'",<>\{\}\[\]\\\/]/gi).test(e) && (e = e.replace(/[`~!#$%^&*()|+\=?;:'",<>\{\}\[\]\\\/]/gi, ""), $(this).val(e))
                })
        }), "verify" == jsVars.VerifyStudent && (
            //console.log(jsVars);
            $("#VerifyLink").trigger("click"), delete jsVars.VerifyStudent), "verify" == jsVars.onlyCrmEnableConfirmation && (
            //console.log(Email Verified Successfully.);
            //$("div#ConfirmationMsgPopupArea").modal('show');
            $("div#ConfirmationMsgPopupArea").modal().css("display", "block"), delete jsVars.onlyCrmEnableConfirmation), void 0 !== jsVars.SocialError && ($("#RegisterSocialLink").trigger("click"), delete jsVars.SocialError), !1);
//Error Message Behaviour Changes for Full Banner Layout
function changesOfFullBannerLayout(e, t) {
    if (void 0 !== jsVars.FullBannerLayoutEnabled || void 0 !== jsVars.isCustomTheme)
        //        $('#'+Form).each()
        //code for register form
        for (var r in t) "" == $("#" + e + " #" + r).val() && (t[r] = "");
    return t
}
//Validate Student Register Form Data
function checkStudentRegisterValidation() {
    $("span.help-block").text("");
    var e = $("form#registerForm input[name='_csrfToken']").val();
    $.ajax({
        url: jsVars.RegisterValidationCheck,
        type: "post",
        data: $("form#registerForm").serialize(),
        dataType: "json",
        headers: {
            "X-CSRF-Token": e
        },
        beforeSend: function() {
            $("#register-now div.loader-block").show(), $("#register-page div.loader-block").show()
        },
        complete: function() {
            $("#register-now div.loader-block").hide(), $("#register-page div.loader-block").hide()
        },
        success: function(e) {
            if (e.redirect) location = e.redirect;
            else if (e.error) {
                if (e.error.msg) alertPopup(e.error.msg, "error");
                else if (e.error.list)
                    if (e.error.list.missing) alertPopup(e.error.list.missing, "error");
                    else
                        for (var t in e.error.list = changesOfFullBannerLayout("registerForm", e.error.list), e.error.list) {
                            var r;
                            r = ("CareerUtsavId" == t ? $("form#registerForm input[name='career_utsav_id[]']") : $("form#registerForm #" + t)).parents("div.form-group"), $(r).addClass("has-error"), $(r).find("span.help-block").html(e.error.list[t]), "Captcha" == t && (void 0 !== e.error.list.captchField ? $("#" + e.error.list.captchField) : $("#CaptchaRefreshBtn")).trigger("click")
                        }
            } else 200 == e.success && (e.AnalyticsCodeSlug && hitC360AnalyticsCode(e.AnalyticsCodeSlug, e.AnalyticsCodeAction, e.GAName, e.NPFAnalyticsCodeAction),
                //commented on 1/04/2017, Case: trigger on succcess,Change By: Surya Singh    
                //                if((typeof jsVars.trigger_collegedunia != 'undefined') && json['register_continue_collegedunia_pixel']){
                //                    append_html=json['register_continue_collegedunia_pixel'];
                //                }
                //console.log(append_html);
                $("#college-instruction").append(""), $("#hit_popup_instructions").trigger("click"))
        },
        error: function(e, t, r) {
            console.log(r + "\r\n" + e.statusText + "\r\n" + e.responseText), $("#register-now div.loader-block,#register-page div.loader-block").hide()
        }
    })
}

function agreeConditions() {
    var e = $("#InstructionAgree").parents("div.agree-group");
    return $(e).removeClass("has-error"), $(e).find("span.help-block").text(""), $("#InstructionAgree").is(":checked") ? ($("#InstructionAgree").trigger("click"), $("#college-instruction").modal("hide"), $("#RegisterPopupOpenBtn").trigger("click"), !0) : ($(e).addClass("has-error"), $(e).find("span.help-block").text("Please select the checkbox to continue."), !1)
}
//Registration form submit function
$(document).on("click", "#loginBtn", function() {
        $("form#loginForm span.help-block").text("");
        var e, t = $("form#loginForm input[name='_csrfToken']").val();
        1 != isVarLoginUser && (isVarLoginUser = !0, e = $("form#loginForm").serializeArray(), send_ajax_request(jsVars.LoginUrl, "post", e, function(e) {
            if (isVarLoginUser = !1, e.redirect) location = e.redirect;
            else if (e.error) {
                if (e.error.msg) alertPopup(e.error.msg, "error");
                else if (e.error.list)
                    for (var t in e.error.list = changesOfFullBannerLayout("loginForm", e.error.list), e.error.list) {
                        //if(json['error']['list'][i])
                        var r = $("form#loginForm #" + ("Password" == t ? "loginPassword" : "Email" == t ? "loginEmail" : t)).parents("div.form-group");
                        //alert(parentDiv.html());
                        $(r).addClass("has-error"), $(r).find("span.help-block").text(""), $(r).find("span.help-block").append(e.error.list[t])
                    }
            } else 200 == e.success && (
                //Push data in Datalayer for LPU
                pushLoginDatainDatalayer(), location = e.location)
        }, function() {
            $("#already-registered div.loader-block,#register-now div.loader-block").hide()
        }, function() {
            $("#already-registered div.loader-block,#register-now div.loader-block").show()
        }, function(e, t, r) {
            console.log(r + "\r\n" + e.statusText + "\r\n" + e.responseText), $("#already-registered div.loader-block,#register-now div.loader-block").hide()
        }, {
            "X-CSRF-Token": t
        }))
    }), "undefined" != jsVars.ShowInstructionPopup &&
    //on click instruction continue button
    $(document).on("click", "#ContinueWithAgree, #ContinueAndRegister", function() {
        agreeConditions() && registerUser()
    }), $(document).on("click", "#registerBtn", function() {
        registerUser()
    });
var CodeSlug, CodeAction, NPFCodeAction, GAName, isVarRegisterUser = !1,
    userRegistered = !1;

function registerUser() {
    $("form#registerForm #registerBtn").attr("disabled", "disabled"), $("form#registerForm #registerBtn").css("pointer-events", "none"),
        // console.log('registerUser',registerUser);
        $("span.help-block").text("");
    var e = $("form#registerForm input[name='_csrfToken']").val(),
        h = $("form#registerForm input[name='widgetId']").val();
    if (1 != isVarRegisterUser) {
        if (runConditionalJs()) return !1;
        var t = new FormData($("form#registerForm")[0]);
        void 0 !== jsVars.dynamicRequest && 1 == jsVars.dynamicRequest && t.append("dynamicRequest", jsVars.dynamicRequest),
            //    console.log(new FormData($('form#registerForm')[0])); return;
            isVarRegisterUser = !0, //If ajax hit is called then set this variable to true
            $.ajax({
                url: jsVars.RegisterUrl,
                xhrFields: {
                    withCredentials: !0
                },
                type: "post",
                data: t,
                dataType: "json",
                processData: !1,
                contentType: !1,
                async: !1,
                headers: {
                    "X-CSRF-Token": e,
                    token: jsVars.requestCsrf
                },
                beforeSend: function() {
                    $("#register-now div.loader-block").show(), $("#register-page div.loader-block").show(),
                        //Disable the register Button
                        $("form#registerForm #registerBtn").attr("disabled", "disabled"), $("form#registerForm #registerBtn").css("pointer-events", "none")
                },
                complete: function() {
                    $("#register-now div.loader-block").hide(), $("#register-page div.loader-block").hide()
                },
                success: function(e) {
                    if (
                        //console.log(json);
                        isVarRegisterUser = !1, e.redirect) location = e.redirect;
                    else if (e.error) {
                        if ("csrf" == e.error) alertPopup("Please refresh the page and try again.", "error");
                        else if (e.error.msg) alertPopup(e.error.msg, "error");
                        else if (e.error.list)
                            if (e.error.list.missing) alertPopup(e.error.list.missing, "error");
                            else {
                                e.error.list = changesOfFullBannerLayout("registerForm", e.error.list);
                                var t, r, o = '<div style="text-align:left">';
                                for (t in e.error.list) "captchField" != t && (void 0 !== jsVars.register_error && "popup" == jsVars.register_error ? o += e.error.list[t] + "<br>" : (r = ("CareerUtsavId" == t ? $("form#registerForm input[name='career_utsav_id[]']") : "Captcha" == t && void 0 !== e.error.list.captchField ? $("form#registerForm #" + e.error.list.captchField) : $("form#registerForm #" + t)).parents("div.form-group"), $(r).addClass("has-error"), $(r).find("span.help-block").html(e.error.list[t]), "Captcha" == t && (void 0 !== e.error.list.captchField ? $("#" + e.error.list.captchField + "Btn") : $("#CaptchaRefreshBtn")).trigger("click")));
                                1 != e.entry_flag && (
                                    //Remove disabled
                                    $("form#registerForm #registerBtn").removeAttr("disabled"), $("form#registerForm #registerBtn").css("pointer-events", "auto")), void 0 !== $("#opt_dataMobile") && "" == $("#opt_dataMobile").val() && $("#otpunverifiedMobile").show(), o += "</div>", void 0 !== jsVars.register_error && "popup" == jsVars.register_error && alertPopup(o, "error")
                            }
                        $("#ErrorPopupArea .modal-dialog").addClass("modal-sm"), $("#ErrorPopupArea #ErroralertTitle").css("font-size", "20px")
                    } else {
                        var a, i, s, n, l, d, c, g, p, u, m, f;
                        200 == e.success && (i = a = !1, s = "", void(n = 0) !== e.thankyou_type && 1 == parseInt(e.thankyou_type) && 0 == parseInt(e.thankyou_redirect_delay) ? (a = !0, s = e.thankyou_external_url) : 0 < parseInt(e.thankyou_redirect_delay) && (i = !(a = !1), s = e.thankyou_external_url, n = parseInt(e.thankyou_redirect_delay)), userRegistered = !0, l = $(document).find("#Mobile").val(), m = u = p = g = c = d = "", "lpuDataLayer" in e && e.lpuDataLayer && ("utm_source" in (f = e.lpuDataLayer) && f.utm_source && (d = f.utm_source), "utm_medium" in f && f.utm_medium && (c = f.utm_medium), "utm_name" in f && f.utm_name && (g = f.utm_name), "current_url" in f && f.current_url && (p = f.current_url), "widget_name" in f && f.widget_name && (u = f.widget_name), "host_name" in f) && f.host_name && (m = f.host_name), pushRegisterDatainDatalayer(l, d, c, g, p, u, m), "registrationDataLayerData" in e && e.registrationDataLayerData && registrationDataLayerData(e.registrationDataLayerData), "function" == typeof npfGtmTagCodeOnRegSuccess && npfGtmTagCodeOnRegSuccess(), e.AnalyticsCodeSlug && hitC360AnalyticsCode(e.AnalyticsCodeSlug, e.AnalyticsCodeAction, e.GAName, e.NPFAnalyticsCodeAction), e.location ? location = e.location : ($("form#registerForm #Agree").val("1"), $('form#registerForm [type="hidden"][name="Agree"]').val("0"), $("span.help-block").text(""), $("div.form-group").removeClass("has-error"), "false" != jsVars.auto_trigger && $(".npf-close").trigger("click"), f = "",
                            //Added on: 1/04/2017,Case: trigger on succcess,Change By: Surya Singh   
                            void 0 !== jsVars.trigger_collegedunia && e.register_continue_collegedunia_pixel && (f = e.register_continue_collegedunia_pixel), a ? 0 < s.length && (
                                // console.log('redirect_external_url:',redirect_external_url);
                                hitOnWidgetThanyou(e.passDataDecoded),
                                // console.log('Redirecting:',redirect_external_url);
                                // window.open(redirect_external_url, "_blank");
                                window.top.location.href = s) : void 0 !== e.msgPosition ? (void 0 === e.passDataDecoded && (e.passDataDecoded = []), hitOnWidgetThanyou(e.passDataDecoded), h != jsVars.lpu_sso_widgetId && "string" == typeof e.parentRedirectURL && "" !== e.parentRedirectURL ? window.parent.location = e.parentRedirectURL : ($("div.widget_thankyou_msg").hide(), "after_heading" == e.msgPosition ? ($("div.after_heading").html(e.msg), $("div.after_heading").fadeIn(), i && "" != s && setTimeout(function() {
                                window.top.location.href = s
                            }, parseInt(1e3 * n))) : "above_button" == e.msgPosition ? ($("div.above_button").html(e.msg), $("div.above_button").fadeIn(), i && "" != s && setTimeout(function() {
                                window.top.location.href = s
                            }, parseInt(1e3 * n))) : "new_page" == e.msgPosition ? window.location.href = "/thankyou?cid=" + (void 0 !== e.cid ? e.cid : "") + "&w=" + (void 0 !== e.passData ? e.passData : "") : ($("div.next_page").html(e.msg), $("div.widget_container").fadeOut(), $("div.next_page").fadeIn(), i && "" != s && setTimeout(function() {
                                window.top.location.href = s
                            }, parseInt(1e3 * n))))) : ($("#SuccessPopupArea .modal-title").html("Thank you for registration" + f), $("#SuccessPopupArea p#MsgBody").text(""), $("#SuccessPopupArea p#MsgBody").append(e.msg), $("#SuccessLink").trigger("click"), e.triggerDataLayer && hitOnRegisterSuccessPopup()),
                            //Added on: 16/04/2019 Case: For LPU SSO Data
                            h == jsVars.lpu_sso_widgetId && "string" == typeof e.parentRedirectURLNewTab && "" !== e.parentRedirectURLNewTab && window.open(e.parentRedirectURLNewTab, "_blank"), void 0 !== h ? setTimeout(function() {
                                $("form#registerForm #registerBtn").removeAttr("disabled"), $("form#registerForm #registerBtn").css("pointer-events", "auto")
                            }, 1e3 * (n + 5)) : ($("form#registerForm #registerBtn").removeAttr("disabled"), $("form#registerForm #registerBtn").css("pointer-events", "auto"))))
                    }
                },
                error: function(e, t, r) {
                    console.log(r + "\r\n" + e.statusText + "\r\n" + e.responseText), $("#register-now div.loader-block").hide(), isVarRegisterUser = !1
                }
            })
    }
}
//for mobile user registration
function redirectPageOnMobile() {
    void 0 !== jsVars.RedirectAfterAnalyticsCodeSlug && (location = jsVars.RedirectAfterAnalyticsCodeSlug)
}
//should be used for All Colleges
function hitC360AnalyticsCode(e, t, r, o) {
    "" !== e && dataLayer.push({
        event: "GAevent",
        eventCategory: "Register",
        eventAction: o,
        eventLabel: e
    })
}
//hit on Register Success Popup
function hitOnRegisterSuccessPopup() {
    //dataLayer.push({'popuptrigger': 'register_success_popup'});
    dataLayer.push({
        event: "registerpopup"
    })
}
//hit on Register Success Popup
function hitOnWidgetThanyou(e) {
    var t = {
            event: "widgetthankyou",
            transactionId: "",
            transactionTotal: 0,
            pInstanceDate: 0,
            oInstanceDate: 0,
            countryName: 0
        },
        r = (void 0 !== e.user_id && (t.transactionId = e.user_id), void 0 !== e.final_register_date && (t.pInstanceDate = e.final_register_date), void 0 !== e.other_instance_date && (t.oInstanceDate = e.other_instance_date), void 0 !== e.user_id && (t.transactionId = e.user_id), {
            name: "",
            sku: "",
            category: ""
        });
    void 0 !== e.name && (r.name = e.name), void 0 !== e.email && (r.name += "_" + e.email), void 0 !== e.mobile && (r.sku = e.mobile), void 0 !== e.coursename && (r.category = e.coursename), void 0 !== e.state && (r.category += "_" + e.state), void 0 !== e.city && (r.category += "_" + e.city), void 0 !== e.countryName && (t.countryName = e.countryName), t.transactionProducts = [r], "undefined" == typeof dataLayer && (window.dataLayer = window.dataLayer || []), dataLayer.push(t)
}
//Resend verification mail function on login
function sendVerificationEmail(e) {
    triggerVerficationMail({
        action: "mail",
        key: e
    })
}
//Resend mail Function
function resendMail(e) {
    var t = "";
    triggerVerficationMail({
        action: "mail",
        key: t = void 0 !== e ? e : t
    })
}
//function is used to send verification email
function triggerVerficationMail(e) {
    var t = !1,
        r = ( //csrf token constant
            0 < $("form#loginForm").length ? r = $("form#loginForm input[name='_csrfToken']").val() : 0 < $("form#registerForm").length ? r = $("form#registerForm input[name='_csrfToken']").val() : 0 < $("form#forgotForm").length ? r = $("form#forgotForm input[name='_csrfToken']").val() : 0 < $("form#ProfileForm").length ? r = $("form#ProfileForm input[name='_csrfToken']").val() : 0 < $("form#chnageEmailId").length ? (r = $("form#chnageEmailId input[name='_csrfToken']").val(), t = !0) : void 0 !== jsVars._csrfToken && (r = jsVars._csrfToken), {
                "X-CSRF-Token": r
            });
    send_ajax_request(jsVars.ResendMailUrl, "post", e, function(e) {
        e.redirect ? location = e.redirect : e.error ? e.error.msg && alertPopup(e.error.msg, "error") : 200 == e.success && (void 0 !== jsVars.auto_trigger && "false" != jsVars.auto_trigger ? $(".npf-close").trigger("click") : //close all popups
            $("div#register-now").modal("hide"), void 0 !== t && 1 == t ? $("#SuccessPopupArea .modal-title").text("Login Credentials Sent.") : void 0 !== e.messageType && "" !== $.trim(e.messageType) ? "error" == e.messageType ? $("#SuccessPopupArea .modal-title").text("Error") : "verification" == e.messageType ? $("#SuccessPopupArea .modal-title").text("Verification Credentials Sent") : "credential" == e.messageType && $("#SuccessPopupArea .modal-title").text("Login Credentials Sent") : $("#SuccessPopupArea .modal-title").text("Thank you for registration"), $("#SuccessPopupArea p#MsgBody").text(""), $("#SuccessPopupArea p#MsgBody").append(e.msg), $("#SuccessLink").trigger("click"))
    }, function() {
        $("div.loader-block").hide()
    }, function() {
        $("div.loader-block").show()
    }, function(e, t, r) {
        console.log(r + "\r\n" + e.statusText + "\r\n" + e.responseText), $("div.loader-block").hide()
    }, r)
}
//Forgot password form submit function
void 0 !== jsVars.AnalyticsCodeSlug && (CodeSlug = jsVars.AnalyticsCodeSlug, CodeAction = jsVars.AnalyticsCodeAction, NPFCodeAction = jsVars.NPFAnalyticsCodeAction,
    //alert(CodeSlug);
    hitC360AnalyticsCode(CodeSlug, CodeAction, GAName = jsVars.GAName, NPFCodeAction), redirectPageOnMobile());
var isVarForgotUser = !1,
    preCurrentRequest = ($(document).on("click", "#forgotBtn", function() {
        $("span.help-block").text("");
        var e, t = $("form#forgotForm input[name='_csrfToken']").val();
        1 != isVarForgotUser && (isVarForgotUser = !0, e = {
            Email: $("form#forgotForm input[name='Email']").val()
        }, send_ajax_request(jsVars.ForgotPasswordUrl, "post", e, function(e) {
            if (isVarForgotUser = !1, e.redirect) location = e.redirect;
            else if (e.error) {
                if (e.error.msg) alertPopup(e.error.msg, "error");
                else if (e.error.list)
                    for (var t in e.error.list = changesOfFullBannerLayout("forgotForm", e.error.list), e.error.list) {
                        var r = t,
                            r = ("Email" == t && (r = "forgetEmail"), $("form#forgotForm #" + r).parents("div.form-group"));
                        $(r).addClass("has-error"), $(r).find("span.help-block").text(""), $(r).find("span.help-block").append(e.error.list[t])
                    }
            } else 200 == e.success && (e.location ? location = e.location : ($("#ForgotOtpTabContainer").show(), 0 < $("#ForgotTabContainer").length && $("#ForgotTabContainer").hide(), 0 < $("#forgot_pwd_form_without_popup").length && $("#forgot_pwd_form_without_popup").hide(), $("#forgotOtpBtn").hide(), $("#hashValue").val(e.hash),
                //                    $("span.help-block").text('');
                //                    $("div.form-group").removeClass('has-error');
                //                    $("#forget-password .npf-close").trigger('click');
                //                    $("#SuccessPopupArea .modal-title").text("Reset Password Link Sent");
                //                    $("#SuccessPopupArea p#MsgBody").text(json['msg']);
                //                    $("#SuccessLink").trigger('click');
                countdownStartFOrget()))
        }, function() {
            $("#forget-password div.loader-block,#register-now div.loader-block").hide(), $(this).attr("disabled", !1)
        }, function() {
            $("#forget-password div.loader-block,#register-now div.loader-block").show(), $(this).attr("disabled", !0)
        }, function(e, t, r) {
            console.log(r + "\r\n" + e.statusText + "\r\n" + e.responseText), $("#forget-password div.loader-block,#register-now div.loader-block").hide()
        }, {
            "X-CSRF-Token": t
        }))
    }), jQuery(function() {
        $("form#registerForm #Agree").val("1"), $('form#registerForm [type="hidden"][name="Agree"]').val("0"), $("form#registerForm #Agree").click(function() {
            $(this).is(":checked") ? ($("form#registerForm #Agree").val("1"), $('form#registerForm [type="hidden"][name="Agree"]').val("0"), $(this).attr("checked", "checked"), $(this).attr("checked", !0)) : $(this).removeAttr("checked")
        })
    }), null);

function validateMobileLength(e) {
    var t = !1,
        r = "+91";
    //check with country dial code
    if (0 < $("form#registerForm #country_dial_codeMobile").length && (t = !0, r = $("form#registerForm #country_dial_codeMobile").val()), 1 == t) {
        //check for india
        if ("+91" == r && 10 == e.length) return !0;
        if ("+91" != r && 6 <= e.length && e.length <= 16) return !0
    } else if (10 == e.length) return !0;
    return !1
}

function populatePredefinedValues(e, t, o, a) {
    var r = 0,
        i = (void 0 !== jsVars.college_id && null != jsVars.college_id && (r = jsVars.college_id), '<option value="">' + t + "</option>");
    $("#" + a).html(i), void 0 !== e && "" !== e && null !== e && $.ajax({
        url: jsVars.getTaxonomyChildListLink,
        type: "post",
        data: {
            parentKey: e,
            college_id: r
        },
        dataType: "html",
        headers: {
            "X-CSRF-Token": jsVars.csrfToken
        },
        beforeSend: function() {
            $("#register-now div.loader-block,#register-page div.loader-block").show()
        },
        complete: function() {
            $("#register-now div.loader-block,#register-page div.loader-block").hide()
        },
        success: function(e) {
            var r, e = $.parseJSON(e);
            1 == e.status ? "object" == typeof e.data && (r = '<option value="">' + t + "</option>", $.each(e.data, function(e, t) {
                r += e == o ? '<option value="' + e + '" selected >' + t + "</option>" : '<option value="' + e + '">' + t + "</option>"
            }), $("#" + a).html(r)) : "session" === e.message ? location = jsVars.FULL_URL : alertPopup(e.message, "error")
        },
        error: function(e, t, r) {
            alert(r + "\r\n" + e.statusText + "\r\n" + e.responseText)
        }
    })
}

function GetChildByMachineKey(e, a) {
    var i, s, n, t;
    void 0 !== a && $("#" + a).length && ($("#" + a + ' option[value!=""]').remove(), void(i = 0) !== jsVars.dependentDropdownFieldList && $(jsVars.dependentDropdownFieldList).each(function(e, t) {
            //if getLastValue > 0 then return from here
            if (0 < i) return !1;
            var o = 0;
            $.each(t, function(e, t) {
                var r;
                //if field match then increase the counter and store the increament value into getLastValue variable
                t == a && (i = ++o), 0 < o && $("#" + t).length && (r = '<option value="">' + $("#" + t).data("label") + "</option>", $("#" + t).hasClass("sumo-select") ? ($("#" + t).find('option[value!=""]').remove(), $("#" + t + ".sumo-select")[0].sumo.reload()) : ($("#" + t).html(r), $("#" + t + "_chosen").length && ($(".chosen-select").chosen(), $(".chosen-select-deselect").chosen({
                    allow_single_deselect: !0
                }), $(".chosen-select").trigger("chosen:updated"))), $("#" + t).hasClass("selectpicker")) && $(".selectpicker").selectpicker("refresh")
            })
        }), n = s = !1, $("#" + a).find('option[value!=""]').remove(), "StateId" == a && (0 < $("#DistrictId").length && (0 < $("#DistrictId.chosen-select").length && (s = !0), $("#DistrictId").find('option[value!=""]').remove(), 0 < $("#DistrictId.sumo-select").length && $("#DistrictId.sumo-select")[0].sumo.reload(), 0 < $("#DistrictId.selectpicker").length) && (n = !0), 0 < $("#CityId").length) && (0 < $("#CityId.chosen-select").length && (s = !0), $("#CityId").find('option[value!=""]').remove(), 0 < $("#CityId.sumo-select").length && $("#CityId.sumo-select")[0].sumo.reload(), 0 < $("#CityId.selectpicker").length) && (n = !0), "DistrictId" == a && 0 < $("#CityId").length && (0 < $("#CityId.chosen-select").length && (s = !0), $("#CityId").find('option[value!=""]').remove(), 0 < $("#CityId.sumo-select").length && $("#CityId.sumo-select")[0].sumo.reload(), 0 < $("#CityId.selectpicker").length) && (n = !0),
        //prevent chosen update for mobile profile page
        !s && 0 < $("#" + a + ".chosen-select").length && (s = !0), !n && 0 < $("#" + a + ".selectpicker").length && (n = !0), s && 0 < $(".chosen-select").length && ($(".chosen-select").chosen(), $(".chosen-select-deselect").chosen({
            allow_single_deselect: !0
        }), $(".chosen-select").trigger("chosen:updated")), n && 0 < $(".selectpicker").length && $(".selectpicker").selectpicker("refresh"), 0 < $(".sumo-select").length && 0 < $("#" + a + ".sumo-select").length && $("#" + a + ".sumo-select")[0].sumo.reload(), void 0 !== e) && "" !== e && (t = "", void 0 !== $("#" + a).attr("name") && "" !== $("#" + a).attr("name") && (t = $("#" + a).attr("name")), e = {
        key: e,
        ContainerId: a,
        fieldName: t
    }, $("#collegeId").length && (e.college_id = $("#collegeId").val()), "DistrictId" == a && (e.includeDistricts = "1"), void 0 !== jsVars.widgetId && "" != jsVars.widgetId && (e.widgetId = jsVars.widgetId), e.cf = "lm-user-profile", t = jsVars.GetTaxonomyLink.replace("get-children-list", "common/GetChildByMachineKeyForRegistrationNew"), send_ajax_request(t, "post", e, function(e) {
        if (e.redirect && (location = e.redirect), e.error && "csrf" !== e.error) alertPopup(e.error, "error");
        else if (e.error && "csrf" === e.error) alertPopup("Please refresh the page and try again.", "error");
        else if (e.success) {
            var t, r = "";
            if (e.CategoryOptions) r = e.CategoryOptions;
            else
                for (var o in e.list) r += '<option value="' + o + '">' + e.list[o] + "</option>";
            void 0 !== $("#" + a).data("label") ? (t = '<option value="">' + $("#" + a).data("label") + "</option>", $("#" + a).html(t + r)) : $("#" + a).append(r), "StateId" == a && ($("#StateId").attr("disabled", "false"), $("#StateId").removeAttr("disabled"), 0 < $("#DistrictId").length && (0 < $("#DistrictId.chosen-select").length && (s = !0), $("#DistrictId").find('option[value!=""]').remove(), 0 < $("#DistrictId.sumo-select").length && $("#DistrictId.sumo-select")[0].sumo.reload(), 0 < $("#DistrictId.selectpicker").length) && (n = !0), 0 < $("#CityId").length) && (0 < $("#CityId.chosen-select").length && (s = !0), $("#CityId").find('option[value!=""]').remove(), 0 < $("#CityId.sumo-select").length && $("#CityId.sumo-select")[0].sumo.reload(), 0 < $("#CityId.selectpicker").length) && (n = !0), "DistrictId" == a && ($("#DistrictId").attr("disabled", "false"), $("#DistrictId").removeAttr("disabled"), 0 < $("#CityId").length) && (0 < $("#CityId.chosen-select").length && (s = !0), $("#CityId").find('option[value!=""]').remove(), 0 < $("#CityId.sumo-select").length && $("#CityId.sumo-select")[0].sumo.reload(), 0 < $("#CityId.selectpicker").length) && (n = !0), "CityId" == a && 0 < $("#CityId").length && (0 < $("#CityId.chosen-select").length && (s = !0), 0 < $("#CityId.selectpicker").length && (n = !0), $("#CityId").attr("disabled", "false"), $("#CityId").removeAttr("disabled")), s && 0 < $(".chosen-select").length && ($(".chosen-select").chosen(), $(".chosen-select-deselect").chosen({
                allow_single_deselect: !0
            }), $(".chosen-select").trigger("chosen:updated")), 0 < $("#" + a + ".sumo-select").length && $("#" + a + ".sumo-select")[0].sumo.reload(), n && 0 < $(".selectpicker").length && $(".selectpicker").selectpicker("refresh")
        }
    }, function() {
        $("#register-now div.loader-block,#register-page div.loader-block").hide()
    }, function() {
        $("#register-now div.loader-block,#register-page div.loader-block").show()
    }, function(e, t, r) {
        console.log(r + "\r\n" + e.statusText + "\r\n" + e.responseText)
    }))
}
//update select input on registartion/profile page
function updateSelectInput(e, t, r) {
    var o = "Choose",
        a = '<option value=""> ' + (o = void 0 !== jsVars.CollegeId && 139 == jsVars.CollegeId ? "Domicile" : o) + " " + t + "</option>";
    "State" == t && 0 < $("#CityId").length && $("#CityId").html('<option value="">' + o + " City</option>"), "City" == t && 0 < $("#CityId").length && ($("#CityId").attr("disabled", "false"), $("#CityId").removeAttr("disabled")), void 0 !== r && (a += r), $("#" + e).html(a), 0 < $(".chosen-select").length && ($(".chosen-select").chosen(), $(".chosen-select-deselect").chosen({
        allow_single_deselect: !0
    }), $(".chosen-select").trigger("chosen:updated"))
}
//For Dropdown Menu Country Dial Code
// this function is used when there is mobile dial country code is selected in form applicant
function filterDialCode(e) {
    void 0 !== e && null != e && "undefined" != e || (e = "");
    var t = (t = $("#filter_dial_code" + e).val()).toLowerCase();
    $("#ul_dial_code" + e + " > li").each(function() {
        -1 < $(this).text().toLowerCase().search(t) ?
            //            $(this).text(src_str);
            $(this).show() : $(this).hide()
    })
}
/*Check Email Validation*/
function isValidEmailDNS(e, t, r) {
    var o;
    "" != $.trim(e) && ($(t).html(""), null == (o = jsVars.csrfToken) && 0 < $("form#registerForm").length ? o = $("form#registerForm input[name='_csrfToken']").val() : null == o && 0 < $("form#loginForm").length && (o = $("form#loginForm input[name='_csrfToken']").val()), e = {
        email: $.trim(e),
        marketPage: void 0 !== jsVars.marketingPage && 1 == jsVars.marketingPage,
        college_id: void 0 !== jsVars.college_id ? jsVars.college_id : 0
    }, send_ajax_request((void 0 !== jsVars.marketingPage && 1 == jsVars.marketingPage ? jsVars.FULL_URL : "") + "/common/check-email", "post", e, function(e) {
        void 0 !== e.message && "" != e.message && ($(t).show(), (null != r && "" !== r && -1 === e.message.indexOf("you mean") ? $(t).html(r) : $(t).html(e.message)).css({
            color: "#f44336",
            display: "block"
        })), $("#registerBtn").removeAttr("disabled")
    }, null, null, function(e, t, r) {
        console.log(r + "\r\n" + e.statusText + "\r\n" + e.responseText)
    }, {
        "X-CSRF-TOKEN": o
    }))
}
$(document).ready(function(e) {
    $(document).on("click", ".bs-dropdown-to-select-group .dropdown-menu-list li", function(e) {
        var e = $(e.currentTarget),
            t = $(this).data("fieldid");
        return e.closest(".bs-dropdown-to-select-group").find('[data-bind="bs-drp-sel-value"]').val(e.attr("data-value")).end().children(".dropdown-toggle").dropdown("toggle"), e.closest(".bs-dropdown-to-select-group").find('[data-bind="bs-drp-sel-masterid-value"]').val(e.attr("data-masterid")).end().children(".dropdown-toggle").dropdown("toggle"), e.closest(".bs-dropdown-to-select-group").find('[data-bind="bs-drp-sel-label"]').text(e.attr("data-value")),
            //When Select the option from dropdown then close the open dropdown
            e.closest(".bs-dropdown-to-select-group").removeClass("open"),
            //Bydefault remove the value when value will change
            $("#" + t).val(""),
            //For change Maxlength value of Mobile Input Box as per selection of country code
            e.attr("data-value") == jsVars.defaultCountryCode ? $("#" + t).attr("maxlength", jsVars.maxMobileLength) : $("#" + t).attr("maxlength", jsVars.internationalMaxMobileLength), !1
    }), jQuery(".filter_dial_code").on("click", function(e) {
        e.stopPropagation()
    })
});
var fetchProfileFromILearnRequestInProgress = !1;

function fetchProfileFromILearn(e, t, s) {
    t = $("#" + t).val();
    "" != $.trim(t) && 0 == fetchProfileFromILearnRequestInProgress && (fetchProfileFromILearnRequestInProgress = !0, $(s).html(""),
        //Call this ajax function
        $.ajax({
            url: "/common/fetch-profile-from-i-learn",
            type: "post",
            dataType: "json",
            async: !0,
            data: "email=" + $.trim(t) + "&college_id=" + e,
            headers: {
                "X-CSRF-TOKEN": jsVars.csrfToken
            },
            beforeSend: function() {
                $("#fetchProfileFromILearnLink").find("a").html("Please wait..")
            },
            complete: function() {
                $("#fetchProfileFromILearnLink").find("a").html("Validate"), fetchProfileFromILearnRequestInProgress = !1
            },
            success: function(e) {
                var t, r, o, a, i;
                void 0 !== e.status && 1 == e.status ? ($("form#registerForm #registerBtn").length && $("form#registerForm #registerBtn").removeAttr("disabled"), $("#fetchProfileFromILearnLink").hide(), t = e.data, $("#Name").length && ($("#Name").parents(".reg_name_div").show(), $("#Name").prop("readonly", !0), r = "", "first_name" in t) && void 0 !== t.first_name && "" !== t.first_name && (r = t.first_name, "last_name" in t && void 0 !== t.last_name && "" !== t.last_name && (r = r + " " + t.last_name), $("#Name").val(r)), r = "", $("#FieldCountryOfResidence").length && ($("#FieldCountryOfResidence").prop("readonly", !0), "country_of_residence" in t) && void 0 !== t.country_of_residence && "" !== t.country_of_residence && (r = t.country_of_residence, $("#FieldCountryOfResidence").val(r)), $("#Mobile").length && ($("#Mobile").parents(".merge_field_div").show(), $("#Mobile").prop("readonly", !0), "mobile_no" in t && void 0 !== t.mobile_no && "" !== t.mobile_no && (o = t.mobile_no, a = $.parseJSON(jsVars.iso_country_list), -1 !== (o = (i = "") !== r && r in a && void 0 !== a[r] && (a[r] = String(a[r]), i = "+" + a[r], -1 !== (o = -1 !== o.indexOf(i) ? $.trim(o.substr(i.length)) : o).indexOf(a[r])) ? $.trim(o.substr(a[r].length)) : o).indexOf(" ") && -1 !== o.indexOf("+") && ("" == i && (i = $.trim(o.substr(0, o.indexOf(" ")))), o = o.substr(o.indexOf(" ") + 1)), o = (o = -1 !== o.indexOf("+") ? o.substr(o.indexOf("+") + 1) : o).split(" ").join(""), $("#ul_dial_codeMobile").length && $("#ul_dial_codeMobile").find("li").each(function() {
                    $(this).data("value") == i && ($(this).trigger("click"), $(this).parents("div.bs-dropdown-to-select-group").removeClass("open"), $("button.bs-dropdown-to-select").attr("aria-expanded", "false"), $("button.bs-dropdown-to-select").prop("disabled", !0))
                }), $("#Mobile").val(o)), $("#Mobile").prop("readonly", !0)), $("#FieldLearningCenter").length && ($("#FieldLearningCenter").prop("readonly", !0), "learning_center" in t) && void 0 !== t.learning_center && "" !== t.learning_center && $("#FieldLearningCenter").val(t.learning_center), $("#FieldLearningCenterName").length && ($("#FieldLearningCenterName").prop("readonly", !0), "learning_center_name" in t) && void 0 !== t.learning_center_name && "" !== t.learning_center_name && $("#FieldLearningCenterName").val(t.learning_center_name), $("#Email").prop("readonly", !0)) : void 0 !== e.message && "" !== e.message ? ($(s).show(), $(s).html(e.message).css({
                    color: "#f44336",
                    display: "block"
                })) : ($(s).show(), $(s).html("Somethig went wrong. Please refresh the page and try again."))
            },
            error: function(e, t, r) {
                console.log(r + "\r\n" + e.statusText + "\r\n" + e.responseText)
            }
        }))
}
/**
 * if country select other then india then hide city and state
 * @returns {undefined}
 */
/*
function showHideStateCity(isIndiaDD,isIndiaCode){
     if(isIndiaCode == true && isIndiaDD == true){
        $('div.StateId, div.CityId').show();
    }else{
        $('#StateId').val('');
        $('#CityId').val('');
        $('div.StateId, div.CityId').hide();
    }
} */
function showCharactersLeft(e, t, r) {
    e = $("#" + e).val().length, r = parseInt(r);
    $("#" + t).html("Total characters count: " + e + "/" + r)
}

function changeYear(e, t, r, o, a, i, s) {
    if ($("#" + e).val(""), 0 < $("#" + e + "_month").length) {
        if ($("#" + e + "_month").html('<option value="">' + i + "</option>"), 0 < $("#" + e + "_day").length && $("#" + e + "_day").html('<option value="">' + s + "</option>"), "" !== $("#" + e + "_year").val()) {
            for (var s = 1, n = 12, l = (parseInt($("#" + e + "_year").val()) <= parseInt(r) && (s = parseInt(t)), parseInt($("#" + e + "_year").val()) >= parseInt(a) && (n = parseInt(o)), '<option value="">' + i + "</option>"), d = s; d <= n; d++) {
                var c = d < 10 ? "0" + String(d) : String(d);
                l += '<option value="' + c + '">' + c + "</option>"
            }
            $("#" + e + "_month").html(l)
        }
    } else "" !== $("#" + e + "_year").val() && $("#" + e).val("01-01-" + $("#" + e + "_year").val())
}

function changeMonth(e, t, r, o, a, i, s, n) {
    if ($("#" + e).val(""), 0 < $("#" + e + "_day").length) {
        if ($("#" + e + "_day").html('<option value="">' + n + "</option>"), "" !== $("#" + e + "_year").val() && "" !== $("#" + e + "_month").val()) {
            for (var l = parseInt($("#" + e + "_year").val()), d = parseInt($("#" + e + "_month").val()), c = 1, g = 31, p = (-1 < [4, 6, 9, 11].indexOf(d) && (g = 30), 2 === d && (g = l % 4 == 0 ? 29 : 28), l <= parseInt(o) ? d <= parseInt(r) && (c = parseInt(t)) : l >= parseInt(s) && d >= parseInt(i) && (g = parseInt(a)), '<option value="">' + n + "</option>"), u = c; u <= g; u++) {
                var m = u < 10 ? "0" + String(u) : String(u);
                p += '<option value="' + m + '">' + m + "</option>"
            }
            $("#" + e + "_day").html(p)
        }
    } else "" !== $("#" + e + "_year").val() && "" !== $("#" + e + "_month").val() && $("#" + e).val("01-" + $("#" + e + "_month").val() + "-" + $("#" + e + "_year").val())
}

function changeDay(e) {
    $("#" + e).val(""), "" !== $("#" + e + "_year").val() && "" !== $("#" + e + "_month").val() && $("#" + e).val($("#" + e + "_day").val() + "-" + $("#" + e + "_month").val() + "-" + $("#" + e + "_year").val())
}

function gotoLogin(e) {
    $("a[href='#cflogin']").trigger("click"), $("form#loginForm input[name='Email']").val(e)
}

function userRegisterByChat(e, t, r, o) {
    $.ajax({
        url: jsVars.preRegisterChatUrl,
        type: "post",
        data: {
            Email: e,
            mobile: t,
            name: r,
            type: o
        },
        dataType: "json",
        headers: {
            "X-CSRF-Token": jsVars._csrfToken
        },
        success: function(e) {
            e.success
        },
        error: function(e, t, r) {
            console.log(r + "\r\n" + e.statusText + "\r\n" + e.responseText)
        }
    })
}
//by pass otp international
function checkBypassOtp(e, t, r) {
    "+91" != $(e).data("value") && "1" == t ? ($(".hideShowOptBypass").hide(), $("#otpverifylinkMobile").hide()) : "registerBtn" === r && $(".hideShowOptBypass").show(), $("#showMObileVerified").hide()
}

function resendVerifyCode() {
    var e = $("#hashValue").val();
    if ("" == e) return !1;
    var t = $("form#forgotOtpForm input[name='_csrfToken']").val();
    send_ajax_request(jsVars.ForgotPasswordUrl, "post", {
        hash: e
    }, function(e) {
        e.redirect ? location = e.redirect : e.error ? void 0 !== e.error.list.Email && alertPopup(e.error.list.Email, "error") : 200 == e.success && (e.location ? location = e.location :
            //                    $("#resendVerifyCodeBtn").remove();
            //                    $("#resent").html('Resent');
            countdownStartFOrget())
    }, function() {
        $("#forget-password div.loader-block,#register-now div.loader-block").hide(), $(this).attr("disabled", !1)
    }, function() {
        $("#forget-password div.loader-block,#register-now div.loader-block").show(), $(this).attr("disabled", !0), $("#resent").hide()
    }, function(e, t, r) {
        console.log(r + "\r\n" + e.statusText + "\r\n" + e.responseText), $("#forget-password div.loader-block,#register-now div.loader-block").hide()
    }, {
        "X-CSRF-Token": t
    }, {
        async: "false"
    })
}
$(function() {
    /* if both field is availble */
    /* if($('#CountryId').length>0 && $('#ul_dial_code li').length>0){
            var isIndiaCode = true;
            var isIndiaDD   = true;
            $('#ul_dial_code li').on('click', function(){
                var cdc = $(this).data("value");
                if(cdc!='' && cdc!='+91'){
                    isIndiaCode = false;
                }else if(cdc=='+91'){
                    isIndiaCode = true;
                }
                
                showHideStateCity(isIndiaCode,isIndiaDD); 
            });
            $('#CountryId').on('change', function(){
                var cdc_val = $(this).val();
                var cdc = $("#CountryId option[value='"+cdc_val+"']").text();
                cdc = cdc.toLowerCase();
                if(cdc!='' && cdc!='india'){
                   isIndiaDD   = false;
                }else if(cdc=='india'){
                   isIndiaDD   = true;
                }
                /* action to perform * /
                showHideStateCity(isIndiaCode,isIndiaDD); 
            });
            
           
            
        }else 
        if($('#CountryId').length>0){ /* if country dropdown is available* /
            $('#CountryId').on('change', function(){
                var cdc_val = $(this).val();
                var cdc = $("#CountryId option[value='"+cdc_val+"']").text();
                cdc = cdc.toLowerCase();
                if(cdc!='' && cdc!='india'){
                    $('#StateId').val('');
                    $('#CityId').val('');
                    $('div.StateId, div.CityId').hide();
                }else if(cdc=='india'){
                    $('div.StateId, div.CityId').show();
                }
            });
        }else 
        */
    0 < $("#ul_dial_codeMobile li").length && /* if check dial code like +91 etc */
        $("#ul_dial_codeMobile li").on("click", function() {
            var e = "",
                t = 0,
                r = 0;
            "mobile" == (e = void 0 !== $(this).data("fieldid") ? (e = $(this).data("fieldid")).toLowerCase() : e) && ("" != (e = $(this).data("value")) && "+91" != e ? ($("#StateId").length && ($("#StateId").val(""), void 0 !== $("select#StateId")[0].sumo) && ($("select#StateId")[0].sumo.unSelectAll(), $("select#CityId")[0].sumo.unSelectAll()), $("#CityId").length && ($("#CityId").val(""), void 0 !== $("select#CityId")[0].sumo) && $("select#CityId")[0].sumo.unSelectAll(), $(".chosen-select").length && $(".chosen-select").trigger("chosen:updated"), $("div.StateId, div.CityId").hide()) : "+91" == e && ($("#StateId").length && (t = $("#StateId").attr("field-hide-show")), $("#CityId").length && (r = $("#CityId").attr("field-hide-show")), 1 != t && $("div.StateId").show(), 1 != r) && $("div.CityId").show())
        })
}), $(document).on("click", "#forgotVerifyCode", function() {
    var e, t, r = $("form#forgotOtpForm #otpcode").parents("div.form-group"),
        o = $("#hashValue").val();
    return "" != o && ("" == (e = $("#otpcode").val()) ? ($(r).addClass("has-error"), $(r).find("span.help-block").text(""), $(r).find("span.help-block").append("Please enter otp code."), !1) : (t = $("form#forgotOtpForm input[name='_csrfToken']").val(), void send_ajax_request(jsVars.ForgotPasswordVerifyCode, "post", {
        hash: o,
        forget_otp: e
    }, function(e) {
        e.redirect ? location = e.redirect : 0 != e.status && 200 == e.status ? ($(r).find("span.help-block").text(""), $("#afterCodeVerify").show(), $("#resendVerifyCodeBtn").remove(), $("#forgotVerifyCode").remove(), $("#forgotOtpBtn").show()) : ($(r).addClass("has-error"), $(r).find("span.help-block").text(""), $(r).find("span.help-block").append(e.message))
    }, function() {
        $("#forget-password div.loader-block,#register-now div.loader-block").hide(), $(this).attr("disabled", !1)
    }, function() {
        $("#forget-password div.loader-block,#register-now div.loader-block").show(), $(this).attr("disabled", !0)
    }, function(e, t, r) {
        console.log(r + "\r\n" + e.statusText + "\r\n" + e.responseText), $("#forget-password div.loader-block,#register-now div.loader-block").hide()
    }, {
        "X-CSRF-Token": t
    })))
}), $(document).on("click", "#forgotOtpBtn", function() {
    var e, t = $("form#forgotOtpForm #otpcode").parents("div.form-group");
    return "" != $("#hashValue").val() && ("" == $("#otpcode").val() ? ($(t).addClass("has-error"), $(t).find("span.help-block").text(""), $(t).find("span.help-block").append("Please enter otp code."), !1) : (t = $("form#forgotOtpForm input[name='_csrfToken']").val(), e = $("form#forgotOtpForm").serializeArray(), void send_ajax_request(jsVars.ForgotPasswordChange, "post", e, function(e) {
        var t, r;
        e.redirect ? location = e.redirect : 0 == e.status ? (t = "Some thing went wrong, please try again.", void 0 !== e.Password ? (r = $("form#forgotOtpForm #forgot-new-password").parents("div.form-group"), t = e.Password) : void 0 !== e.Confirm ? (r = $("form#forgotOtpForm #forgot-confirm-password").parents("div.form-group"), t = e.Confirm) : (t = e.message, r = $("form#forgotOtpForm #forgot-confirm-password").parents("div.form-group")), $(r).addClass("has-error"), $(r).find("span.help-block").text(""), $(r).find("span.help-block").append(t)) : 200 == e.status ? (
            // location = json['data'];
            $("span.help-block").text(""), $("div.form-group").removeClass("has-error"), $("#forget-password .npf-close").trigger("click"), $("#SuccessPopupArea .modal-title").text("Reset Password Sent"), $("#SuccessPopupArea p#MsgBody").text(e.message), $("#SuccessLink").trigger("click")) : (r = $("form#forgotOtpForm #otpcode").parents("div.form-group"), $(r).addClass("has-error"), $(r).find("span.help-block").text(""), $(r).find("span.help-block").append(e.message))
    }, function() {
        $("#forget-password div.loader-block,#register-now div.loader-block").hide(), $(this).attr("disabled", !1)
    }, function() {
        $("#forget-password div.loader-block,#register-now div.loader-block").show(), $(this).attr("disabled", !0)
    }, function(e, t, r) {
        console.log(r + "\r\n" + e.statusText + "\r\n" + e.responseText), $("#forget-password div.loader-block,#register-now div.loader-block").hide()
    }, {
        "X-CSRF-Token": t
    })))
});
//Forgot password form submit function
var isVarresendVlinkBtnUser = !1;

function validateUsersPassword(e) {
    var t = !1,
        e = $("#" + e).val(),
        r = 0,
        o = 0,
        a = 0,
        i = 0;
    $(".ul_new_password li").removeClass("active"), 8 <= e.length && (i = 1, $(".ul_new_password .password_len").addClass("active")), e.toLowerCase() !== e && (r = 1, $(".ul_new_password .capital").addClass("active")), e.toUpperCase(), /\d/.test(e) && (o = 1, $(".ul_new_password .numeric").addClass("active"));
    return 1 == /[!@#$%^&*()_+\-=\[\]{}`~;':"\\|,.<>\/?]/.test(e) && (a = 1, $(".ul_new_password .special").addClass("active")), t = 1 == r && 1 == o && 1 == i && 1 == a ? !0 : t
}
//Refresh captcha on click
function reloadImage(e) {
    var t = (new Date).getTime();
    $("#" + e).attr("src", jsVars.CaptchaLink + "?" + t)
}

function mobileNumberChanged(e) {
    $(e).parent().parent().find(".help-block").html(""), $("#registerBtn").removeAttr("disabled")
}
$(document).on("click", "#resendVlinkBtn", function() {
    $("span.help-block").text("");
    var e = $("form#resendVlinkForm input[name='_csrfToken']").val();
    if (1 != isVarresendVlinkBtnUser) {
        isVarresendVlinkBtnUser = !0; //If ajax hit is called then set this variable to true
        var t = $("form#resendVlinkForm #resentVerificationEmail ").parents("div.form-group");
        if ("" == $("#resentVerificationEmail").val()) return $(t).addClass("has-error"), $(t).find("span.help-block").text(""), $(t).find("span.help-block").append("Please enter email id."), isVarresendVlinkBtnUser = !1;
        var r = {
            email: jQuery('form#resendVlinkForm input[name="email"]').val()
        };
        send_ajax_request(jsVars.studentResendVerificationLink, "post", r, function(e) {
            isVarresendVlinkBtnUser = !1, e.redirect ? location = e.redirect : 0 == e.status && "csrf" != e.message ? ($(t).addClass("has-error"), $(t).find("span.help-block").text(""), $(t).find("span.help-block").append(e.message)) : 200 == e.status ? ($("span.help-block").text(""), $("div.form-group").removeClass("has-error"), $("#resentVerificationEmail .npf-close").trigger("click"), $("#SuccessPopupArea .modal-title").text("Verification Email Sent"), $("#SuccessPopupArea p#MsgBody").text(e.message), $("#SuccessLink").trigger("click")) : "csrf" != e.message && ($(t).addClass("has-error"), $(t).find("span.help-block").text(""), $(t).find("span.help-block").append(e.message))
        }, function() {
            $("#forget-password div.loader-block,#register-now div.loader-block").hide(), $(this).attr("disabled", !1)
        }, function() {
            $("#forget-password div.loader-block,#register-now div.loader-block").show(), $(this).attr("disabled", !0)
        }, function(e, t, r) {
            console.log(r + "\r\n" + e.statusText + "\r\n" + e.responseText), $("#resentVerificationEmail div.loader-block,#register-now div.loader-block").hide()
        }, {
            "X-CSRF-Token": e
        })
    }
}), $(document).on("keypress", "#resendVlinkForm input", function(e) {
    13 == e.which && (e.preventDefault(), $(this).parents("form").find("button").trigger("click").focus())
});
var sendLoginWithPasswordData = 0;

function pushLoginDatainDatalayer() {
    524 == $("#collegeId").val() && 0 === sendLoginWithPasswordData && (window.dataLayer = window.dataLayer || [], dataLayer.push({
        event: "Login",
        category: "Login",
        action: "Submit",
        label: "Login with Email & Password"
    }), sendLoginWithPasswordData = 1)
}
var sendRegisterWithFormData = 0;

function pushRegisterDatainDatalayer(e, t, r, o, a, i, s) {
    var n;
    524 == $("#collegeId").val() && 0 === sendRegisterWithFormData && (window.dataLayer = window.dataLayer || [], n = {
        event: "New User Registration",
        category: "New User Registration",
        action: "Submit",
        label: "Register with Registration Form"
    }, void 0 !== i && (n.pageType = "Widget", n.pageName = i), void 0 !== e && (n.mobileNo = e), void 0 !== t && (n.utm_source = t), void 0 !== r && (n.utm_medium = r), void 0 !== o && (n.utm_campaign = o), void 0 !== a && (n.pageUrl = a), void 0 !== s && (n.hostName = s), dataLayer.push(n), sendRegisterWithFormData = 1)
}

function showFieldsAndtriggerWebhooks(e, t) {
    if ($("span.help-block").text(""), $("#callingevent").val(e), 1 !== t) return registerUser(), !0;
    var t = $("form#registerForm input[name='_csrfToken']").val(),
        r = $("form#registerForm").serializeArray();
    r.push({
        name: "event",
        value: e
    }), $.ajax({
        url: jsVars.widgetCallingUrl,
        type: "post",
        data: r,
        dataType: "html",
        headers: {
            "X-CSRF-Token": t
        },
        beforeSend: function() {
            $("form#registerForm #callNowBtn").attr("disabled", "disabled"), $("form#registerForm #scheduleCallBtn").attr("disabled", "disabled")
        },
        complete: function() {
            $("form#registerForm #callNowBtn").removeAttr("disabled"), $("form#registerForm #scheduleCallBtn").removeAttr("disabled")
        },
        success: function(e) {
            e = JSON.parse(e), $(".agree-group").before(e.html), $("#callNowBtn").hide(), $("#scheduleCallBtn").hide(), $("#registerBtn").text(e.submitBtnText), $("#registerBtn").show(), $("#resetBtn").show()
        },
        error: function(e, t, r) {
            console.log(r + "\r\n" + e.statusText + "\r\n" + e.responseText), $("#register-now div.loader-block").hide(), isVarRegisterUser = !1
        }
    })
}

function getDynamicFieldDependencyLPU(e, r) {
    if ("string" != typeof e || "" === e || null === e) return [];
    $.ajax({
        url: jsVars.lpuDynamicFieldDependencyLink,
        type: "post",
        data: {
            field: e
        },
        async: !0,
        dataType: "json",
        beforeSend: function() {
            $("#register-now div.loader-block,#register-page div.loader-block").show()
        },
        complete: function() {
            $("#register-now div.loader-block,#register-page div.loader-block").hide()
        },
        success: function(e) {
            if (e.redirect) location = e.redirect;
            else if (1 == e.status)
                for (var t in e.data) r[t] = e.data[t]
        },
        error: function(e, t, r) {
            console.log(r + "\r\n" + e.statusText + "\r\n" + e.responseText)
        }
    })
}

function getDynamicFieldValueMappingLPU(e, r) {
    if ("string" != typeof e || "" === e || null === e) return [];
    $.ajax({
        url: jsVars.lpuDynamicFieldValueMappingLink,
        type: "post",
        data: {
            field: e
        },
        async: !0,
        dataType: "json",
        beforeSend: function() {
            $("#register-now div.loader-block,#register-page div.loader-block").show()
        },
        complete: function() {
            $("#register-now div.loader-block,#register-page div.loader-block").hide()
        },
        success: function(e) {
            if (e.redirect) location = e.redirect;
            else if (1 == e.status)
                for (var t in e.data) r[t] = e.data[t]
        },
        error: function(e, t, r) {
            console.log(r + "\r\n" + e.statusText + "\r\n" + e.responseText)
        }
    })
}

function loadCustomDateTime() {
    $(".registration-date").length && $(".registration-date").each(function() {
        var e, t, r = $(this).data("format"),
            o = $(this).data("startdate"),
            a = $(this).data("enddate"),
            i = $(this).attr("id");
        "DD/MM/YYYY" == r ? $(this).datepicker({
            startView: "decade",
            format: "dd/mm/yyyy",
            enableYearToMonth: !0,
            enableMonthToDay: !0,
            startDate: o,
            endDate: a
        }) : "MM/YYYY" == r ? $(this).datepicker({
            startView: "decade",
            format: "mm/yyyy",
            minViewMode: "months",
            startDate: o,
            endDate: a
        }) : "YYYY" == r ? $(this).datepicker({
            startView: "decade",
            format: "yyyy",
            minViewMode: "years",
            startDate: String(o),
            endDate: String(a)
        }) : "DD/MM/YYYY HH:MM:SS AM/PM" == r && (e = $.fn.tooltip.Constructor.VERSION.split(".")[0], t = "DD/MM/YYYY hh:mm:ss A", $(this).datetimepicker({
            useCurrent: !1,
            format: t
        }).data("DateTimePicker").minDate(o).maxDate(a), $(this).on("dp.show", function() {
            3 < e && ($("body").addClass("bt-" + e), $(this).siblings(".bootstrap-datetimepicker-widget").find("li.collapse").removeClass("show"), $(this).siblings(".bootstrap-datetimepicker-widget").find("li.collapse.in").removeClass("in").addClass("show"), $(".bootstrap-datetimepicker-widget .accordion-toggle").on("click", function() {
                var e = $(".bootstrap-datetimepicker-widget .collapse:not(.show)");
                0 < e.length && ($(".bootstrap-datetimepicker-widget .collapse").removeClass("show"), e.addClass("show"), $(".bootstrap-datetimepicker-widget .glyphicon-time").toggleClass("glyphicon-calendar"))
            })), dateTimePickerMinMax("#" + i, o, a, t)
        }))
    }), $(".registration-date-time").length && $(".registration-date-time").each(function() {
        var e, t = $(this).data("format"),
            r = $(this).data("startdate"),
            o = $(this).data("enddate"),
            a = $(this).data("customdays"),
            i = [];
        for (e in a.weeks) "0" === a.weeks[e] && i.push(e);
        var s = new Date,
            n = new Date;
        n.setDate(n.getDate() + 7), "DD/MM/YYYY" == t ? $(this).datetimepicker({
            format: "DD/MM/YYYY HH:mm",
            daysOfWeekDisabled: i,
            minDate: s,
            maxDate: n
        }) : "MM/YYYY" == t ? $(this).datepicker({
            startView: "decade",
            format: "mm/yyyy",
            minViewMode: "months",
            startDate: r,
            endDate: o
        }) : "YYYY" == t && $(this).datepicker({
            startView: "decade",
            format: "yyyy",
            minViewMode: "years",
            startDate: String(r),
            endDate: String(o)
        })
    }), $(".registration-date-time").val("")
}

function resetShowFields() {
    $("div.widget-show-fields").remove(), $("#callingevent").val(""), $("#callNowBtn").show(), $("#scheduleCallBtn").show(), $("#registerBtn").text("Register"), $("#registerBtn").hide(), $("#resetBtn").hide()
}

function resetInputFile(e) {
    e = $(e).data("id");
    $("#" + e).val(""), $("#" + e + "_choose_files").val("")
}

function showSelectedFiles(e) {
    $("#" + e).parent().removeClass("file"), $("#" + e + "_choose_files").val("");
    for (var t = document.getElementById(e), e = (document.getElementById(e + "_show"), document.getElementById(e + "_choose_files")), r = "", o = 0; o < t.files.length; ++o) 0 < o ? r = o + 1 + " files" : r += t.files.item(o).name, t.files.item(o).name;
    e.value = r
}

function downloadWidgetPDF(e) {
    e = jsVars.FULL_URL + "/downloadWidgetPdf/" + btoa(e);
    window.top.location = e
}

function registrationDataLayerData(e) {
    var t = 0;
    if (0 === (t = "collegeId" in e && e.collegeId ? e.collegeId : t)) return !0;
    var r = 0;
    if (0 === (r = "configureDatalayerColleges" in e && e.configureDatalayerColleges && -1 !== $.inArray(t, e.configureDatalayerColleges) ? 1 : r)) return !0;
    //    if(collegeId === 531) {
    window.dataLayer = window.dataLayer || [];
    t = {};
    "name" in e && e.name && (t.name = e.name), "email" in e && e.email && (t.email = e.email), "mobile" in e && e.mobile && (t.mobile = e.mobile), "countryDialCode" in e && e.countryDialCode && (t.countryDialCode = e.countryDialCode), "phoneNumber" in e && e.phoneNumber && (t.phoneNumber = e.phoneNumber), dataLayer.push(t)
}

function alertPopup(e, t, r) {
    var o, a, i, s;
    t = "error" == t ? (o = "#ErrorPopupArea", a = "#ErroralertTitle", i = "#ErrorMsgBody", s = "#ErrorOkBtn", "Error") : "alert" == t ? (o = "#SuccessPopupArea", a = "#SuccessPopupArea #alertTitle", i = "#MsgBody", s = "#OkBtn", "Alert") : "Preview" == t ? (o = "#SuccessPopupArea", a = "#SuccessPopupArea #alertTitle", i = "#MsgBody", s = "#OkBtn", "Preview") : (o = "#SuccessPopupArea", a = "#alertTitle", i = "#MsgBody", s = "#OkBtn", "Success"), $(a).html(t), $(o + " " + i).html(e), $(".oktick").hide(), void 0 !== r ? ($(s).show(), $(o).modal({
        keyboard: !1
    }).one("click", s, function(e) {
        window.location.href = r
    })) : $(o).modal()
}

function dateTimePickerMinMax(t, r, o, e) {
    var a = moment(r, e).format("MM/DD/YYYY"),
        i = moment(o, e).format("MM/DD/YYYY");
    $(".datepicker-days tbody").on("click", "td.day", function() {
        var e = $(this).data("day");
        e == a ? setTimeout(() => {
            $(t).val(r).datetimepicker("update"), $(t).trigger("change")
        }, 100) : e == i && setTimeout(() => {
            $(t).val(o).datetimepicker("update"), $(t).trigger("change")
        }, 100)
    })
}
$('[data-toggle="tooltip"]').length && $('[data-toggle="tooltip"]').tooltip(), $("select[data-limit]").map((e, t) => {
    $(t).attr("data-limit");
    $(t).closest(".form-group").append(`<span class="validation-limit small">Max ${+parseInt($(t).data("limit"))} selections allowed!</span>`)
}), $(document).on("show.bs.select", "select[data-limit]", function(e) {
    $(e).hasClass("selectpicker") && $(e).selectpicker({
        maxOptions: +parseInt($(e).data("limit"))
    })
}), $(document).on("change", "select[data-limit]", function() {
    $(this).hasClass("sumo-select") && window.innerWidth < 767 && ($(this).val().length >= parseInt($(this).data("limit")) ? $(this).closest(".SumoSelect").find(".optWrapper ul.options .opt:not('.selected')").css({
        "pointer-events": "none",
        opacity: ".6"
    }) : $(this).closest(".SumoSelect").find(".optWrapper ul.options .opt:not('.selected')").css({
        "pointer-events": "",
        opacity: "1"
    }))
});