! function() {
    "use strict";

    function t(t, n, e) {
        return n in t ? Object.defineProperty(t, n, {
            value: e,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[n] = e, t
    }

    function n(t, n) {
        var e = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
            var r = Object.getOwnPropertySymbols(t);
            n && (r = r.filter((function(n) {
                return Object.getOwnPropertyDescriptor(t, n).enumerable
            }))), e.push.apply(e, r)
        }
        return e
    }

    function e(e) {
        for (var r = 1; r < arguments.length; r++) {
            var o = null != arguments[r] ? arguments[r] : {};
            r % 2 ? n(Object(o), !0).forEach((function(n) {
                t(e, n, o[n])
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : n(Object(o)).forEach((function(t) {
                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t))
            }))
        }
        return e
    }

    function r(t, n) {
        return function(t) {
            if (Array.isArray(t)) return t
        }(t) || function(t, n) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(t))) return;
            var e = [],
                r = !0,
                o = !1,
                i = void 0;
            try {
                for (var u, c = t[Symbol.iterator](); !(r = (u = c.next()).done) && (e.push(u.value), !n || e.length !== n); r = !0);
            } catch (t) {
                o = !0, i = t
            } finally {
                try {
                    r || null == c.return || c.return()
                } finally {
                    if (o) throw i
                }
            }
            return e
        }(t, n) || i(t, n) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function o(t) {
        return function(t) {
            if (Array.isArray(t)) return u(t)
        }(t) || function(t) {
            if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) return Array.from(t)
        }(t) || i(t) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function i(t, n) {
        if (t) {
            if ("string" == typeof t) return u(t, n);
            var e = Object.prototype.toString.call(t).slice(8, -1);
            return "Object" === e && t.constructor && (e = t.constructor.name), "Map" === e || "Set" === e ? Array.from(t) : "Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e) ? u(t, n) : void 0
        }
    }

    function u(t, n) {
        (null == n || n > t.length) && (n = t.length);
        for (var e = 0, r = new Array(n); e < n; e++) r[e] = t[e];
        return r
    }
    var c = function(t) {
            return "object" == typeof t ? null !== t : "function" == typeof t
        },
        a = function(t) {
            if (!c(t)) throw TypeError(t + " is not an object!");
            return t
        },
        f = function(t) {
            try {
                return !!t()
            } catch (t) {
                return !0
            }
        },
        d = !f((function() {
            return 7 != Object.defineProperty({}, "a", {
                get: function() {
                    return 7
                }
            }).a
        }));
    var l = function(t, n) {
            return t(n = {
                exports: {}
            }, n.exports), n.exports
        }((function(t) {
            var n = t.exports = "undefined" != typeof window && window.Math == Math ? window : "undefined" != typeof self && self.Math == Math ? self : Function("return this")();
            "number" == typeof __g && (__g = n)
        })).document,
        s = c(l) && c(l.createElement),
        m = !d && !f((function() {
            return 7 != Object.defineProperty((t = "div", s ? l.createElement(t) : {}), "a", {
                get: function() {
                    return 7
                }
            }).a;
            var t
        })),
        p = Object.defineProperty,
        w = {
            f: d ? Object.defineProperty : function(t, n, e) {
                if (a(t), n = function(t, n) {
                        if (!c(t)) return t;
                        var e, r;
                        if (n && "function" == typeof(e = t.toString) && !c(r = e.call(t))) return r;
                        if ("function" == typeof(e = t.valueOf) && !c(r = e.call(t))) return r;
                        if (!n && "function" == typeof(e = t.toString) && !c(r = e.call(t))) return r;
                        throw TypeError("Can't convert object to primitive value")
                    }(n, !0), a(e), m) try {
                    return p(t, n, e)
                } catch (t) {}
                if ("get" in e || "set" in e) throw TypeError("Accessors not supported!");
                return "value" in e && (t[n] = e.value), t
            }
        }.f,
        v = Function.prototype,
        y = /^\s*function ([^ (]*)/;
    "name" in v || d && w(v, "name", {
        configurable: !0,
        get: function() {
            try {
                return ("" + this).match(y)[1]
            } catch (t) {
                return ""
            }
        }
    });
    var h, g = {
            client_id: "c",
            cookie_id: "ci",
            duration_ms: "d",
            event: "e",
            google_click_id: "gc",
            input: "in",
            last_interaction: "li",
            method: "m",
            orientation: "o",
            outer_html: "oh",
            pageview_uuid: "p",
            referer: "r",
            resolution: "re",
            timestamp: "t",
            title: "ti",
            type: "ty",
            url: "ur",
            utm_campaign: "uca",
            utm_content: "uc",
            utm_medium: "um",
            utm_source: "us",
            utm_term: "ut",
            uuid: "u",
            visit_id: "v",
            name: "fn",
            className: "fc",
            id: "fi"
        },
        _ = window._nQs,
        b = window._nQsv || "0.0.0";
    ! function(t) {
        t.FormInput = "form_input", t.FormSubmit = "form_submit", t.LinkClick = "link_click", t.PageView = "pageview", t.NetworkInformation = "network_information", t.WindowBlur = "window_blur"
    }(h || (h = {}));
    var O, j = function(t) {
            var n = [];
            for (var e in t) Object.prototype.hasOwnProperty.call(t, e) && n.push([e, t[e]]);
            return n
        },
        k = function(t, n) {
            for (var e = [], r = 0; r < t.length; r++) e.push(n(t[r], r));
            return e
        },
        S = function(t, n, e) {
            for (var r = e, o = 0; o < t.length; o++) r = n(r, t[o], o);
            return r
        },
        I = function() {
            return window._nQc
        },
        A = "nQ_userVisitId",
        P = function() {
            var t, n, e = "undefined" != typeof window && (window.crypto || window.msCrypto);
            if (e && e.getRandomValues) return t = e.getRandomValues(new Uint8Array(16)), (n = k(o(new Array(256)), (function(t, n) {
                return (n + 256).toString(16).substring(1)
            })))[t[0]] + n[t[1]] + n[t[2]] + n[t[3]] + "-" + n[t[4]] + n[t[5]] + "-" + n[t[6]] + n[t[7]] + "-" + n[t[8]] + n[t[9]] + "-" + n[t[10]] + n[t[11]] + n[t[12]] + n[t[13]] + n[t[14]] + n[t[15]];
            var r = function() {
                return Math.floor(65536 * (1 + Math.random())).toString(16).substring(1)
            };
            return r() + r() + "-" + r() + "-" + r() + "-" + r() + "-" + r() + r() + r()
        },
        E = P(),
        C = function() {
            return E
        },
        x = function() {
            E = P()
        },
        D = function(t, n, e) {
            var r = new Date((new Date).getTime() + 60 * e * 60 * 1e3).toUTCString();
            document.cookie = "".concat(t, "=").concat(n, ";expires=cookie_expire_date").concat(r, ";path=/")
        },
        L = function(t) {
            var n = document.cookie,
                e = n.indexOf(t + "=");
            if (-1 === e) return null;
            var r = -1 === n.indexOf(";", e) ? n.length : n.indexOf(";", e);
            return n.substring(e, r).split("=").pop()
        },
        Q = function(t) {
            return L(t) || P()
        },
        N = [],
        T = !0,
        M = function(t) {
            T = t
        },
        F = function() {
            z(N), N = []
        },
        V = function(t, n) {
            T && (N.push({
                event: t,
                cookie_id: (D("nQ_cookieId", Q("nQ_cookieId"), 8760), L("nQ_cookieId")),
                visit_id: (D(A, Q(A), .5), L(A)),
                pageview_uuid: C(),
                uuid: t === h.PageView ? C() : P(),
                client_id: I(),
                timestamp: Date.now(),
                data: n
            }), 10 === N.length && F())
        },
        U = function(n, o) {
            var i = e({
                event: n.event,
                cookie_id: n.cookie_id,
                visit_id: n.visit_id,
                pageview_uuid: n.pageview_uuid,
                uuid: n.uuid,
                client_id: n.client_id,
                timestamp: n.timestamp
            }, n.data);
            return S(j(i), (function(n, i) {
                var u = r(i, 2),
                    c = u[0],
                    a = u[1];
                return e(e({}, n), a && t({}, function(t, n) {
                    return "".concat(g[t]).concat(n)
                }(c, o), a))
            }), {})
        },
        R = function(t, n) {
            return "".concat(t, "=").concat(encodeURIComponent(n))
        },
        B = function(t) {
            return k(j(t), (function(t) {
                var n = r(t, 2),
                    e = n[0],
                    o = n[1];
                return Array.isArray(o) ? k(o, (function(t) {
                    return R(e, t)
                })).join("&") : R(e, o)
            })).join("&")
        },
        z = function(t) {
            t.length && function(t) {
                var n, e = new Image;
                e.height = 0, e.width = 0, e.style.position = "fixed", e.src = t, e.onload = function() {
                    var t;
                    null !== e.parentNode && (null === (t = document.body) || void 0 === t || t.removeChild(e))
                }, e.onerror = function() {
                    var t;
                    return null === (t = document.body) || void 0 === t ? void 0 : t.removeChild(e)
                }, null === (n = document.body) || void 0 === n || n.appendChild(e)
            }(function(t) {
                var n, e = [{
                        s: (n = [{
                            name: _,
                            version: b
                        }, {
                            name: "JSCollector",
                            version: "3.1.3"
                        }].filter((function(t) {
                            return t.name
                        })), k(n, (function(t) {
                            return "".concat(t.name, ",").concat(t.version)
                        })))
                    }].concat(o(k(t, U))),
                    r = k(e, B).join("&");
                return "".concat("https://new-collect.albacross.com/e.gif?").concat(r)
            }(t))
        },
        W = function(t, n) {
            window.addEventListener && window.addEventListener(t, n, !0)
        },
        Z = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
        $ = function(t) {
            if (-1 !== ["text", "url", "email"].indexOf(t.type)) {
                var n = t.value;
                if (u = n, Z.test(String(u).toLowerCase())) {
                    var e = function(t) {
                            return "@".concat(t.split("@").pop())
                        }(n),
                        r = t.id,
                        o = t.className,
                        i = t.name;
                    V(h.FormInput, {
                        input: e,
                        id: r,
                        className: o,
                        name: i
                    })
                }
            }
            var u
        },
        G = window.navigator.connection,
        H = function(t) {
            t && O !== t && (V(h.NetworkInformation, {
                type: t
            }), O = t)
        },
        J = function() {
            var t, n;
            return (null === (n = null === (t = window.screen) || void 0 === t ? void 0 : t.orientation) || void 0 === n ? void 0 : n.type) || function(t) {
                switch (t) {
                    case 0:
                        return "portrait-primary";
                    case 90:
                        return "landscape-primary";
                    case -90:
                        return "landscape-secondary";
                    case 180:
                        return "portrait-secondary";
                    default:
                        return null
                }
            }(window.orientation)
        },
        q = Date.now(),
        K = function() {
            V(h.WindowBlur, {
                duration_ms: Date.now() - q
            }), q = Date.now()
        },
        X = function() {
            var n = window.location.search.substring(1).split("&"),
                o = k(n, (function(t) {
                    return t.split("=")
                }));
            return S(o, (function(n, o) {
                var i = r(o, 2),
                    u = i[0],
                    c = i[1];
                return e(e({}, n), {}, t({}, u, decodeURIComponent(c)))
            }), {})
        },
        Y = function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : document.location.href,
                n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : document.title,
                e = X(),
                r = e.gclid,
                o = e.utm_source,
                i = e.utm_medium,
                u = e.utm_term,
                c = e.utm_content,
                a = e.utm_campaign;
            x(), V(h.PageView, {
                url: t,
                title: n || void 0,
                referer: document.referrer || void 0,
                resolution: window.screen && [window.screen.width, window.screen.height],
                orientation: J(),
                utm_source: o,
                utm_medium: i,
                utm_term: u,
                utm_content: c,
                utm_campaign: a,
                google_click_id: r && parseInt(r)
            })
        },
        tt = window.location.hash,
        nt = window.location.href,
        et = function() {
            tt = window.location.hash
        },
        rt = function() {
            Y(),
                function() {
                    if (window.history) {
                        var t = window.history.pushState;
                        window.history.pushState = function(n, e, r) {
                            if (r && "string" == typeof r) {
                                var o = "." === r.charAt(0) ? r.slice(1) : r,
                                    i = "/" === o.charAt(0) ? "".concat(document.location.origin).concat(o) : o;
                                i !== nt && (K(), Y(i, e || void 0), nt = i)
                            }
                            et(), t.apply(window.history, arguments)
                        }
                    }
                }(), W("popstate", (function(t) {
                    window.location.hash !== tt && Y(t.target.location.href), et()
                }))
        },
        ot = function() {
            W("change", (function(t) {
                return $(t.target)
            })), rt(), W("submit", (function(t) {
                var n = t.target,
                    e = n.method,
                    r = n.action,
                    i = n.name,
                    u = n.id,
                    c = n.className;
                V(h.FormSubmit, {
                    method: e || "GET",
                    url: r,
                    name: i,
                    id: u,
                    className: c
                }), o(t.target.getElementsByTagName("input")).forEach((function(t) {
                    return $(t)
                }))
            })), W("click", (function(t) {
                var n = function(t, n) {
                    var e = t;
                    do {
                        if (e.tagName.toLowerCase() === n.toLowerCase()) return e;
                        e = e.parentElement
                    } while (e);
                    return null
                }(t.target, "a");
                if (n) {
                    var e = n.title,
                        r = n.text,
                        o = n.href,
                        i = n.outerHTML;
                    V(h.LinkClick, {
                        title: e || r || void 0,
                        url: o || void 0,
                        referer: window.location.href,
                        outer_html: i.length > 500 ? void 0 : i
                    })
                }
            })), G && (G.addEventListener("change", (function(t) {
                return H(t.target.type)
            })), H(G.type)), W("focus", (function(t) {
                t.target === window && (q = Date.now(), M(!0))
            })), W("blur", (function(t) {
                t.target === window && (K(), M(!1))
            }))
        };
    I() && !window._nQ_scriptLoaded && (window._nQ_scriptLoaded = !0, D("nQ_cookieId", Q("nQ_cookieId"), 8760), D(A, Q(A), .5), ot(), setInterval(F, 3e3), W("beforeunload", (function() {
        F()
    })))
}();