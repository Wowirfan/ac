'use strict';
var aa = function(a) {
        function c(d) {
            return a.next(d)
        }

        function b(d) {
            return a.throw(d)
        }
        return new Promise(function(d, e) {
            function f(g) {
                g.done ? d(g.value) : Promise.resolve(g.value).then(c, b).then(f, e)
            }
            f(a.next())
        })
    },
    h = function(a) {
        return aa(a())
    };
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var n = this || self;
var r, u;
a: {
    for (var ba = ["CLOSURE_FLAGS"], z = n, A = 0; A < ba.length; A++)
        if (z = z[ba[A]], z == null) {
            u = null;
            break a
        }
    u = z
}
var ca = u && u[610401301];
r = ca != null ? ca : !1;
var D;
const da = n.navigator;
D = da ? da.userAgentData || null : null;

function F(a) {
    return r ? D ? D.brands.some(({
        brand: c
    }) => c && c.indexOf(a) != -1) : !1 : !1
}

function G(a) {
    var c;
    a: {
        const b = n.navigator;
        if (b) {
            const d = b.userAgent;
            if (d) {
                c = d;
                break a
            }
        }
        c = ""
    }
    return c.indexOf(a) != -1
};

function H() {
    return r ? !!D && D.brands.length > 0 : !1
}

function I() {
    return H() ? F("Chromium") : (G("Chrome") || G("CriOS")) && !(H() ? 0 : G("Edge")) || G("Silk")
};
!G("Android") || I();
I();
G("Safari") && (I() || (H() ? 0 : G("Coast")) || (H() ? 0 : G("Opera")) || (H() ? 0 : G("Edge")) || (H() ? F("Microsoft Edge") : G("Edg/")) || H() && F("Opera"));
var J = null,
    fa = function(a) {
        const c = a.length;
        let b = c * 3 / 4;
        b % 3 ? b = Math.floor(b) : "=.".indexOf(a[c - 1]) != -1 && (b = "=.".indexOf(a[c - 2]) != -1 ? b - 2 : b - 1);
        const d = new Uint8Array(b);
        let e = 0;
        ea(a, function(f) {
            d[e++] = f
        });
        return e !== b ? d.subarray(0, e) : d
    },
    ea = function(a, c) {
        function b(e) {
            for (; d < a.length;) {
                const f = a.charAt(d++),
                    g = J[f];
                if (g != null) return g;
                if (!/^[\s\xa0]*$/.test(f)) throw Error("Unknown base64 encoding at char: " + f);
            }
            return e
        }
        ha();
        let d = 0;
        for (;;) {
            const e = b(-1),
                f = b(0),
                g = b(64),
                k = b(64);
            if (k === 64 && e === -1) break;
            c(e <<
                2 | f >> 4);
            g != 64 && (c(f << 4 & 240 | g >> 2), k != 64 && c(g << 6 & 192 | k))
        }
    },
    ha = function() {
        if (!J) {
            J = {};
            var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),
                c = ["+/=", "+/", "-_=", "-_.", "-_"];
            for (let b = 0; b < 5; b++) {
                const d = a.concat(c[b].split(""));
                for (let e = 0; e < d.length; e++) {
                    const f = d[e];
                    J[f] === void 0 && (J[f] = e)
                }
            }
        }
    };
/*

 Copyright 2020 Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
var K = class extends Error {
    constructor(a) {
        super(a);
        Object.setPrototypeOf(this, K.prototype)
    }
};
K.prototype.name = "SecurityException";
var L = class extends Error {
    constructor(a) {
        super(a);
        Object.setPrototypeOf(this, L.prototype)
    }
};
L.prototype.name = "InvalidArgumentsException";

function M(...a) {
    let c = 0;
    for (let e = 0; e < arguments.length; e++) c += arguments[e].length;
    const b = new Uint8Array(c);
    let d = 0;
    for (let e = 0; e < arguments.length; e++) b.set(arguments[e], d), d += arguments[e].length;
    return b
}

function N(a) {
    const c = a.replace(/-/g, "+").replace(/_/g, "/");
    return O(globalThis.atob(c))
}

function ia(a) {
    let c = "";
    for (let b = 0; b < a.length; b += 1) c += String.fromCharCode(a[b]);
    return globalThis.btoa(c).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_")
}

function O(a) {
    const c = [];
    let b = 0;
    for (let d = 0; d < a.length; d++) {
        const e = a.charCodeAt(d);
        c[b++] = e
    }
    return new Uint8Array(c)
};
/*

 Copyright 2022 Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
var ja = function(a, c, b, d) {
        return h(function*() {
            if (b.length < (a.o ? 28 : 16)) throw new K("ciphertext too short");
            if (c.length !== 12) throw new K("IV must be 12 bytes");
            const e = {
                name: "AES-GCM",
                iv: c,
                tagLength: 128
            };
            d && (e.additionalData = d);
            const f = a.o ? new Uint8Array(b.subarray(12)) : b;
            try {
                return new Uint8Array(yield globalThis.crypto.subtle.decrypt(e, a.key, f))
            } catch (g) {
                throw new K(g.toString());
            }
        })
    },
    ka = class {
        constructor({
            key: a,
            o: c
        }) {
            this.key = a;
            this.o = c
        }
        encrypt(a, c, b) {
            const d = this;
            return h(function*() {
                if (a.length !==
                    12) throw new K("IV must be 12 bytes");
                const e = {
                    name: "AES-GCM",
                    iv: a,
                    tagLength: 128
                };
                b && (e.additionalData = b);
                const f = yield globalThis.crypto.subtle.encrypt(e, d.key, c);
                return d.o ? M(a, new Uint8Array(f)) : new Uint8Array(f)
            })
        }
    };

function la({
    key: a,
    o: c
}) {
    return h(function*() {
        if (![16, 32].includes(a.length)) throw new L("unsupported AES key size: ${n}");
        const b = yield globalThis.crypto.subtle.importKey("raw", a, {
            name: "AES-GCM",
            length: a.length
        }, !1, ["encrypt", "decrypt"]);
        return new ka({
            key: b,
            o: c
        })
    })
};

function ma(a) {
    switch (a) {
        case 1:
            return "P-256";
        case 2:
            return "P-384";
        case 3:
            return "P-521"
    }
}

function P(a) {
    switch (a) {
        case "P-256":
            return 1;
        case "P-384":
            return 2;
        case "P-521":
            return 3
    }
    throw new L("unknown curve: " + a);
}

function R(a) {
    switch (a) {
        case 1:
            return 32;
        case 2:
            return 48;
        case 3:
            return 66
    }
}

function na(a, c) {
    return h(function*() {
        const b = a.algorithm.namedCurve;
        if (!b) throw new L("namedCurve must be provided");
        const d = Object.assign({}, {
                "public": c
            }, a.algorithm),
            e = 8 * R(P(b)),
            f = yield globalThis.crypto.subtle.deriveBits(d, a, e);
        return new Uint8Array(f)
    })
}

function oa(a) {
    return h(function*() {
        return yield globalThis.crypto.subtle.generateKey({
            name: "ECDH",
            namedCurve: a
        }, !0, ["deriveKey", "deriveBits"])
    })
}

function pa(a) {
    return h(function*() {
        const c = yield globalThis.crypto.subtle.exportKey("jwk", a);
        if (c.crv === void 0) throw new L("crv must be provided");
        const b = R(P(c.crv));
        if (c.x === void 0) throw new L("x must be provided");
        if (c.y === void 0) throw new L("y must be provided");
        const d = N(c.x);
        if (d.length !== b) throw new L(`x-coordinate byte-length is invalid (got: ${d.length}, want: ${b}).`);
        const e = N(c.y);
        if (e.length !== b) throw new L(`y-coordinate byte-length is invalid (got: ${e.length}, want: ${b}).`);
        return c
    })
}

function qa(a) {
    return h(function*() {
        const c = a.crv;
        if (!c) throw new L("crv must be provided");
        return yield globalThis.crypto.subtle.importKey("jwk", a, {
            name: "ECDH",
            namedCurve: c
        }, !0, [])
    })
};
var ra = S(1, 0),
    sa = S(2, 16),
    ta = S(2, 18),
    ua = S(2, 1),
    va = S(2, 3),
    wa = S(2, 1),
    xa = S(2, 2),
    ya = O("KEM"),
    za = O("HPKE"),
    Ba = O("HPKE-v1");

function S(a, c) {
    const b = new Uint8Array(a);
    for (let d = 0; d < a; d++) b[d] = c >> 8 * (a - d - 1) & 255;
    return b
}

function Ca({
    J: a,
    I: c,
    D: b
}) {
    return M(za, a, c, b)
}

function Da({
    m: a,
    l: c,
    i: b
}) {
    return M(Ba, b, O(a), c)
}

function Ea({
    s: a,
    info: c,
    i: b,
    length: d
}) {
    return M(S(2, d), Ba, b, O(a), c)
}

function Fa(a, c) {
    return h(function*() {
        var b; {
            const d = R(P(a));
            if (c.length !== 1 + 2 * d || c[0] !== 4) throw new K("invalid point");
            b = {
                kty: "EC",
                crv: a,
                x: ia(new Uint8Array(c.subarray(1, 1 + d))),
                y: ia(new Uint8Array(c.subarray(1 + d, c.length))),
                ext: !0
            }
        }
        return yield qa(b)
    })
}

function Ga(a) {
    return h(function*() {
        const c = a.algorithm,
            b = yield pa(a);
        if (!b.crv) throw new K("Curve has to be defined.");
        var d; {
            const e = R(P(c.namedCurve)),
                f = b.x,
                g = b.y;
            if (f === void 0) throw new L("x must be provided");
            if (g === void 0) throw new L("y must be provided");
            const k = new Uint8Array(1 + 2 * e),
                l = N(g),
                p = N(f);
            k.set(l, 1 + 2 * e - l.length);
            k.set(p, 1 + e - p.length);
            k[0] = 4;
            d = k
        }
        return d
    })
};
var Ha = class {
    constructor(a) {
        this.v = a
    }
    seal({
        key: a,
        nonce: c,
        K: b,
        A: d
    }) {
        const e = this;
        return h(function*() {
            if (a.length !== e.v) throw new K("Unexpected key length: " + a.length.toString());
            return yield(yield la({
                key: a,
                o: !1
            })).encrypt(c, b, d)
        })
    }
    open({
        key: a,
        nonce: c,
        F: b,
        A: d
    }) {
        const e = this;
        return h(function*() {
            if (a.length !== e.v) throw new K("Unexpected key length: " + a.length.toString());
            return ja(yield la({
                key: a,
                o: !1
            }), c, b, d)
        })
    }
};
var Ia = class {};

function T(a) {
    if (a == null || !(a instanceof Uint8Array)) throw new L("input must be a non null Uint8Array");
};
var Ja = function(a, c) {
        return h(function*() {
            T(c);
            const b = yield globalThis.crypto.subtle.sign({
                name: "HMAC",
                hash: {
                    name: a.hash
                }
            }, a.key, c);
            return new Uint8Array(b.slice(0, a.g))
        })
    },
    Ka = class extends Ia {
        constructor(a, c, b) {
            super();
            this.hash = a;
            this.key = c;
            this.g = b
        }
    };

function La(a, c, b) {
    return h(function*() {
        T(c);
        if (!Number.isInteger(b)) throw new L("invalid tag size, must be an integer");
        if (b < 10) throw new L("tag too short, must be at least " + (10).toString() + " bytes");
        switch (a) {
            case "SHA-1":
                if (b > 20) throw new L("tag too long, must not be larger than 20 bytes");
                break;
            case "SHA-256":
                if (b > 32) throw new L("tag too long, must not be larger than 32 bytes");
                break;
            case "SHA-384":
                if (b > 48) throw new L("tag too long, must not be larger than 48 bytes");
                break;
            case "SHA-512":
                if (b >
                    64) throw new L("tag too long, must not be larger than 64 bytes");
                break;
            default:
                throw new L(a + " is not supported");
        }
        const d = yield globalThis.crypto.subtle.importKey("raw", c, {
            name: "HMAC",
            hash: {
                name: a
            },
            length: c.length * 8
        }, !1, ["sign", "verify"]);
        return new Ka(a, d, b)
    })
};
var Ma = function(a, c, b) {
        return h(function*() {
            T(c);
            const d = U(a);
            let e;
            ((e = b) == null ? 0 : e.length) || (b = new Uint8Array(d));
            T(b);
            return yield Ja(yield La(a.u, b, d), c)
        })
    },
    V = function(a, {
        l: c,
        m: b,
        i: d,
        salt: e
    }) {
        return h(function*() {
            return yield Ma(a, Da({
                m: b,
                l: c,
                i: d
            }), e)
        })
    },
    Na = function(a, c, b, d) {
        return h(function*() {
            if (!Number.isInteger(d)) throw new K("length must be an integer");
            if (d <= 0) throw new K("length must be positive");
            const e = U(a);
            if (d > 255 * e) throw new K("length too large");
            T(b);
            const f = yield La(a.u, c, e);
            let g =
                1,
                k = 0,
                l = new Uint8Array(0);
            const p = new Uint8Array(d);
            for (;;) {
                const q = new Uint8Array(l.length + b.length + 1);
                q.set(l, 0);
                q.set(b, l.length);
                q[q.length - 1] = g;
                l = yield Ja(f, q);
                if (k + l.length < d) p.set(l, k), k += l.length, g++;
                else {
                    p.set(l.subarray(0, d - k), k);
                    break
                }
            }
            return p
        })
    },
    Oa = function(a, {
        C: c,
        info: b,
        s: d,
        i: e,
        length: f
    }) {
        return h(function*() {
            return yield Na(a, c, Ea({
                s: d,
                info: b,
                i: e,
                length: f
            }), f)
        })
    },
    Pa = function(a, {
        l: c,
        m: b,
        info: d,
        s: e,
        i: f,
        length: g,
        salt: k
    }) {
        return h(function*() {
            const l = yield Ma(a, Da({
                m: b,
                l: c,
                i: f
            }), k);
            return yield Na(a,
                l, Ea({
                    s: e,
                    info: d,
                    i: f,
                    length: g
                }), g)
        })
    },
    U = function(a) {
        switch (a.u) {
            case "SHA-256":
                return 32;
            case "SHA-512":
                return 64
        }
    },
    W = class {
        constructor(a) {
            this.u = a
        }
    };
var Qa = function(a) {
        var c = a.g;
        const b = new Uint8Array(12);
        for (let f = 0; f < 12; f++) b[f] = Number(c >> BigInt(8 * (12 - f - 1))) & 255;
        var d = a.h;
        if (d.length !== b.length) throw new L("Both byte arrays should be of the same length");
        const e = new Uint8Array(d.length);
        for (let f = 0; f < e.length; f++) e[f] = d[f] ^ b[f];
        if (a.g >= a.j) throw new K("message limit reached");
        a.g += BigInt(1);
        return e
    },
    Ra = class {
        constructor(a, c, b, d) {
            this.B = a;
            this.key = c;
            this.h = b;
            this.aead = d;
            this.g = BigInt(0);
            this.j = (BigInt(1) << BigInt(96)) - BigInt(1)
        }
        seal(a, c) {
            const b =
                this;
            return h(function*() {
                const d = Qa(b);
                return yield b.aead.seal({
                    key: b.key,
                    nonce: d,
                    K: a,
                    A: c
                })
            })
        }
        open(a, c) {
            const b = this;
            return h(function*() {
                const d = Qa(b);
                return b.aead.open({
                    key: b.key,
                    nonce: d,
                    F: a,
                    A: c
                })
            })
        }
    };

function Sa(a, c, b, d, e, f) {
    return h(function*() {
        var g;
        a: {
            switch (e.v) {
                case 16:
                    g = wa;
                    break a;
                case 32:
                    g = xa;
                    break a
            }
            g = void 0
        }
        var k;
        a: {
            switch (d.u) {
                case "SHA-256":
                    k = ua;
                    break a;
                case "SHA-512":
                    k = va;
                    break a
            }
            k = void 0
        }
        const l = Ca({
                J: Ta(b),
                I: k,
                D: g
            }),
            p = yield V(d, {
                l: new Uint8Array(0),
                m: "psk_id_hash",
                i: l
            }), q = yield V(d, {
                l: f,
                m: "info_hash",
                i: l
            }), E = M(ra, p, q), w = yield V(d, {
                l: new Uint8Array(0),
                m: "secret",
                i: l,
                salt: c
            }), m = yield Oa(d, {
                C: w,
                info: E,
                s: "key",
                i: l,
                length: e.v
            }), t = yield Oa(d, {
                C: w,
                info: E,
                s: "base_nonce",
                i: l,
                length: 12
            });
        return new Ra(a, m, t, e)
    })
}

function Ua(a, c, b, d, e) {
    return h(function*() {
        const f = yield Va(c, a);
        return yield Sa(f.B, f.L, c, b, d, e)
    })
};
var Wa = function(a) {
        return h(function*() {
            return yield Ga(a.publicKey)
        })
    },
    Xa = class {
        constructor(a, c) {
            this.privateKey = a;
            this.publicKey = c
        }
    };

function Ya(a) {
    return h(function*() {
        Za(a.privateKey, "private");
        Za(a.publicKey, "public");
        return new Xa(a.privateKey, a.publicKey)
    })
}

function Za(a, c) {
    if (c !== a.type) throw new L(`keyPair ${c} key was of type ${a.type}`);
    const b = a.algorithm;
    if ("ECDH" !== b.name) throw new L(`keyPair ${c} key should be ECDH but found ${b.name}`);
};
var ab = function(a) {
        switch (a) {
            case 1:
                return new $a(new W("SHA-256"), 1);
            case 3:
                return new $a(new W("SHA-512"), 3)
        }
    },
    Ta = function(a) {
        switch (a.g) {
            case 1:
                return sa;
            case 3:
                return ta
        }
    },
    Va = function(a, c) {
        return h(function*() {
            const b = yield oa(ma(a.g));
            return yield a.h(c, yield Ya(b))
        })
    },
    bb = function(a, c, b, d) {
        return h(function*() {
            const e = M(b, d),
                f = M(ya, Ta(a));
            return yield Pa(a.j, {
                l: c,
                m: "eae_prk",
                info: e,
                s: "shared_secret",
                i: f,
                length: U(a.j)
            })
        })
    },
    $a = class {
        constructor(a, c) {
            this.j = a;
            this.g = c;
            this.TEST_ONLY = this.h
        }
        h(a,
            c) {
            const b = this;
            return h(function*() {
                const d = yield Fa(ma(b.g), a), e = yield na(c.privateKey, d), f = yield Wa(c);
                return {
                    L: yield bb(b, e, f, a), B: f
                }
            })
        }
    };
/*

 Copyright 2024 Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
function cb(a, c, b) {
    var d;
    return h(function*() {
        d || (d = new Uint8Array(0));
        let e, f, g;
        switch (a) {
            case 1:
                e = ab(1);
                f = new W("SHA-256");
                g = new Ha(16);
                break;
            case 2:
                e = ab(3);
                f = new W("SHA-512");
                g = new Ha(32);
                break;
            default:
                throw new K(`Unknown HPKE parameters: ${a}`);
        }
        const k = yield Ua(c, e, f, g, d), l = yield k.seal(b, new Uint8Array(0));
        return M(k.B, l)
    })
};
const db = Number('_TEMPLATE_VARIABLE("var_encryption_timeout_ms")');

function eb(a) {
    try {
        const c = JSON.parse(a).keys,
            b = c[Math.floor(Math.random() * c.length)];
        return b && b.hpkePublicKey && b.hpkePublicKey.params && b.hpkePublicKey.params.kem && b.hpkePublicKey.params.kdf && b.hpkePublicKey.params.aead && b.hpkePublicKey.version !== void 0 && b.id && b.hpkePublicKey.publicKey ? b : void 0
    } catch (c) {}
}
var fb = function(a, c, b) {
        return h(function*() {
            if (!b.crypto) return X(9);
            if (!a.h) return X(a.status);
            try {
                let f;
                const g = fa((f = a.h) == null ? void 0 : f.hpkePublicKey.publicKey);
                if (!g || !a.g) return X(11);
                const k = fa(btoa(c)),
                    l = yield cb(a.g, g, k);
                var d;
                if (l.length <= 8192) d = String.fromCharCode.apply(null, l);
                else {
                    var e = "";
                    for (let q = 0; q < l.length; q += 8192) e += String.fromCharCode.apply(null, Array.prototype.slice.call(l, q, q + 8192));
                    d = e
                }
                let p = b.btoa(d);
                p = p.replace(/\//g, "_");
                p = p.replace(/\+/g, "-");
                return X(0, p)
            } catch (f) {
                return X(6)
            }
        })
    },
    hb = class {
        constructor(a) {
            this.status = 13;
            if (a) {
                var c = a.hpkePublicKey.params.kem,
                    b = a.hpkePublicKey.params.kdf,
                    d = a.hpkePublicKey.params.aead;
                c === "DHKEM_P521_HKDF_SHA512" && b === "HKDF_SHA512" && d === "AES_256_GCM" ? (this.g = 2, this.h = a) : c === "DHKEM_P256_HKDF_SHA256" && b === "HKDF_SHA256" && d === "AES_128_GCM" ? (this.g = 1, this.h = a) : this.status = 7
            } else this.status = 8
        }
        encrypt(a, c, b) {
            const d = fb(this, a, c);
            return b || !db ? d : Promise.race([d, gb().then(() => X(14))])
        }
    };

function X(a, c) {
    return a === 0 ? {
        cipherText: c,
        status: a
    } : {
        status: a
    }
}

function gb() {
    return new Promise(a => void setTimeout(a, db))
};

function ib(a) {
    switch (a) {
        case 0:
            break;
        case 9:
            return "e4";
        case 6:
            return "e5";
        case 14:
            return "e6";
        default:
            return "e7"
    }
};
const jb = /^[0-9A-Fa-f]{64}$/;

function kb(a) {
    try {
        return (new TextEncoder).encode(a)
    } catch (c) {
        const b = [];
        for (let d = 0; d < a.length; d++) {
            let e = a.charCodeAt(d);
            e < 128 ? b.push(e) : e < 2048 ? b.push(192 | e >> 6, 128 | e & 63) : e < 55296 || e >= 57344 ? b.push(224 | e >> 12, 128 | e >> 6 & 63, 128 | e & 63) : (e = 65536 + ((e & 1023) << 10 | a.charCodeAt(++d) & 1023), b.push(240 | e >> 18, 128 | e >> 12 & 63, 128 | e >> 6 & 63, 128 | e & 63))
        }
        return new Uint8Array(b)
    }
}

function lb(a, c) {
    if (a === "" || a === "e0") return Promise.resolve(a);
    let b;
    if ((b = c.crypto) == null ? 0 : b.subtle) {
        if (jb.test(a)) return Promise.resolve(a);
        try {
            const d = kb(a);
            return c.crypto.subtle.digest("SHA-256", d).then(e => {
                const f = Array.from(new Uint8Array(e)).map(g => String.fromCharCode(g)).join("");
                return c.btoa(f).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
            }).catch(() => "e2")
        } catch (d) {
            return Promise.resolve("e2")
        }
    } else return Promise.resolve("e1")
};
/*
 jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license.
*/
var mb = /\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,
    nb = function(a) {
        var c;
        if (!(c = !a)) {
            var b;
            if (a == null) b = String(a);
            else {
                var d = mb.exec(Object.prototype.toString.call(Object(a)));
                b = d ? d[1].toLowerCase() : "object"
            }
            c = b != "object"
        }
        if (c || a.nodeType || a == a.window) return !1;
        try {
            if (a.constructor && !Object.prototype.hasOwnProperty.call(Object(a), "constructor") && !Object.prototype.hasOwnProperty.call(Object(a.constructor.prototype), "isPrototypeOf")) return !1
        } catch (f) {
            return !1
        }
        for (var e in a);
        return e ===
            void 0 || Object.prototype.hasOwnProperty.call(Object(a), e)
    };
var ob = function(a, c) {
        c = a.g + c;
        let b = c.indexOf("\n\n");
        for (; b !== -1;) {
            var d;
            a: {
                const [x, B] = c.substring(0, b).split("\n");
                if (x.indexOf("event: message") === 0 && B.indexOf("data: ") === 0) try {
                    d = JSON.parse(B.substring(B.indexOf(":") + 1));
                    break a
                } catch (y) {}
                d = void 0
            }
            var e = a,
                f = d;
            if (f) {
                var g = f.send_pixel,
                    k = f.options,
                    l = e.h;
                if (g) {
                    var p = g || [];
                    if (Array.isArray(p)) {
                        var q = nb(k) ? k : {};
                        for (const x of p) l(x, q)
                    }
                }
                var E = f.create_iframe,
                    w = f.options,
                    m = e.j;
                if (E && m) {
                    var t = E || [];
                    if (Array.isArray(t)) {
                        var v = nb(w) ? w : {};
                        for (const x of t) m(x,
                            v)
                    }
                }
            }
            c = c.substring(b + 2);
            b = c.indexOf("\n\n")
        }
        a.g = c
    },
    pb = class {
        constructor(a) {
            this.h = a;
            this.g = ""
        }
    };
var qb = {
    M: 0,
    N: 1,
    0: "GET",
    1: "POST"
};
var rb = function(a, c, b) {
        return h(function*() {
            const d = eb(b.encryptionKeyString || ""),
                e = a.g.performance.now();
            return (new hb(d)).encrypt(c, a.g).then(f => {
                const g = a.g.performance.now(),
                    k = [`emkid.${d==null?void 0:d.id}~`, `ev.${(f.cipherText||"").replace(/./g,"*")}`, `&_es=${f.status}`];
                e && g && k.push(`&_est=${Math.round(g)-Math.round(e)}`);
                return k.join("")
            }, () => [`ec.${ib(15)}`, "&_es=15"].join("")).catch(() => [`ec.${ib(16)}`, "&_es=16"].join(""))
        })
    },
    ub = function(a, c) {
        return h(function*() {
            if (!c.url) return {
                failureType: 9,
                command: 0,
                data: "url required."
            };
            const b = yield sb(a, c);
            if ("failureType" in b) return b;
            yield tb(a, b, c);
            return b
        })
    },
    vb = function(a, c, b, d) {
        h(function*() {
            let e;
            const f = c.commandType,
                g = c.params;
            switch (f) {
                case 0:
                    e = yield ub(a, g);
                    break;
                default:
                    e = {
                        failureType: 8,
                        command: f,
                        data: `Command with type ${f} unknown.`
                    }
            }
            "failureType" in e ? d(e) : b(e)
        })
    },
    sb = function(a, c) {
        return h(function*() {
            function b(m) {
                return h(function*() {
                    const [t, v] = m.split("|");
                    let [x, B] = t.split("."), y = B, C = k[x];
                    C || (C = t, y = "");
                    const Z = Q => h(function*() {
                        try {
                            return yield E(v)(Q)
                        } catch (Y) {
                            throw new wb(Y.message);
                        }
                    });
                    if (!y) {
                        if (typeof C === "string") return yield Z(C);
                        const Q = C,
                            Y = Object.keys(Q).map(Aa => h(function*() {
                                const yb = yield Z(Q[Aa]);
                                return `${Aa}=${yb}`
                            }));
                        return (yield Promise.all(Y)).join("&")
                    }
                    return typeof C === "object" && C[y] ? yield Z(C[y]): m
                })
            }

            function d(m) {
                return h(function*() {
                    let t, v = "";
                    for (; m.match(q) && v !== m;) {
                        v = m;
                        t = m.matchAll(q);
                        const x = [...t].map(y => b(y[1])),
                            B = yield Promise.all(x);
                        B.length !== 0 && (m = m.replace(q, y => B.shift() || y))
                    }
                    return m
                })
            }
            let {
                url: e,
                body: f
            } = c;
            const {
                attributionReporting: g,
                templates: k,
                processResponse: l,
                method: p = 0
            } = c, q = RegExp("\\${([^${}]*?)}", "g"), E = m => {
                if (m == null) return v => h(function*() {
                    return v
                });
                const t = a.h[m];
                if (t == null) throw Error(`Unknown filter: ${m}`);
                return v => h(function*() {
                    return yield t(v, c)
                })
            };
            try {
                e = yield d(e), f = f ? yield d(f): void 0
            } catch (m) {
                return {
                    failureType: 9,
                    command: 0,
                    data: `Failed to inject template values: ${m}`
                }
            }
            const w = {
                method: qb[p],
                credentials: "include",
                body: p === 1 ? f : void 0,
                keepalive: !0,
                redirect: "follow"
            };
            l || (w.mode = "no-cors");
            g && (w.attributionReporting = {
                eventSourceEligible: !1,
                triggerEligible: !0
            });
            try {
                const m = yield a.g.fetch(e, w);
                return l && !m.ok ? {
                    failureType: 9,
                    command: 0,
                    data: "Fetch failed"
                } : {
                    data: l ? yield m.text(): e
                }
            } catch (m) {
                return {
                    failureType: 9,
                    command: 0,
                    data: `Fetch failed: ${m}`
                }
            }
        })
    },
    tb = function(a, c, b) {
        return h(function*() {
            if (b.processResponse) {
                var d = [];
                ob(new pb((e, f) => {
                    d.push(sb(a, {
                        url: e,
                        method: 0,
                        templates: b.templates,
                        processResponse: !1,
                        attributionReporting: f.attribution_reporting
                    }))
                }), c.data);
                return Promise.all(d)
            }
        })
    },
    xb = class {
        constructor(a) {
            this.g = a;
            this.h = {
                sha256: c => {
                    const b = this;
                    return h(function*() {
                        return yield lb(c, b.g)
                    })
                },
                encode: c => h(function*() {
                    return encodeURIComponent(c)
                }),
                encrypt: (c, b) => {
                    const d = this;
                    return h(function*() {
                        return yield rb(d, c, b)
                    })
                }
            }
        }
    };
class wb extends Error {
    constructor(a) {
        super(a)
    }
};
var zb = function(a, c, b) {
    a.g[c] == null && (a.g[c] = 0, a.h[c] = b, a.j++);
    a.g[c]++;
    return {
        targetId: a.id,
        clientCount: a.j,
        totalLifeMs: Math.round(b - a.H),
        heartbeatCount: a.g[c],
        clientLifeMs: Math.round(b - a.h[c])
    }
};
class Ab {
    constructor(a) {
        this.H = a;
        this.g = {};
        this.h = {};
        this.j = 0;
        this.id = String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()))
    }
}

function Bb(a) {
    return a.performance && a.performance.now() || Date.now()
}
var Cb = function(a, c) {
    class b {
        constructor(d, e) {
            this.h = d;
            this.g = e;
            this.j = new Ab(Bb(e))
        }
        G(d, e) {
            const f = d.clientId;
            if (d.type === 0) d.stats = zb(this.j, f, Bb(this.g)), e(d);
            else if (d.type === 1) try {
                this.h(d.command, g => {
                    d.result = g;
                    e(d)
                }, g => {
                    d.failure = g;
                    e(d)
                })
            } catch (g) {
                d.failure = {
                    failureType: 11,
                    data: g.toString()
                }, e(d)
            }
        }
    }
    return new b(a, c)
};
(function(a) {
    a.g.addEventListener("install", () => {
        a.g.skipWaiting()
    });
    a.g.addEventListener("activate", c => {
        c.waitUntil(a.g.clients.claim())
    });
    a.g.addEventListener("message", c => {
        const b = c.source;
        if (b) {
            var d = c.data,
                e = new Promise(f => {
                    a.h.G(d, g => {
                        b.postMessage(g);
                        f(void 0)
                    })
                });
            c.waitUntil(e)
        }
    })
})(new class {
    constructor(a) {
        this.g = a;
        const c = new xb(a);
        this.h = Cb((b, d, e) => {
            vb(c, b, d, e)
        }, a)
    }
}(self));