(function() {
    var n, ba;

    function ca(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    }
    var da = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    };

    function ea(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    }
    var fa = ea(this),
        ha = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        q = {},
        ka = {};

    function r(a, b, c) {
        if (!c || a != null) {
            c = ka[b];
            if (c == null) return a[b];
            c = a[c];
            return c !== void 0 ? c : a[b]
        }
    }

    function x(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = d.length === 1;
            var e = d[0],
                f;!a && e in q ? f = q : f = fa;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = ha && c === "es6" ? f[d] : null;b = b(c);b != null && (a ? da(q, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (ka[d] === void 0 && (a = Math.random() * 1E9 >>> 0, ka[d] = ha ? fa.Symbol(d) : "$jscp$" + a + "$" + d), da(f, ka[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    }
    x("Symbol", function(a) {
        function b(f) {
            if (this instanceof b) throw new TypeError("Symbol is not a constructor");
            return new c(d + (f || "") + "_" + e++, f)
        }

        function c(f, g) {
            this.g = f;
            da(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        }
        if (a) return a;
        c.prototype.toString = function() {
            return this.g
        };
        var d = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            e = 0;
        return b
    }, "es6");
    x("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, q.Symbol)("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = fa[b[c]];
            typeof d === "function" && typeof d.prototype[a] != "function" && da(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return la(ca(this))
                }
            })
        }
        return a
    }, "es6");

    function la(a) {
        a = {
            next: a
        };
        a[r(q.Symbol, "iterator")] = function() {
            return this
        };
        return a
    }

    function y(a) {
        var b = typeof q.Symbol != "undefined" && r(q.Symbol, "iterator") && a[r(q.Symbol, "iterator")];
        if (b) return b.call(a);
        if (typeof a.length == "number") return {
            next: ca(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    }

    function ma(a) {
        return na(a, a)
    }

    function na(a, b) {
        a.raw = b;
        Object.freeze && (Object.freeze(a), Object.freeze(b));
        return a
    }

    function A(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    }
    var oa = ha && typeof r(Object, "assign") == "function" ? r(Object, "assign") : function(a, b) {
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var e in d) A(d, e) && (a[e] = d[e])
        }
        return a
    };
    x("Object.assign", function(a) {
        return a || oa
    }, "es6");

    function pa() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    }
    x("WeakMap", function(a) {
        function b(g) {
            this.g = (f += Math.random() + 1).toString();
            if (g) {
                g = y(g);
                for (var h; !(h = g.next()).done;) h = h.value, this.set(h[0], h[1])
            }
        }

        function c() {}

        function d(g) {
            var h = typeof g;
            return h === "object" && g !== null || h === "function"
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var g = Object.seal({}),
                        h = Object.seal({}),
                        k = new a([
                            [g, 2],
                            [h, 3]
                        ]);
                    if (k.get(g) != 2 || k.get(h) != 3) return !1;
                    k.delete(g);
                    k.set(h, 4);
                    return !k.has(g) && k.get(h) == 4
                } catch (l) {
                    return !1
                }
            }()) return a;
        var e = "$jscomp_hidden_" + Math.random(),
            f = 0;
        b.prototype.set = function(g, h) {
            if (!d(g)) throw Error("Invalid WeakMap key");
            if (!A(g, e)) {
                var k = new c;
                da(g, e, {
                    value: k
                })
            }
            if (!A(g, e)) throw Error("WeakMap key fail: " + g);
            g[e][this.g] = h;
            return this
        };
        b.prototype.get = function(g) {
            return d(g) && A(g, e) ? g[e][this.g] : void 0
        };
        b.prototype.has = function(g) {
            return d(g) && A(g, e) && A(g[e], this.g)
        };
        b.prototype.delete = function(g) {
            return d(g) && A(g, e) && A(g[e], this.g) ? delete g[e][this.g] : !1
        };
        return b
    }, "es6");
    x("Map", function(a) {
        function b() {
            var h = {};
            return h.o = h.next = h.head = h
        }

        function c(h, k) {
            var l = h[1];
            return la(function() {
                if (l) {
                    for (; l.head != h[1];) l = l.o;
                    for (; l.next != l.head;) return l = l.next, {
                        done: !1,
                        value: k(l)
                    };
                    l = null
                }
                return {
                    done: !0,
                    value: void 0
                }
            })
        }

        function d(h, k) {
            var l = k && typeof k;
            l == "object" || l == "function" ? f.has(k) ? l = f.get(k) : (l = "" + ++g, f.set(k, l)) : l = "p_" + k;
            var m = h[0][l];
            if (m && A(h[0], l))
                for (h = 0; h < m.length; h++) {
                    var p = m[h];
                    if (k !== k && p.key !== p.key || k === p.key) return {
                        id: l,
                        list: m,
                        index: h,
                        l: p
                    }
                }
            return {
                id: l,
                list: m,
                index: -1,
                l: void 0
            }
        }

        function e(h) {
            this[0] = {};
            this[1] = b();
            this.size = 0;
            if (h) {
                h = y(h);
                for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
            }
        }
        if (function() {
                if (!a || typeof a != "function" || !r(a.prototype, "entries") || typeof Object.seal != "function") return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(y([
                            [h, "s"]
                        ]));
                    if (k.get(h) != "s" || k.size != 1 || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || k.size != 2) return !1;
                    var l = r(k, "entries").call(k),
                        m = l.next();
                    if (m.done || m.value[0] != h || m.value[1] != "s") return !1;
                    m = l.next();
                    return m.done ||
                        m.value[0].x != 4 || m.value[1] != "t" || !l.next().done ? !1 : !0
                } catch (p) {
                    return !1
                }
            }()) return a;
        var f = new q.WeakMap;
        e.prototype.set = function(h, k) {
            h = h === 0 ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this[0][l.id] = []);
            l.l ? l.l.value = k : (l.l = {
                next: this[1],
                o: this[1].o,
                head: this[1],
                key: h,
                value: k
            }, l.list.push(l.l), this[1].o.next = l.l, this[1].o = l.l, this.size++);
            return this
        };
        e.prototype.delete = function(h) {
            h = d(this, h);
            return h.l && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.l.o.next = h.l.next, h.l.next.o =
                h.l.o, h.l.head = null, this.size--, !0) : !1
        };
        e.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].o = b();
            this.size = 0
        };
        e.prototype.has = function(h) {
            return !!d(this, h).l
        };
        e.prototype.get = function(h) {
            return (h = d(this, h).l) && h.value
        };
        e.prototype.entries = function() {
            return c(this, function(h) {
                return [h.key, h.value]
            })
        };
        e.prototype.keys = function() {
            return c(this, function(h) {
                return h.key
            })
        };
        e.prototype.values = function() {
            return c(this, function(h) {
                return h.value
            })
        };
        e.prototype.forEach = function(h, k) {
            for (var l = r(this,
                    "entries").call(this), m; !(m = l.next()).done;) m = m.value, h.call(k, m[1], m[0], this)
        };
        e.prototype[r(q.Symbol, "iterator")] = r(e.prototype, "entries");
        var g = 0;
        return e
    }, "es6");
    x("globalThis", function(a) {
        return a || fa
    }, "es_2020");

    function qa(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[r(q.Symbol, "iterator")] = function() {
            return e
        };
        return e
    }
    x("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return qa(this, function(b, c) {
                return [b, c]
            })
        }
    }, "es6");
    x("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return qa(this, function(b) {
                return b
            })
        }
    }, "es6");

    function ra(a, b, c) {
        if (a == null) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    }
    x("String.prototype.endsWith", function(a) {
        return a ? a : function(b, c) {
            var d = ra(this, b, "endsWith");
            c === void 0 && (c = d.length);
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var e = b.length; e > 0 && c > 0;)
                if (d[--c] != b[--e]) return !1;
            return e <= 0
        }
    }, "es6");
    x("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) A(b, d) && c.push([d, b[d]]);
            return c
        }
    }, "es8");
    x("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) A(b, d) && c.push(b[d]);
            return c
        }
    }, "es8");
    x("Array.prototype.values", function(a) {
        return a ? a : function() {
            return qa(this, function(b, c) {
                return c
            })
        }
    }, "es8");
    x("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c
        }
    }, "es6");
    x("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || r(Object, "is").call(Object, f, b)) return !0
            }
            return !1
        }
    }, "es7");
    x("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return ra(this, b, "includes").indexOf(b, c || 0) !== -1
        }
    }, "es6");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var B = this || self;

    function sa(a) {
        a = parseFloat(a);
        return isNaN(a) || a > 1 || a < 0 ? 0 : a
    };

    function wa(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    var xa = Array.prototype.indexOf ? function(a, b) {
            return Array.prototype.indexOf.call(a, b, void 0)
        } : function(a, b) {
            if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
            for (var c = 0; c < a.length; c++)
                if (c in a && a[c] === b) return c;
            return -1
        },
        ya = Array.prototype.some ? function(a, b) {
            return Array.prototype.some.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) return !0;
            return !1
        };
    var za, Aa;
    a: {
        for (var Ba = ["CLOSURE_FLAGS"], Ca = B, Da = 0; Da < Ba.length; Da++)
            if (Ca = Ca[Ba[Da]], Ca == null) {
                Aa = null;
                break a
            }
        Aa = Ca
    }
    var Ea = Aa && Aa[610401301];
    za = Ea != null ? Ea : !1;

    function Fa() {
        var a = B.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Ga, Ha = B.navigator;
    Ga = Ha ? Ha.userAgentData || null : null;

    function Ia(a) {
        return za ? Ga ? Ga.brands.some(function(b) {
            return (b = b.brand) && b.indexOf(a) != -1
        }) : !1 : !1
    }

    function C(a) {
        return Fa().indexOf(a) != -1
    };

    function G() {
        return za ? !!Ga && Ga.brands.length > 0 : !1
    }

    function Ja() {
        return G() ? Ia("Chromium") : (C("Chrome") || C("CriOS")) && !(G() ? 0 : C("Edge")) || C("Silk")
    };

    function Ka(a) {
        Ka[" "](a);
        return a
    }
    Ka[" "] = function() {};
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    var La = q.globalThis.trustedTypes,
        Ma;

    function Na() {
        var a = null;
        if (!La) return a;
        try {
            var b = function(c) {
                return c
            };
            a = La.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {}
        return a
    }

    function Ra() {
        Ma === void 0 && (Ma = Na());
        return Ma
    };

    function Ta(a) {
        this.g = a
    }
    Ta.prototype.toString = function() {
        return this.g + ""
    };

    function Ua(a) {
        var b = Ra();
        return new Ta(b ? b.createScriptURL(a) : a)
    }

    function Va(a) {
        if (a instanceof Ta) return a.g;
        throw Error("");
    };
    var Wa = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function Xa(a) {
        this.g = a
    }
    Xa.prototype.toString = function() {
        return this.g + ""
    };

    function Ya(a) {
        var b = Ra();
        return new Xa(b ? b.createHTML(a) : a)
    }

    function Za(a) {
        if (a instanceof Xa) return a.g;
        throw Error("");
    };

    function $a(a, b) {
        a.src = Va(b);
        var c;
        b = a.ownerDocument && a.ownerDocument.defaultView || window;
        b = b === void 0 ? document : b;
        var d;
        b = (d = (c = "document" in b ? b.document : b).querySelector) == null ? void 0 : d.call(c, "script[nonce]");
        (c = b == null ? "" : b.nonce || b.getAttribute("nonce") || "") && a.setAttribute("nonce", c)
    };

    function ab(a, b) {
        a.write(Za(b))
    };
    var bb = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function cb(a) {
        var b = a.match(bb);
        a = b[5];
        var c = b[6];
        b = b[7];
        var d = "";
        a && (d += a);
        c && (d += "?" + c);
        b && (d += "#" + b);
        return d
    }

    function db(a, b, c, d) {
        for (var e = c.length;
            (b = a.indexOf(c, b)) >= 0 && b < d;) {
            var f = a.charCodeAt(b - 1);
            if (f == 38 || f == 63)
                if (f = a.charCodeAt(b + e), !f || f == 61 || f == 38 || f == 35) return b;
            b += e + 1
        }
        return -1
    }
    var eb = /#|$/;

    function fb(a, b) {
        var c = a.search(eb),
            d = db(a, 0, b, c);
        if (d < 0) return null;
        var e = a.indexOf("&", d);
        if (e < 0 || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, e !== -1 ? e : 0).replace(/\+/g, " "))
    }
    var gb = /[?&]($|#)/;

    function hb(a, b, c) {
        for (var d = a.search(eb), e = 0, f, g = [];
            (f = db(a, e, b, d)) >= 0;) g.push(a.substring(e, f)), e = Math.min(a.indexOf("&", f) + 1 || d, d);
        g.push(a.slice(e));
        a = g.join("").replace(gb, "$1");
        c = c != null ? "=" + encodeURIComponent(String(c)) : "";
        (b += c) ? (c = a.indexOf("#"), c < 0 && (c = a.length), d = a.indexOf("?"), d < 0 || d > c ? (d = c, e = "") : e = a.substring(d + 1, c), c = [a.slice(0, d), e, a.slice(c)], a = c[1], c[1] = b ? a ? a + "&" + b : b : a, b = c[0] + (c[1] ? "?" + c[1] : "") + c[2]) : b = a;
        return b
    };

    function ib(a) {
        return a instanceof Xa ? a : Ya(String(a).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;"))
    }

    function jb(a) {
        var b = ib("");
        return Ya(a.map(function(c) {
            return Za(ib(c))
        }).join(Za(b).toString()))
    }
    var kb = /^[a-z][a-z\d-]*$/i,
        lb = "APPLET BASE EMBED IFRAME LINK MATH META OBJECT SCRIPT STYLE SVG TEMPLATE".split(" "),
        mb = "AREA BR COL COMMAND HR IMG INPUT KEYGEN PARAM SOURCE TRACK WBR".split(" "),
        nb = ["action", "formaction", "href"];

    function ob(a) {
        var b;
        if (!kb.test("span")) throw Error("");
        if (lb.indexOf("SPAN") !== -1) throw Error("");
        var c = "<span";
        a && (c += pb(a));
        Array.isArray(b) || (b = b === void 0 ? [] : [b]);
        mb.indexOf("SPAN") !== -1 ? c += ">" : (a = jb(b.map(function(d) {
            return d instanceof Xa ? d : ib(String(d))
        })), c += ">" + a.toString() + "</span>");
        return Ya(c)
    }

    function pb(a) {
        for (var b = "", c = r(Object, "keys").call(Object, a), d = 0; d < c.length; d++) {
            var e = c[d],
                f = a[e];
            if (!kb.test(e)) throw Error("");
            if (f !== void 0 && f !== null) {
                if (/^on./i.test(e)) throw Error("");
                nb.indexOf(e.toLowerCase()) !== -1 && (f = String(f), f = Wa.test(f) ? f : void 0, f = f || "about:invalid#zClosurez");
                e = e + '="' + ib(String(f)) + '"';
                b += " " + e
            }
        }
        return b
    };

    function qb(a) {
        var b = pa.apply(1, arguments);
        if (b.length === 0) return Ua(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return Ua(c)
    }

    function rb(a, b, c, d) {
        function e(g, h) {
            g != null && (Array.isArray(g) ? g.forEach(function(k) {
                return e(k, h)
            }) : (b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g), f = "&"))
        }
        var f = b.length ? "&" : "?";
        d.constructor === Object && (d = r(Object, "entries").call(Object, d));
        Array.isArray(d) ? d.forEach(function(g) {
            return e(g[1], g[0])
        }) : d.forEach(e);
        return Ua(a + b + c)
    };

    function sb(a) {
        try {
            var b;
            if (b = !!a && a.location.href != null) a: {
                try {
                    Ka(a.foo);
                    b = !0;
                    break a
                } catch (c) {}
                b = !1
            }
            return b
        } catch (c) {
            return !1
        }
    }

    function tb() {
        if (!q.globalThis.crypto) return Math.random();
        try {
            var a = new Uint32Array(1);
            q.globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (b) {
            return Math.random()
        }
    }

    function ub(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }
    var xb = wa(function() {
            return ya(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], vb) || Math.random() < 1E-4
        }),
        yb = wa(function() {
            return vb("MSIE")
        });

    function vb(a) {
        return Fa().indexOf(a) != -1
    }

    function H(a) {
        return /^true$/.test(a)
    }

    function zb(a, b) {
        if (!a || !b.head) return null;
        var c = Ab("META");
        b.head.appendChild(c);
        c.httpEquiv = "origin-trial";
        c.content = a;
        return c
    }

    function Ab(a, b) {
        b = b === void 0 ? document : b;
        return b.createElement(String(a).toLowerCase())
    };
    var Bb = sa("0.20"),
        Cb = sa("0.002"),
        Db = sa("1.0"),
        Eb = sa("1.0"),
        Fb = sa("0.00"),
        Gb = sa("0.00"),
        Hb = H("false"),
        Ib = H("true"),
        Jb = H("true"),
        Kb = H("true"),
        Lb = H("true"),
        Mb = H("true");
    var Nb = null;

    function Ob() {
        if (Nb === null) {
            Nb = "";
            try {
                var a = "";
                try {
                    a = B.top.location.hash
                } catch (c) {
                    a = B.location.hash
                }
                if (a) {
                    var b = a.match(/\bdeid=([\d,]+)/);
                    Nb = b ? b[1] : ""
                }
            } catch (c) {}
        }
        return Nb
    }

    function I(a, b, c) {
        var d = J;
        if (c ? d.g.hasOwnProperty(c) && d.g[c] == "" : 1) {
            var e;
            e = (e = Ob()) ? (e = e.match(new RegExp("\\b(" + a.join("|") + ")\\b"))) ? e[0] : null : null;
            if (e) a = e;
            else a: {
                if (!yb() && !xb() && (e = Math.random(), e < b)) {
                    e = tb();
                    a = a[Math.floor(e * a.length)];
                    break a
                }
                a = null
            }
            a && a != "" && (c ? d.g.hasOwnProperty(c) && (d.g[c] = a) : d.M[a] = !0)
        }
    }

    function K(a) {
        var b = J;
        return b.g.hasOwnProperty(a) ? b.g[a] : ""
    }

    function Pb() {
        var a = J,
            b = [];
        ub(a.M, function(c, d) {
            b.push(d)
        });
        ub(a.g, function(c) {
            c != "" && b.push(c)
        });
        return b
    };
    var Qb = {
            aa: 2,
            ka: 13,
            ia: 14,
            ea: 16,
            ca: 17,
            ba: 18,
            Z: 19,
            ma: 20,
            la: 21,
            Y: 22
        },
        J = null;

    function Rb() {
        return !!J && (K(20) == "466465926" || K(20) == "466465925")
    }

    function Sb() {
        return !!J && K(16) == "592230571"
    }

    function Tb() {
        return !!J && (K(22) == "512247839" || K(22) == "512247838")
    };

    function Ub(a) {
        var b = b === void 0 ? B : b;
        var c, d;
        return ((c = b.performance) == null ? void 0 : (d = c.timing) == null ? void 0 : d[a]) || 0
    };

    function Vb() {
        var a = Wb,
            b = "J";
        if (a.J && a.hasOwnProperty(b)) return a.J;
        b = new a;
        return a.J = b
    };
    var Xb = {
        fa: 0,
        V: 1,
        ga: 2,
        X: 3,
        W: 4
    };

    function Wb() {
        this.g = {}
    }

    function Yb(a, b, c) {
        typeof c === "number" && c > 0 && (a.g[b] = Math.round(c))
    }

    function Zb(a) {
        var b = Vb();
        var c = c === void 0 ? B : c;
        c = c.performance;
        Yb(b, a, c && c.now ? c.now() : null)
    }

    function $b() {
        function a() {
            return Yb(b, 0, Ub("loadEventStart") - Ub("navigationStart"))
        }
        var b = Vb();
        Ub("loadEventStart") != 0 ? a() : window.addEventListener("load", a)
    }

    function ac() {
        var a = Vb();
        return r(Object, "values").call(Object, Xb).map(function(b) {
            return [b, a.g[b] || 0]
        })
    };
    var bc = H("false");
    var cc = {};

    function dc(a) {
        cc.TAGGING = cc.TAGGING || [];
        cc.TAGGING[a] = !0
    };
    var ec = [];

    function L(a) {
        return ec[a] === void 0 ? !1 : ec[a]
    };

    function fc(a) {
        return typeof a === "function"
    }

    function gc(a) {
        return typeof a === "string"
    }

    function hc(a, b) {
        if (a && Array.isArray(a))
            for (var c = 0; c < a.length; c++)
                if (a[c] && b(a[c])) return a[c]
    }

    function ic(a, b) {
        for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(c, a[c])
    };

    function jc(a) {
        a = kc(a);
        return Ya(a)
    }

    function kc(a) {
        return a === null ? "null" : a === void 0 ? "undefined" : a
    };
    var M = window,
        N = document,
        lc = navigator,
        mc = {
            async: 1,
            nonce: 1,
            onerror: 1,
            onload: 1,
            src: 1,
            type: 1
        },
        nc = {
            onload: 1,
            src: 1,
            width: 1,
            height: 1,
            style: 1
        };

    function oc(a, b, c) {
        b && ic(b, function(d, e) {
            d = d.toLowerCase();
            c.hasOwnProperty(d) || a.setAttribute(d, e)
        })
    }

    function pc(a, b, c, d, e) {
        var f = N.createElement("script");
        oc(f, d, mc);
        f.type = "text/javascript";
        f.async = d && d.async === !1 ? !1 : !0;
        a = Ua(kc(a));
        $a(f, a);
        b && (f.onload = b);
        c && (f.onerror = c);
        e ? e.appendChild(f) : (b = N.getElementsByTagName("script")[0] || N.body || N.head, b.parentNode.insertBefore(f, b))
    }

    function qc(a, b, c) {
        var d = !1;
        d = d === void 0 ? !0 : d;
        var e = !1;
        c || (c = N.createElement("iframe"), e = !0);
        oc(c, void 0, nc);
        d && (c.height = "0", c.width = "0", c.style.display = "none", c.style.visibility = "hidden");
        a !== void 0 && (c.src = a);
        e && (a = N.body && N.body.lastChild || N.body || N.head, a.parentNode.insertBefore(c, a));
        b && (c.onload = b)
    }

    function rc(a) {
        try {
            var b = lc.sendBeacon && lc.sendBeacon(a)
        } catch (c) {
            dc(15)
        }
        b || sc(a)
    }
    var tc = {
        cache: "no-store",
        credentials: "include",
        keepalive: !0,
        method: "POST",
        mode: "no-cors",
        redirect: "follow"
    };

    function uc(a) {
        var b = {
            priority: "high"
        };
        if (typeof M.fetch === "function") {
            var c = r(Object, "assign").call(Object, {}, tc);
            b && (b.attributionReporting && (c.attributionReporting = b.attributionReporting), b.browsingTopics && (c.browsingTopics = b.browsingTopics));
            try {
                var d = M.fetch(a, c);
                if (d) return d.then(function() {}).catch(function() {}), !0
            } catch (e) {}
        }
        if (b && b.noFallback) return !1;
        rc(a);
        return !0
    }

    function vc() {
        var a = M.performance;
        if (a && a.getEntriesByType) try {
            var b = a.getEntriesByType("navigation");
            if (b && b.length > 0) var c = b[0].type
        } catch (d) {
            return "e"
        }
        if (!c) return "u";
        switch (c) {
            case "navigate":
                return "n";
            case "back_forward":
                return "h";
            case "reload":
                return "r";
            case "prerender":
                return "p";
            default:
                return "x"
        }
    }

    function sc(a) {
        var b = new Image(1, 1);
        oc(b, void 0, {});
        b.onload = function() {
            b.onload = null
        };
        b.onerror = function() {
            b.onerror = null
        };
        b.src = a
    };

    function wc() {
        var a = a === void 0 ? document : a;
        var b;
        return !((b = a.featurePolicy) == null || !(ba = b.allowedFeatures(), r(ba, "includes")).call(ba, "attribution-reporting"))
    };

    function xc(a, b, c) {
        a = yc(a, !0);
        if (a[b]) return !1;
        a[b] = [];
        a[b][0] = c;
        return !0
    }

    function yc(a, b) {
        var c = a.GooglebQhCsO;
        c || (c = {}, b && (a.GooglebQhCsO = c));
        return c
    };
    !C("Android") || Ja();
    Ja();
    C("Safari") && (Ja() || (G() ? 0 : C("Coast")) || (G() ? 0 : C("Opera")) || (G() ? 0 : C("Edge")) || (G() ? Ia("Microsoft Edge") : C("Edg/")) || G() && Ia("Opera"));
    var zc = {},
        Ac = null;

    function Bc(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            e > 255 && (b[c++] = e & 255, e >>= 8);
            b[c++] = e
        }
        a = 4;
        a === void 0 && (a = 0);
        if (!Ac)
            for (Ac = {}, c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), d = ["+/=", "+/", "-_=", "-_.", "-_"], e = 0; e < 5; e++) {
                var f = c.concat(d[e].split(""));
                zc[e] = f;
                for (var g = 0; g < f.length; g++) {
                    var h = f[g];
                    Ac[h] === void 0 && (Ac[h] = g)
                }
            }
        a = zc[a];
        c = Array(Math.floor(b.length / 3));
        d = a[64] || "";
        for (e = f = 0; f < b.length - 2; f += 3) {
            var k = b[f],
                l = b[f + 1];
            h = b[f + 2];
            g = a[k >> 2];
            k = a[(k &
                3) << 4 | l >> 4];
            l = a[(l & 15) << 2 | h >> 6];
            h = a[h & 63];
            c[e++] = g + k + l + h
        }
        g = 0;
        h = d;
        switch (b.length - f) {
            case 2:
                g = b[f + 1], h = a[(g & 15) << 2] || d;
            case 1:
                b = b[f], c[e] = a[b >> 2] + a[(b & 3) << 4 | g >> 4] + h + d
        }
        return c.join("")
    };

    function Cc(a, b, c, d, e, f) {
        var g = fb(c, "fmt");
        if (d) {
            var h = fb(c, "random"),
                k = fb(c, "label") || "";
            if (!h) return !1;
            h = Bc(decodeURIComponent(k.replace(/\+/g, " ")) + ":" + decodeURIComponent(h.replace(/\+/g, " ")));
            if (!xc(a, h, d)) return !1
        }
        g && Number(g) !== 4 && (c = hb(c, "rfmt", g));
        c = hb(c, "fmt", 4);
        pc(c, function() {
            a.google_noFurtherRedirects && d && (a.google_noFurtherRedirects = null, d())
        }, e, f, b.getElementsByTagName("script")[0].parentElement || void 0);
        return !0
    };
    var Dc = {},
        Ec = (Dc.k = {
            G: /^[\w-]+$/
        }, Dc.b = {
            G: /^[\w-]+$/,
            K: !0
        }, Dc.i = {
            G: /^[1-9]\d*$/
        }, Dc.u = {
            G: /^[1-9]\d*$/
        }, Dc);
    var Fc = {},
        Ic = (Fc[5] = {
            P: {
                2: Gc
            },
            H: ["k", "i", "b", "u"]
        }, Fc[4] = {
            P: {
                2: Gc,
                GCL: Hc
            },
            H: ["k", "i", "b"]
        }, Fc);

    function Gc(a, b) {
        var c = a.split(".");
        if (c.length === 3 && (a = {}, b = Ic[b])) {
            b = b.H;
            c = y(c[2].split("$"));
            for (var d = c.next(); !d.done; d = c.next()) {
                d = d.value;
                var e = d[0];
                if (b.indexOf(e) !== -1) try {
                    var f = decodeURIComponent(d.substring(1)),
                        g = Ec[e];
                    g && (g.K ? (a[e] = a[e] || [], a[e].push(f)) : a[e] = f)
                } catch (h) {}
            }
            return a
        }
    }

    function Hc(a) {
        a = a.split(".");
        a.shift();
        var b = a.shift(),
            c = a.shift(),
            d = {};
        return d.k = c, d.i = b, d.b = a, d
    };

    function Jc(a) {
        var b = [],
            c = N.cookie.split(";");
        a = new RegExp("^\\s*" + (a || "_gac") + "_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$");
        for (var d = 0; d < c.length; d++) {
            var e = c[d].match(a);
            e && b.push({
                L: e[1],
                value: e[2],
                timestamp: Number(e[2].split(".")[1]) || 0
            })
        }
        b.sort(function(f, g) {
            return g.timestamp - f.timestamp
        });
        return b
    }

    function Kc(a, b) {
        a = Jc(a);
        var c = {};
        if (!a || !a.length) return c;
        for (var d = 0; d < a.length; d++) {
            var e = a[d].value.split(".");
            if (!(e[0] !== "1" || b && e.length < 3 || !b && e.length !== 3) && Number(e[1])) {
                c[a[d].L] || (c[a[d].L] = []);
                var f = {
                    version: e[0],
                    timestamp: Number(e[1]) * 1E3,
                    j: e[2]
                };
                b && e.length > 3 && (f.labels = e.slice(3));
                c[a[d].L].push(f)
            }
        }
        return c
    };

    function Lc() {
        var a = {};
        var b = M.google_tag_data;
        M.google_tag_data = b === void 0 ? a : b;
        a = M.google_tag_data;
        return a.ics = a.ics || new Mc
    }

    function Mc() {
        this.entries = {};
        this.waitPeriodTimedOut = this.wasSetLate = this.accessedAny = this.accessedDefault = this.usedImplicit = this.usedUpdate = this.usedDefault = this.usedDeclare = this.active = !1;
        this.g = []
    }
    n = Mc.prototype;
    n.default = function(a, b, c, d, e, f, g) {
        this.usedDefault || this.usedDeclare || !this.accessedDefault && !this.accessedAny || (this.wasSetLate = !0);
        this.usedDefault = this.active = !0;
        dc(19);
        b == null ? dc(18) : Nc(this, a, b === "granted", c, d, e, f, g)
    };
    n.waitForUpdate = function(a, b, c) {
        for (var d = 0; d < a.length; d++) Nc(this, a[d], void 0, void 0, "", "", b, c)
    };

    function Nc(a, b, c, d, e, f, g, h) {
        var k = r(a, "entries"),
            l = k[b] || {},
            m = l.region;
        d = d && gc(d) ? d.toUpperCase() : void 0;
        e = e.toUpperCase();
        f = f.toUpperCase();
        if (e === "" || d === f || (d === e ? m !== f : !d && !m)) {
            f = !!(g && g > 0 && l.update === void 0);
            var p = {
                region: d,
                declare_region: l.declare_region,
                implicit: l.implicit,
                default: c !== void 0 ? c : l.default,
                declare: l.declare,
                update: l.update,
                quiet: f
            };
            if (e !== "" || l.default !== !1) k[b] = p;
            f && M.setTimeout(function() {
                    k[b] === p && p.quiet && (dc(2), a.waitPeriodTimedOut = !0, a.clearTimeout(b, void 0, h), a.notifyListeners())
                },
                g)
        }
    }
    n.clearTimeout = function(a, b, c) {
        var d = [a],
            e = c.delegatedConsentTypes,
            f;
        for (f in e) e.hasOwnProperty(f) && e[f] === a && d.push(f);
        e = r(this, "entries")[a] || {};
        a = this.getConsentState(a, c);
        if (e.quiet)
            for (e.quiet = !1, b = y(d), d = b.next(); !d.done; d = b.next()) Oc(this, d.value);
        else if (b !== void 0 && a !== b)
            for (b = y(d), d = b.next(); !d.done; d = b.next()) Oc(this, d.value)
    };
    n.update = function(a, b, c) {
        this.usedDefault || this.usedDeclare || this.usedUpdate || !this.accessedAny || (this.wasSetLate = !0);
        this.usedUpdate = this.active = !0;
        if (b != null) {
            var d = this.getConsentState(a, c),
                e = r(this, "entries");
            (e[a] = e[a] || {}).update = b === "granted";
            this.clearTimeout(a, d, c)
        }
    };
    n.declare = function(a, b, c, d, e) {
        this.usedDeclare = this.active = !0;
        var f = r(this, "entries"),
            g = f[a] || {},
            h = g.declare_region;
        c = c && gc(c) ? c.toUpperCase() : void 0;
        d = d.toUpperCase();
        e = e.toUpperCase();
        if (d === "" || c === e || (c === d ? h !== e : !c && !h))
            if (b = {
                    region: g.region,
                    declare_region: c,
                    declare: b === "granted",
                    implicit: g.implicit,
                    default: g.default,
                    update: g.update,
                    quiet: g.quiet
                }, d !== "" || g.declare !== !1) f[a] = b
    };
    n.implicit = function(a, b) {
        this.usedImplicit = !0;
        var c = r(this, "entries");
        a = c[a] = c[a] || {};
        a.implicit !== !1 && (a.implicit = b === "granted")
    };
    n.getConsentState = function(a, b) {
        var c = r(this, "entries"),
            d = c[a] || {},
            e = d.update;
        if (e !== void 0) return e ? 1 : 2;
        if (b.usedContainerScopedDefaults) {
            e = b.containerScopedDefaults[a];
            if (e === 3) return 1;
            if (e === 2) return 2
        } else if (e = d.default, e !== void 0) return e ? 1 : 2;
        if (b == null ? 0 : b.delegatedConsentTypes.hasOwnProperty(a)) {
            a = b.delegatedConsentTypes[a];
            c = c[a] || {};
            e = c.update;
            if (e !== void 0) return e ? 1 : 2;
            if (b.usedContainerScopedDefaults) {
                b = b.containerScopedDefaults[a];
                if (b === 3) return 1;
                if (b === 2) return 2
            } else if (e = c.default,
                e !== void 0) return e ? 1 : 2
        }
        e = d.declare;
        if (e !== void 0) return e ? 1 : 2;
        e = d.implicit;
        return e !== void 0 ? e ? 3 : 4 : 0
    };
    n.addListener = function(a, b) {
        this.g.push({
            consentTypes: a,
            R: b
        })
    };

    function Oc(a, b) {
        for (var c = 0; c < a.g.length; ++c) {
            var d = a.g[c];
            Array.isArray(d.consentTypes) && d.consentTypes.indexOf(b) !== -1 && (d.O = !0)
        }
    }
    n.notifyListeners = function(a, b) {
        for (var c = 0; c < this.g.length; ++c) {
            var d = this.g[c];
            if (d.O) {
                d.O = !1;
                try {
                    d.R({
                        consentEventId: a,
                        consentPriorityId: b
                    })
                } catch (e) {}
            }
        }
    };
    var Pc = {},
        Qc = {
            delegatedConsentTypes: {},
            corePlatformServices: {},
            usedCorePlatformServices: !1,
            selectedAllCorePlatformServices: !1,
            containerScopedDefaults: (Pc.ad_storage = 1, Pc.analytics_storage = 1, Pc.ad_user_data = 1, Pc.ad_personalization = 1, Pc),
            usedContainerScopedDefaults: !1
        };

    function Rc(a) {
        var b = Lc();
        b.accessedAny = !0;
        return (gc(a) ? [a] : a).every(function(c) {
            switch (b.getConsentState(c, Qc)) {
                case 1:
                case 3:
                    return !0;
                case 2:
                case 4:
                    return !1;
                default:
                    return !0
            }
        })
    }

    function Sc(a) {
        var b = Lc();
        b.accessedAny = !0;
        return !(r(b, "entries")[a] || {}).quiet
    }

    function Uc(a, b) {
        Lc().addListener(a, b)
    }

    function Vc(a, b) {
        function c() {
            for (var e = 0; e < b.length; e++)
                if (!Sc(b[e])) return !0;
            return !1
        }
        if (c()) {
            var d = !1;
            Uc(b, function(e) {
                d || c() || (d = !0, a(e))
            })
        } else a({})
    }

    function Wc(a, b) {
        function c() {
            for (var g = [], h = 0; h < e.length; h++) {
                var k = e[h];
                Rc(k) && !f[k] && g.push(k)
            }
            return g
        }

        function d(g) {
            for (var h = 0; h < g.length; h++) f[g[h]] = !0
        }
        var e = gc(b) ? [b] : b,
            f = {};
        b = c();
        b.length !== e.length && (d(b), Uc(e, function(g) {
            function h(m) {
                m.length !== 0 && (d(m), g.consentTypes = m, a(g))
            }
            var k = c();
            if (k.length !== 0) {
                var l = r(Object, "keys").call(Object, f).length;
                k.length + l >= e.length ? h(k) : M.setTimeout(function() {
                    h(c())
                }, 500)
            }
        }))
    };
    var Xc = /:[0-9]+$/;

    function Yc(a, b) {
        a = y(a.split("&"));
        for (var c = a.next(); !c.done; c = a.next()) {
            var d = y(c.value.split("="));
            c = d.next().value;
            for (var e, f = []; !(e = d.next()).done;) f.push(e.value);
            d = f;
            if (decodeURIComponent(c.replace(/\+/g, " ")) === b) return decodeURIComponent(d.join("=").replace(/\+/g, " "))
        }
    }

    function Zc(a, b) {
        var c = "query";
        var d = (d = a.protocol) ? d.replace(":", "").toLowerCase() : "";
        c && (c = String(c).toLowerCase());
        switch (c) {
            case "url_no_fragment":
                b = "";
                a && a.href && (b = a.href.indexOf("#"), b = b < 0 ? a.href : a.href.substring(0, b));
                a = b;
                break;
            case "protocol":
                a = d;
                break;
            case "host":
                a = a.hostname.replace(Xc, "").toLowerCase();
                break;
            case "port":
                a = String(Number(a.port) || (d === "http" ? 80 : d === "https" ? 443 : ""));
                break;
            case "path":
                a.pathname || a.hostname || dc(1);
                a = a.pathname.charAt(0) === "/" ? a.pathname : "/" + a.pathname;
                a = a.split("/");
                [].indexOf(a[a.length - 1]) >= 0 && (a[a.length - 1] = "");
                a = a.join("/");
                break;
            case "query":
                a = a.search.replace("?", "");
                b && (a = Yc(a, b));
                break;
            case "extension":
                a = a.pathname.split(".");
                a = a.length > 1 ? a[a.length - 1] : "";
                a = a.split("/")[0];
                break;
            case "fragment":
                a = a.hash.replace("#", "");
                break;
            default:
                a = a && a.href
        }
        return a
    }
    var $c = {},
        ad = 0;

    function bd(a) {
        for (var b = 0; b < 3; ++b) try {
            var c = decodeURIComponent(a).replace(/\+/g, " ");
            if (c === a) break;
            a = c
        } catch (d) {
            return ""
        }
        return a
    };

    function cd(a, b, c, d) {
        if (dd(d)) {
            d = [];
            b = String(b || ed()).split(";");
            for (var e = 0; e < b.length; e++) {
                var f = b[e].split("="),
                    g = f[0].replace(/^\s*|\s*$/g, "");
                g && g === a && ((f = f.slice(1).join("=").replace(/^\s*|\s*$/g, "")) && c && (f = decodeURIComponent(f)), d.push(f))
            }
            a = d
        } else a = [];
        return a
    }

    function fd(a, b, c, d) {
        var e = ed(),
            f = window;
        f.origin !== "null" && (f.document.cookie = a);
        a = ed();
        return e !== a || c !== void 0 && cd(b, a, !1, d).indexOf(c) >= 0
    }

    function gd(a, b, c) {
        function d(p, t, u) {
            if (u == null) return delete g[t], p;
            g[t] = u;
            return p + "; " + t + "=" + u
        }

        function e(p, t) {
            if (t == null) return p;
            g[t] = !0;
            return p + "; " + t
        }
        if (dd(c.D)) {
            if (b == null) var f = a + "=deleted; expires=" + (new Date(0)).toUTCString();
            else c.encode && (b = encodeURIComponent(b)), b = hd(b), f = a + "=" + b;
            var g = {};
            f = d(f, "path", c.path);
            if (c.expires instanceof Date) var h = c.expires.toUTCString();
            else c.expires != null && (h = c.expires);
            f = d(f, "expires", h);
            f = d(f, "max-age", c.na);
            f = d(f, "samesite", c.oa);
            c.pa && (f = e(f, "secure"));
            if ((h = c.domain) && h.toLowerCase() === "auto") {
                h = id();
                for (var k = 0; k < h.length; ++k) {
                    var l = h[k] !== "none" ? h[k] : void 0,
                        m = d(f, "domain", l);
                    m = e(m, c.flags);
                    if (!jd(l, c.path) && fd(m, a, b, c.D)) break
                }
            } else h && h.toLowerCase() !== "none" && (f = d(f, "domain", h)), f = e(f, c.flags), jd(h, c.path) || fd(f, a, b, c.D)
        }
    }

    function kd(a, b, c) {
        c.path == null && (c.path = "/");
        c.domain || (c.domain = "auto");
        gd(a, b, c)
    }

    function hd(a) {
        a && a.length > 1200 && (a = a.substring(0, 1200));
        return a
    }
    var ld = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
        md = /(^|\.)doubleclick\.net$/i;

    function jd(a, b) {
        return a !== void 0 && (md.test(window.document.location.hostname) || b === "/" && ld.test(a))
    }

    function ed() {
        return window.origin !== "null" ? window.document.cookie : ""
    }

    function dd(a) {
        return a && L(10) ? (Array.isArray(a) ? a : [a]).every(function(b) {
            return Sc(b) && Rc(b)
        }) : !0
    }

    function id() {
        var a = [],
            b = window.document.location.hostname.split(".");
        if (b.length === 4) {
            var c = b[b.length - 1];
            if (Number(c).toString() === c) return ["none"]
        }
        for (c = b.length - 2; c >= 0; c--) a.push(b.slice(c).join("."));
        b = window.document.location.hostname;
        md.test(b) || ld.test(b) || a.push("none");
        return a
    };

    function nd(a, b, c, d) {
        var e, f = Number(a.N != null ? a.N : void 0);
        f !== 0 && (e = new Date((b || (new Date(Date.now())).getTime()) + 1E3 * (f || 7776E3)));
        return {
            path: a.path,
            domain: a.domain,
            flags: a.flags,
            encode: !!c,
            expires: e,
            D: d
        }
    };
    var od = new q.Map([
        [5, "ad_storage"],
        [4, ["ad_storage", "ad_user_data"]]
    ]);

    function pd(a) {
        if (Ic[5]) {
            var b = [];
            a = cd(a, void 0, void 0, od.get(5));
            a = y(a);
            for (var c = a.next(); !c.done; c = a.next()) {
                a: {
                    c = c.value;
                    var d = Ic[5];
                    if (d) {
                        var e = c.split(".")[0];
                        if (e && (d = d.P[e])) {
                            c = d(c, 5);
                            break a
                        }
                    }
                    c = void 0
                }
                c && (qd(c), b.push(c))
            }
            return b
        }
    }

    function rd(a, b, c, d) {
        c = c || {};
        var e;
        if (e = c.domain) {
            var f = e;
            L(9) && e === "none" && (f = window.document.location.hostname);
            f = f.indexOf(".") === 0 ? f.substring(1) : f;
            e = f.split(".").length
        } else e = 1;
        e = "" + e;
        (f = c.path) && f !== "/" ? (f[0] !== "/" && (f = "/" + f), f[f.length - 1] !== "/" && (f += "/"), f = f.split("/").length - 1) : f = 1;
        f > 1 && (e += "-" + f);
        var g = Ic[5];
        if (g) {
            f = [];
            g = y(g.H);
            for (var h = g.next(); !h.done; h = g.next()) {
                h = h.value;
                var k = Ec[h];
                if (k) {
                    var l = b[h];
                    if (l !== void 0)
                        if (k.K && Array.isArray(l))
                            for (k = y(l), l = k.next(); !l.done; l = k.next()) f.push(encodeURIComponent(h +
                                l.value));
                        else f.push(encodeURIComponent(h + l))
                }
            }
            b = ["2", e || "1", f.join("$")].join(".")
        } else b = void 0;
        b && (c = nd(c, d, void 0, od.get(5)), kd(a, b, c))
    }

    function sd(a, b) {
        b = b.G;
        return typeof b === "function" ? b(a) : b.test(a)
    }

    function qd(a) {
        for (var b = y(r(Object, "keys").call(Object, a)), c = b.next(), d = {}; !c.done; d = {
                B: void 0
            }, c = b.next()) {
            c = c.value;
            var e = a[c];
            d.B = Ec[c];
            d.B ? d.B.K ? a[c] = Array.isArray(e) ? e.filter(function(f) {
                return function(g) {
                    return sd(g, f.B)
                }
            }(d)) : void 0 : typeof e === "string" && sd(e, d.B) || (a[c] = void 0) : a[c] = void 0
        }
    };
    var td = ["ad_storage", "ad_user_data"];

    function ud() {
        var a = vd();
        if (a.error) return a;
        if (!a.value) return {
            error: 2
        };
        try {
            var b = a.value.gclid
        } catch (c) {
            return {
                error: 11
            }
        }
        return b ? {
            value: b
        } : {
            value: void 0
        }
    }

    function vd() {
        if (!Rc(td)) return {
            error: 3
        };
        try {
            if (!M.localStorage) return {
                error: 1
            }
        } catch (d) {
            return {
                error: 14
            }
        }
        var a = {
                schema: "gcl",
                version: 1
            },
            b = void 0;
        try {
            b = M.localStorage.getItem("_gcl_ls")
        } catch (d) {
            return {
                error: 13
            }
        }
        try {
            if (b) {
                var c = JSON.parse(b);
                if (c && typeof c === "object") a = c;
                else return {
                    error: 12
                }
            }
        } catch (d) {
            return {
                error: 8
            }
        }
        if (a.schema !== "gcl") return {
            error: 4
        };
        if (a.version !== 1) return {
            error: 5
        };
        try {
            wd(a)
        } catch (d) {
            return {
                error: 8
            }
        }
        return {
            value: a,
            error: 0
        }
    }

    function wd(a) {
        if (a && typeof a === "object")
            if ("expires" in a && "value" in a) {
                var b;
                typeof a.expires === "number" ? b = a.expires : b = typeof a.expires === "string" ? Number(a.expires) : NaN;
                !isNaN(b) && Date.now() <= b || (a.value = null, a.error = 9)
            } else {
                b = y(r(Object, "keys").call(Object, a));
                for (var c = b.next(); !c.done; c = b.next()) wd(a[c.value])
            }
    };
    var xd = /^\w+$/,
        O = /^[\w-]+$/,
        Q = {},
        yd = (Q.aw = "_aw", Q.dc = "_dc", Q.gf = "_gf", Q.gp = "_gp", Q.gs = "_gs", Q.ha = "_ha", Q.ag = "_ag", Q.gb = "_gb", Q);

    function R() {
        return ["ad_storage", "ad_user_data"]
    }

    function T(a) {
        return !L(10) || Rc(a)
    }

    function zd(a) {
        function b() {
            var d = T(c);
            d && a();
            return d
        }
        var c = R();
        Vc(function() {
            b() || Wc(b, c)
        }, c)
    }

    function Ad(a) {
        return U(a).map(function(b) {
            return b.j
        })
    }

    function Bd(a) {
        function b(d) {
            return function(e) {
                e.type = d;
                return e
            }
        }
        var c = Cd(a.prefix);
        a = V("gb", c);
        c = V("ag", c);
        if (!c || !a) return [];
        a = U(a).map(b("gb"));
        c = Dd(c).map(b("ag"));
        return a.concat(c).sort(function(d, e) {
            return e.timestamp - d.timestamp
        })
    }

    function Ed(a, b, c, d, e, f) {
        var g = hc(a, function(h) {
            return h.j === c
        });
        g ? (g.timestamp < d && (g.timestamp = d, g.C = f), g.labels = Fd(g.labels || [], e || [])) : a.push({
            version: b,
            j: c,
            timestamp: d,
            labels: e,
            C: f
        })
    }

    function Dd(a) {
        var b = pd(a) || [];
        a = [];
        b = y(b);
        for (var c = b.next(); !c.done; c = b.next()) {
            var d = c = c.value,
                e = d.k;
            d = d.b;
            var f = c ? (Number(c.i) || 0) * 1E3 : 0;
            if (f) {
                var g = void 0;
                L(11) && (g = c.u);
                Ed(a, "2", e, f, d || [], g)
            }
        }
        return a.sort(function(h, k) {
            return k.timestamp - h.timestamp
        })
    }

    function U(a) {
        var b = [];
        a = cd(a, N.cookie, void 0, R());
        a = y(a);
        for (var c = a.next(); !c.done; c = a.next()) c = Gd(c.value), c != null && Ed(b, c.version, c.j, c.timestamp, c.labels);
        b.sort(function(d, e) {
            return e.timestamp - d.timestamp
        });
        return Hd(b)
    }

    function Id(a, b) {
        var c = [];
        a = y(a);
        for (var d = a.next(); !d.done; d = a.next()) d = d.value, r(c, "includes").call(c, d) || c.push(d);
        b = y(b);
        for (a = b.next(); !a.done; a = b.next()) a = a.value, r(c, "includes").call(c, a) || c.push(a);
        return c
    }

    function Jd(a, b) {
        var c = hc(a, function(d) {
            return d.j === b.j
        });
        c ? (c.timestamp < b.timestamp && (c.timestamp = b.timestamp, c.C = b.C), c.m = c.m ? b.m ? c.timestamp < b.timestamp ? b.m : c.m : c.m || 0 : b.m || 0, c.labels = Id(c.labels || [], b.labels || []), c.A = Id(c.A || [], b.A || [])) : a.push(b)
    }

    function Kd() {
        var a = ud();
        if (!a || a.error || !a.value || typeof a.value !== "object") return null;
        a = a.value;
        try {
            if (!("value" in a && a.value) || typeof a.value !== "object") return null;
            var b = a.value,
                c = b.value;
            return c && c.match(O) ? {
                version: "",
                j: c,
                timestamp: Number(b.creationTimeMs) || 0,
                labels: [],
                m: b.linkDecorationSource || 0,
                A: [2]
            } : null
        } catch (d) {
            return null
        }
    }

    function Ld(a) {
        var b = [];
        a = cd(a, N.cookie, void 0, R());
        a = y(a);
        for (var c = a.next(); !c.done; c = a.next()) c = Gd(c.value), c != null && (c.C = void 0, c.m = 0, c.A = [1], Jd(b, c));
        if (a = Kd()) a.C = void 0, a.m = a.m || 0, a.A = a.A || [2], Jd(b, a);
        b.sort(function(d, e) {
            return e.timestamp - d.timestamp
        });
        return Hd(b)
    }

    function Fd(a, b) {
        if (!a.length) return b;
        if (!b.length) return a;
        var c = {};
        return a.concat(b).filter(function(d) {
            return c.hasOwnProperty(d) ? !1 : c[d] = !0
        })
    }

    function Cd(a) {
        return a && typeof a === "string" && a.match(xd) ? a : "_gcl"
    }

    function Md(a, b) {
        var c = $c[a];
        if (!c) {
            c = N.createElement("a");
            a && (c.href = a);
            var d = c.pathname;
            d[0] !== "/" && (a || dc(1), d = "/" + d);
            var e = c.hostname.replace(Xc, "");
            c = {
                href: c.href,
                protocol: c.protocol,
                host: c.host,
                hostname: e,
                pathname: d,
                search: c.search,
                hash: c.hash,
                port: c.port
            };
            ad < 5 && ($c[a] = c, ad++)
        }
        d = c;
        a = Zc(d, "gclid");
        c = Zc(d, "gclsrc");
        e = Zc(d, "wbraid");
        if (e) {
            var f = e;
            if (L(3)) try {
                f = decodeURIComponent(e)
            } catch (k) {}
            f = f.split(",");
            e = f.length === 2 && f[0] === f[1] ? f[0] : e
        }
        f = Zc(d, "gbraid");
        var g = Zc(d, "gad_source"),
            h = Zc(d, "dclid");
        !b || a && c && e && f || (b = d.hash.replace("#", ""), a = a || Yc(b, "gclid"), c = c || Yc(b, "gclsrc"), e = e || Yc(b, "wbraid"), f = f || Yc(b, "gbraid"), g = g || Yc(b, "gad_source"));
        return Nd(a, c, h, e, f, g)
    }

    function Nd(a, b, c, d, e, f) {
        function g(k, l) {
            h[l] || (h[l] = []);
            h[l].push(k)
        }
        var h = {};
        h.gclid = a;
        h.gclsrc = b;
        h.dclid = c;
        if (a !== void 0 && a.match(O)) switch (b) {
            case void 0:
                g(a, "aw");
                break;
            case "aw.ds":
                g(a, "aw");
                g(a, "dc");
                break;
            case "ds":
                g(a, "dc");
                break;
            case "3p.ds":
                g(a, "dc");
                break;
            case "gf":
                g(a, "gf");
                break;
            case "ha":
                g(a, "ha")
        }
        c && g(c, "dc");
        d !== void 0 && O.test(d) && (h.wbraid = d, g(d, "gb"));
        e !== void 0 && O.test(e) && (h.gbraid = e, g(e, "ag"));
        f !== void 0 && O.test(f) && (h.gad_source = f, g(f, "gs"));
        return h
    }

    function Od(a, b, c, d, e) {
        function f() {
            if (T(l)) {
                var t = nd(c, h, !0);
                t.D = l;
                for (var u = function(z, D) {
                        var Oa = V(z, g);
                        Oa && (kd(Oa, D, t), z !== "gb" && (m = !0))
                    }, v = function(z) {
                        z = ["GCL", k, z];
                        e.length > 0 && z.push(e.join("."));
                        return z.join(".")
                    }, Y = y(["aw", "dc", "gf", "ha", "gp"]), P = Y.next(); !P.done; P = Y.next()) P = P.value, a[P] && u(P, v(a[P][0]));
                if (!m && a.gb) {
                    var Pa = a.gb[0];
                    Y = V("gb", g);
                    !b && U(Y).some(function(z) {
                        return z.j === Pa && z.labels && z.labels.length > 0
                    }) || u("gb", v(Pa))
                }
            }
            if (!p && a.gbraid && T("ad_storage") && (p = !0, !m)) {
                var Qa = a.gbraid;
                u = V("ag", g);
                if (b || !Dd(u).some(function(z) {
                        return z.j === Qa && z.labels && z.labels.length > 0
                    })) v = {}, v = (v.k = Qa, v.i = "" + k, v.b = e, v), rd(u, v, c, h)
            }
            Pd(a, g, h, c)
        }
        c = c || {};
        e = e || [];
        var g = Cd(c.prefix),
            h = d || (new Date(Date.now())).getTime(),
            k = Math.round(h / 1E3),
            l = R(),
            m = !1,
            p = !1;
        Vc(function() {
            f();
            T(l) || Wc(f, l)
        }, l)
    }

    function Pd(a, b, c, d) {
        if (a.gad_source !== void 0 && T("ad_storage")) {
            if (L(5)) {
                var e = vc();
                if (e === "r" || e === "h") return
            }
            a = a.gad_source;
            if (b = V("gs", b)) {
                e = (e = M.performance) && fc(e.now) ? e.now() : void 0;
                e = Math.round(((new Date(Date.now())).getTime() - (e || 0)) / 1E3);
                if (L(11)) {
                    var f = M.location.hostname;
                    var g = M.location.pathname;
                    f = bd(f);
                    f.split(".").length > 2 && (f = f.replace(/^(www[0-9]*|web|ftp|wap|home|m|w|amp|mobile)\./, ""));
                    g = bd(g);
                    g = g.split(";")[0];
                    g = g.replace(/\/(ar|slp|web|index)?\/?$/, "");
                    g = (f + g).toLowerCase();
                    f =
                        1;
                    var h;
                    if (g)
                        for (f = 0, h = g.length - 1; h >= 0; h--) {
                            var k = g.charCodeAt(h);
                            f = (f << 6 & 268435455) + k + (k << 14);
                            k = f & 266338304;
                            f = k !== 0 ? f ^ k >> 21 : f
                        }
                    g = String(f);
                    f = {};
                    a = (f.k = a, f.i = "" + e, f.u = g, f)
                } else g = {}, a = (g.k = a, g.i = "" + e, g);
                rd(b, a, d, c)
            }
        }
    }

    function V(a, b) {
        a = yd[a];
        if (a !== void 0) return b + a
    }

    function Qd(a) {
        return Rd(a.split(".")).length !== 0 ? (Number(a.split(".")[1]) || 0) * 1E3 : 0
    }

    function Gd(a) {
        a = Rd(a.split("."));
        return a.length === 0 ? null : {
            version: a[0],
            j: a[2],
            timestamp: (Number(a[1]) || 0) * 1E3,
            labels: a.slice(3)
        }
    }

    function Rd(a) {
        return a.length < 3 || a[0] !== "GCL" && a[0] !== "1" || !/^\d+$/.test(a[1]) || !O.test(a[2]) ? [] : a
    }

    function Hd(a) {
        return a.filter(function(b) {
            return O.test(b.j)
        })
    }

    function Sd() {
        var a = ["aw"],
            b = {};
        if (M.origin !== "null") {
            for (var c = Cd(b.prefix), d = {}, e = 0; e < a.length; e++) yd[a[e]] && (d[a[e]] = yd[a[e]]);
            zd(function() {
                ic(d, function(f, g) {
                    g = cd(c + g, N.cookie, void 0, R());
                    g.sort(function(m, p) {
                        return Qd(p) - Qd(m)
                    });
                    if (g.length) {
                        var h = g[0];
                        g = Qd(h);
                        var k = Rd(h.split(".")).length !== 0 ? h.split(".").slice(3) : [],
                            l = {};
                        h = Rd(h.split(".")).length !== 0 ? h.split(".")[2] : void 0;
                        l[f] = [h];
                        Od(l, !0, b, g, k)
                    }
                })
            })
        }
    }

    function Td(a, b, c, d) {
        var e = [];
        c = c || {};
        if (!T(R())) return e;
        var f = U(a);
        var g = [];
        if (f.length !== 0)
            for (var h = {}, k = 0; k < f.length; k++) {
                var l = f[k],
                    m = l.type ? l.type : "gcl";
                (l.labels || []).indexOf(b) === -1 ? (e.push(0), h[m] || g.push(l)) : e.push(1);
                h[m] = !0
            }
        if (g.length && !d)
            for (d = y(g), f = d.next(); !f.done; f = d.next()) g = f.value, f = g.timestamp, g = [g.version, Math.round(f / 1E3), g.j].concat(g.labels || [], [b]).join("."), f = nd(c, f, !0), f.D = R(), kd(a, g, f);
        return e
    }

    function Ud(a, b) {
        b = Cd(b);
        b = V(a, b);
        if (!b) return 0;
        a = a === "ag" ? Dd(b) : U(b);
        for (var c = b = 0; c < a.length; c++) b = Math.max(b, a[c].timestamp);
        return b
    }

    function Vd(a) {
        for (var b = 0, c = y(r(Object, "keys").call(Object, a)), d = c.next(); !d.done; d = c.next()) {
            d = a[d.value];
            for (var e = 0; e < d.length; e++) b = Math.max(b, Number(d[e].timestamp))
        }
        return b
    };
    var Wd = RegExp("^UA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*(?:%3BUA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*)*$"),
        Xd = /^~?[\w-]+(?:\.~?[\w-]+)*$/,
        Yd = /^\d+\.fls\.doubleclick\.net$/,
        Zd = /;gac=([^;?]+)/,
        $d = /;gacgb=([^;?]+)/;

    function ae(a, b, c) {
        if (Yd.test(a.location.host)) return (b = a.location.href.match(c)) && b.length === 2 && b[1].match(Wd) ? decodeURIComponent(b[1]) : "";
        a = [];
        c = y(r(Object, "keys").call(Object, b));
        for (var d = c.next(); !d.done; d = c.next()) {
            d = d.value;
            for (var e = [], f = b[d], g = 0; g < f.length; g++) e.push(f[g].j);
            a.push(d + ":" + e.join(","))
        }
        return a.length > 0 ? a.join(";") : ""
    }

    function be(a, b, c, d) {
        for (var e = T(R()) ? Kc("_gac_gb", !0) : {}, f = [], g = !1, h = y(r(Object, "keys").call(Object, e)), k = h.next(); !k.done; k = h.next()) {
            k = k.value;
            var l = Td("_gac_gb_" + k, b, c, d);
            g = g || l.length !== 0 && l.some(function(m) {
                return m === 1
            });
            f.push(k + ":" + l.join(","))
        }
        return {
            T: g ? f.join(";") : "",
            S: ae(a, e, $d)
        }
    }

    function ce(a, b) {
        return (a = a.location.href.match(new RegExp(";" + b + "=([^;?]+)"))) && a.length === 2 && a[1].match(Xd) ? a[1] : void 0
    }

    function de(a, b, c, d) {
        var e = e === void 0 ? !1 : e;
        if (Yd.test(a.location.host)) {
            if (e = ce(a, d)) return [{
                j: e
            }]
        } else {
            if (c === "gclid") return a = (b || "_gcl") + "_aw", e ? Ld(a) : U(a);
            if (c === "wbraid") return U((b || "_gcl") + "_gb");
            if (c === "braids") return Bd({
                prefix: b
            })
        }
        return []
    }

    function ee(a, b) {
        return de(a, b, "gclid", "gclaw").map(function(c) {
            return c.j
        }).join(".")
    }

    function fe(a, b) {
        return de(a, b, "wbraid", "gclgb").map(function(c) {
            return c.j
        }).join(".")
    }

    function ge(a) {
        if (Ad("_gcl_aw").length === 0 && (!a || Ad(a + "_aw").length === 0)) {
            a = Md(M.location.href, !0);
            if (L(7)) {
                for (var b = !0, c = y(r(Object, "keys").call(Object, a)), d = c.next(); !d.done; d = c.next())
                    if (a[d.value] !== void 0) {
                        b = !1;
                        break
                    }
                b && (a = Md(M.document.referrer, !1), a.gad_source = void 0)
            }
            Od(a, !1, {});
            Sd()
        }
    }

    function he(a, b, c) {
        a = Td((b && b.prefix || "_gcl") + "_gb", a, b, c);
        return a.length === 0 || a.every(function(d) {
            return d === 0
        }) ? "" : a.join(".")
    };

    function ie() {
        var a = M.__uspapi;
        if (fc(a)) {
            var b = "";
            try {
                a("getUSPData", 1, function(c, d) {
                    d && c && (c = c.uspString) && RegExp("^[\\da-zA-Z-]{1,20}$").test(c) && (b = c)
                })
            } catch (c) {}
            return b
        }
    };
    var je = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function ke(a) {
        var b;
        return (b = a.google_tag_data) != null ? b : a.google_tag_data = {}
    }

    function le(a) {
        a = a.google_tag_data;
        if (a != null && a.uach) {
            a = a.uach;
            var b = r(Object, "assign").call(Object, {}, a);
            a.fullVersionList && (b.fullVersionList = a.fullVersionList.slice(0));
            a = b
        } else a = null;
        return a
    }

    function me(a) {
        var b, c;
        return typeof((b = a.navigator) == null ? void 0 : (c = b.userAgentData) == null ? void 0 : c.getHighEntropyValues) === "function"
    }

    function ne() {
        var a = window;
        if (me(a)) {
            var b = ke(a);
            b.uach_promise || (a = a.navigator.userAgentData.getHighEntropyValues(je).then(function(c) {
                b.uach != null || (b.uach = c);
                return c
            }), b.uach_promise = a)
        }
    };
    var oe = /^[a-zA-Z0-9_]+$/,
        pe = !1,
        qe = "google_conversion_id google_conversion_format google_conversion_type google_conversion_order_id google_conversion_language google_conversion_value google_conversion_currency google_conversion_domain google_conversion_label google_conversion_color google_disable_viewthrough google_enable_display_cookie_match google_gtag_event_data google_remarketing_only google_conversion_linker google_tag_for_child_directed_treatment google_tag_for_under_age_of_consent google_allow_ad_personalization_signals google_restricted_data_processing google_conversion_items google_conversion_merchant_id google_user_id google_custom_params google_conversion_date google_conversion_time google_conversion_js_version onload_callback opt_image_generator google_gtm_url_processor google_conversion_page_url google_conversion_referrer_url google_gcl_cookie_prefix google_gcl_cookie_path google_gcl_cookie_flags google_gcl_cookie_domain google_gcl_cookie_max_age_seconds google_read_gcl_cookie_opt_out google_basket_feed_country google_basket_feed_language google_basket_discount google_basket_transaction_type google_additional_conversion_params google_additional_params google_transport_url google_gtm_experiments".split(" "),
        re = ["google_conversion_first_time", "google_conversion_snippets"];

    function W(a) {
        return a != null ? encodeURIComponent(String(a)) : ""
    }

    function se(a) {
        if (a != null) {
            a = String(a).substring(0, 512);
            var b = a.indexOf("#");
            return b == -1 ? a : a.substring(0, b)
        }
        return ""
    }

    function X(a, b) {
        b = W(b);
        return b != "" && (a = W(a), a != "") ? "&".concat(a, "=", b) : ""
    }

    function te(a) {
        var b = typeof a;
        return a == null || b == "object" || b == "function" ? null : String(a).replace(/,/g, "\\,").replace(/;/g, "\\;").replace(/=/g, "\\=")
    }

    function ue(a) {
        if (!a || typeof a != "object" || typeof a.join == "function") return "";
        var b = [],
            c;
        for (c in a)
            if (Object.prototype.hasOwnProperty.call(a, c)) {
                var d = a[c];
                if (d && typeof d.join === "function") {
                    for (var e = [], f = 0; f < d.length; ++f) {
                        var g = te(d[f]);
                        g != null && e.push(g)
                    }
                    d = e.length == 0 ? null : e.join(",")
                } else d = te(d);
                (e = te(c)) && d != null && b.push(e + "=" + d)
            }
        return b.join(";")
    }

    function ve(a) {
        return typeof a != "number" && typeof a != "string" ? "" : W(a.toString())
    }

    function we(a, b) {
        if (b.google_read_gcl_cookie_opt_out || b.google_remarketing_only || b.google_conversion_domain && (!b.google_gcl_cookie_prefix || !/^_ycl/.test(b.google_gcl_cookie_prefix))) return "";
        var c = "";
        var d = b.google_gcl_cookie_prefix && b.google_gcl_cookie_prefix !== "_gcl" && oe.test(b.google_gcl_cookie_prefix) ? b.google_gcl_cookie_prefix : "";
        var e = {};
        b.google_gcl_cookie_domain && (e.domain = b.google_gcl_cookie_domain);
        b.google_gcl_cookie_flags && (e.flags = b.google_gcl_cookie_flags);
        b.google_gcl_cookie_max_age_seconds !=
            null && (e.N = b.google_gcl_cookie_max_age_seconds);
        b.google_gcl_cookie_path && (e.path = b.google_gcl_cookie_path);
        d && (e.prefix = d);
        if (xe(b) && b.I) var f = b.F === void 0;
        else Yd.test(a.location.host) ? f = !(ce(a, "gclaw") || ce(a, "gac")) : (f = Math.max(Ud("aw", d), Vd(T(R()) ? Kc() : {})), f = Math.max(Ud("gb", d), Vd(T(R()) ? Kc("_gac_gb", !0) : {})) > f);
        if (f) {
            if (b.F !== void 0) return b.F;
            c = fe(a, d || void 0);
            f = b.google_conversion_label;
            var g = he(f, e, b.I);
            c = X("gclgb", c) + (g ? X("mcov", g) : "");
            if (d) return b.F = c;
            d = be(a, f, e, b.I);
            a = d.S;
            d = d.T;
            c += (a ?
                X("gacgb", a) : "") + (d ? X("gacmcov", d) : "");
            return b.F = c
        }
        if (d) return b = ee(a, d), X("gclaw", b);
        (b = ee(a)) && (c = X("gclaw", b));
        b = ae(a, T(R()) ? Kc() : {}, Zd);
        return c + (b ? X("gac", b) : "")
    }

    function ye(a) {
        function b(d) {
            try {
                return decodeURIComponent(d), !0
            } catch (e) {
                return !1
            }
        }
        a = a ? a.title : "";
        if (a == void 0 || a == "") return "";
        a = encodeURIComponent(a);
        for (var c = 256; !b(a.substr(0, c));) c--;
        return "&tiba=" + a.substr(0, c)
    }

    function ze(a, b, c, d, e) {
        var f = "https://",
            g = d.google_conversion_type === "landing" ? "/extclk" : "/";
        switch (e) {
            default: return "";
            case 2:
                    case 3:
                    var h = "googleads.g.doubleclick.net/";
                var k = "pagead/viewthroughconversion/";
                break;
            case 1:
                    h = "www.google.com/";k = "pagead/1p-conversion/";
                break;
            case 6:
                    h = "www.google.com/";k = "ccm/conversion/";
                break;
            case 0:
                    h = d.google_conversion_domain || "www.googleadservices.com/";k = "pagead/conversion/";
                break;
            case 5:
                    h = d.google_conversion_domain || "www.googleadservices.com/";k = "ccm/conversion/";
                break;
            case 4:
                    h = (h = d.google_gtm_experiments) && h.apcm ? "www.google.com" : h && h.capiorig ? d.google_conversion_id + ".privacysandbox.googleadservices.com" : "www.google.com/";k = "pagead/privacysandbox/conversion/";
                break;
            case 7:
                    h = "googleads.g.doubleclick.net/",
                k = "td/rul/"
        }
        Hb && d.google_transport_url && (h = d.google_transport_url);
        h[h.length - 1] !== "/" && (h += "/");
        if (h.indexOf("http://") === 0 || h.indexOf("https://") === 0) f = "";
        f = [f, h, k, W(d.google_conversion_id), g, "?random=", W(d.google_conversion_time)].join("");
        g = X("cv", d.google_conversion_js_version);
        h = X("fst", d.google_conversion_first_time);
        k = X("num", d.google_conversion_snippets);
        var l = X("fmt", d.google_conversion_format),
            m = d.google_remarketing_only ? X("userId", d.google_user_id) : "";
        var p = d.google_tag_for_child_directed_treatment;
        p = p == null || p !== 0 && p !== 1 ? "" : X("tfcd", p);
        var t = d.google_tag_for_under_age_of_consent;
        t = t == null || t !== 0 && t !== 1 ? "" : X("tfua", t);
        var u = d.google_allow_ad_personalization_signals;
        u = u === !1 ? X("npa", 1) : u === !0 ? X("npa", 0) : "";
        var v = d.google_restricted_data_processing;
        v = Jb ? v === !0 ? X("rdp",
            1) : v === !1 ? X("rdp", 0) : "" : "";
        var Y = X("value", d.google_conversion_value),
            P = X("currency_code", d.google_conversion_currency),
            Pa = X("label", d.google_conversion_label),
            Qa = X("oid", d.google_conversion_order_id),
            z = X("bg", d.google_conversion_color);
        a: {
            var D = d.google_conversion_language;
            if (D != null) {
                D = D.toString();
                if (2 == D.length) {
                    D = X("hl", D);
                    break a
                }
                if (5 == D.length) {
                    D = X("hl", D.substring(0, 2)) + X("gl", D.substring(3, 5));
                    break a
                }
            }
            D = ""
        }
        var Oa = X("guid", "ON"),
            Me = !d.google_conversion_domain && "GooglemKTybQhCsO" in B && typeof B.GooglemKTybQhCsO ==
            "function" ? X("resp", "GooglemKTybQhCsO") : "",
            Ne = X("disvt", d.google_disable_viewthrough),
            Oe = X("eid", Pb().join());
        var ta = d.google_conversion_date;
        var F = [];
        if (a) {
            var S = a.screen;
            S && (F.push(X("u_h", S.height)), F.push(X("u_w", S.width)), F.push(X("u_ah", S.availHeight)), F.push(X("u_aw", S.availWidth)), F.push(X("u_cd", S.colorDepth)));
            a.history && F.push(X("u_his", a.history.length))
        }
        ta && typeof ta.getTimezoneOffset == "function" && F.push(X("u_tz", -ta.getTimezoneOffset()));
        b && (typeof b.javaEnabled == "function" && F.push(X("u_java",
            b.javaEnabled())), b.plugins && F.push(X("u_nplug", b.plugins.length)), b.mimeTypes && F.push(X("u_nmime", b.mimeTypes.length)));
        ta = F.join("");
        b = b && b.sendBeacon ? X("sendb", "1") : "";
        F = Ae();
        S = X("ig", /googleadservices\.com/.test("www.googleadservices.com") ? 1 : 0);
        var aa = ue(d.google_custom_params);
        var Sa = ue();
        aa = aa.concat(aa.length > 0 && Sa.length > 0 ? ";" : "", Sa);
        aa = aa == "" ? "" : "&".concat("data=", encodeURIComponent(aa));
        Sa = we(c, d);
        var ua = d.google_conversion_page_url,
            Qe = d.google_conversion_referrer_url,
            va = "";
        if (c) {
            var ia = a.top ==
                a ? 0 : (ia = a.location.ancestorOrigins) ? ia[ia.length - 1] == a.location.origin ? 1 : 2 : sb(a.top) ? 1 : 2;
            ua = ua ? ua : ia == 1 ? a.top.location.href : a.location.href;
            var Tc = "";
            J && I(["509562772", "509562773"], Eb, 21);
            if (J && (K(21) == "509562773" || K(21) == "509562772")) {
                for (var E, w = a, ja = w; w && w != w.parent;) w = w.parent, sb(w) && (ja = w);
                E = ja;
                w = E.location.href;
                if (E === E.top) w = {
                    url: w,
                    U: !0
                };
                else {
                    ja = !1;
                    var wb = E.document;
                    wb && wb.referrer && (w = wb.referrer, E.parent === E.top && (ja = !0));
                    (E = E.location.ancestorOrigins) && (E = E[E.length - 1]) && w.indexOf(E) ===
                        -1 && (ja = !1, w = E);
                    w = {
                        url: w,
                        U: ja
                    }
                }
                w.url && ua !== w.url && (Tc = w.url)
            }
            va += X("frm", ia);
            va += X("url", se(ua));
            va += X("ref", se(Qe || c.referrer));
            va += X("top", se(Tc))
        }
        a = [g, h, k, l, m, p, t, u, v, Y, P, Pa, Qa, z, D, Oa, Me, Ne, Oe, ta, b, F, S, aa, Sa, va, ye(c), Be(d.google_additional_params), Be(d.google_remarketing_only ? {} : d.google_additional_conversion_params), "&hn=" + W("www.googleadservices.com"), Ce(a), De(a)].join("");
        c = Ob();
        a += c.length > 0 ? "&debug_experiment_id=" + c : "";
        if (!d.google_remarketing_only && !d.google_conversion_domain) {
            c = [X("mid", d.google_conversion_merchant_id),
                X("fcntr", d.google_basket_feed_country), X("flng", d.google_basket_feed_language), X("dscnt", d.google_basket_discount), X("bttype", d.google_basket_transaction_type)
            ].join("");
            if (d)
                if (g = d.google_conversion_items) {
                    h = [];
                    k = 0;
                    for (l = g.length; k < l; k++) m = g[k], p = [], m && (p.push(ve(m.value)), p.push(ve(m.quantity)), p.push(ve(m.item_id)), p.push(ve(m.start_date)), p.push(ve(m.end_date)), h.push("(" + p.join("*") + ")"));
                    g = h.length > 0 ? "&item=" + h.join("") : ""
                } else g = "";
            else g = "";
            c = [a, c, g].join("");
            a = c.length > 4E3 ? [a, X("item", "elngth")].join("") :
                c
        }
        f += a;
        e === 1 || e === 6 ? f += [X("gcp", 1), X("sscte", 1), X("ct_cookie_present", 1)].join("") : e == 3 && (f += X("gcp", 1), f += X("ct_cookie_present", 1));
        Ib && (e = ie(), e !== void 0 && (f += X("us_privacy", e || "error")));
        xe(d) && (f = d.I ? f + X("gbcov", 1) : f + X("gbcov", 0));
        return f
    }

    function Ee(a, b, c, d, e, f, g) {
        return '<iframe name="' + a + '"' + (g ? ' id="' + g + '"' : "") + ' title="' + b + '" width="' + d + '" height="' + e + '"' + (c ? ' src="' + c + '"' : "") + ' frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true"' + (f ? ' style="display:none"' : "") + ' scrolling="no"></iframe>'
    }

    function Fe(a) {
        return {
            ar: 1,
            bg: 1,
            cs: 1,
            da: 1,
            de: 1,
            el: 1,
            en_AU: 1,
            en_US: 1,
            en_GB: 1,
            es: 1,
            et: 1,
            fi: 1,
            fr: 1,
            hi: 1,
            hr: 1,
            hu: 1,
            id: 1,
            is: 1,
            it: 1,
            iw: 1,
            ja: 1,
            ko: 1,
            lt: 1,
            nl: 1,
            no: 1,
            pl: 1,
            pt_BR: 1,
            pt_PT: 1,
            ro: 1,
            ru: 1,
            sk: 1,
            sl: 1,
            sr: 1,
            sv: 1,
            th: 1,
            tl: 1,
            tr: 1,
            vi: 1,
            zh_CN: 1,
            zh_TW: 1
        }[a] ? a + ".html": "en_US.html"
    }

    function Ge(a, b, c, d) {
        function e(h, k, l, m, p) {
            m = m ? ' style="display:none"' : "";
            return "<img " + (p && Tb() ? "attributionsrc " : "") + 'height="' + l + '" width="' + k + '" border="0" alt="" src="' + h + '"' + m + " />"
        }
        Sb() && Zb(2);
        var f = "";
        d.google_remarketing_only && d.google_enable_display_cookie_match && !bc && (J && I(["376635470", "376635471"], Bb, 2), f = d.google_remarketing_only && d.google_enable_display_cookie_match && !bc && J && K(2) == "376635471" ? Ee("google_cookie_match_frame", "Google cookie match frame", "https://bid.g.doubleclick.net/xbbe/pixel?d=KAE",
            1, 1, !0, null) : "");
        d.google_remarketing_only && !d.google_conversion_domain && J && I(["759238990", "759238991"], Gb, 13);
        !d.google_remarketing_only || d.google_conversion_domain || J && (K(14) == "759248991" || K(14) == "759248990") || J && I(["759248990", "759248991"], Fb, 14);
        d.google_conversion_linker !== !1 && ge(d.google_gcl_cookie_prefix);
        b = ze(a, b, c, d, d.google_remarketing_only ? 2 : 0);
        if (d.google_conversion_format == 0 && d.google_conversion_domain == null) return '<a href="https://services.google.com/sitestats/' + (Fe(d.google_conversion_language) +
            "?cid=" + W(d.google_conversion_id)) + '" target="_blank">' + e(b, 135, 27, !1, !1) + "</a>" + f;
        if (d.google_conversion_snippets !== void 0 && d.google_conversion_snippets > 1 || d.google_conversion_format == 3) {
            var g = b;
            d.google_conversion_domain == null && (g = d.google_conversion_format == 3 ? b : hb(b, "fmt", 3));
            b = void 0;
            Tb() && !d.google_remarketing_only && (b = {
                attributionsrc: ""
            });
            return He(a, c, d, g, b) ? f : e(g, 1, 1, !0, !d.google_remarketing_only) + f
        }
        g = null;
        !d.google_conversion_domain && He(a, c, d, b) && (g = "goog_conv_iframe", b = "");
        return Ee("google_conversion_frame",
            "Google conversion frame", b, d.google_conversion_format == 2 ? 200 : 300, d.google_conversion_format == 2 ? 26 : 13, !1, g) + f
    }

    function He(a, b, c, d, e) {
        if (c.google_conversion_domain) return !1;
        try {
            return Cc(a, b, d, null, void 0, e)
        } catch (f) {
            return !1
        }
    }

    function Ie(a) {
        if (a.google_conversion_type === "landing" || !a.google_conversion_id || a.google_remarketing_only && a.google_disable_viewthrough) return !1;
        a.google_conversion_date = new Date;
        a.google_conversion_time = a.google_conversion_date.getTime();
        a.google_conversion_snippets = typeof a.google_conversion_snippets === "number" && a.google_conversion_snippets > 0 ? a.google_conversion_snippets + 1 : 1;
        a.google_conversion_first_time === void 0 && (a.google_conversion_first_time = a.google_conversion_time);
        a.google_conversion_js_version =
            "9";
        a.google_conversion_format != 0 && a.google_conversion_format != 1 && a.google_conversion_format != 2 && a.google_conversion_format != 3 && (a.google_conversion_format = 3);
        a.google_enable_display_cookie_match !== !1 && (a.google_enable_display_cookie_match = !0);
        return !0
    }

    function Je(a) {
        for (var b = 0; b < qe.length; b++) a[qe[b]] = null
    }

    function Ke(a) {
        for (var b = {}, c = 0; c < qe.length; c++) b[qe[c]] = a[qe[c]];
        for (c = 0; c < re.length; c++) b[re[c]] = a[re[c]];
        return b
    }

    function Ae() {
        var a = "";
        Sb() && (a = ac().map(function(b) {
            return b.join("-")
        }).join("_"));
        return X("li", a)
    }

    function Ce(a) {
        if (!Kb || !a.__gsaExp || !a.__gsaExp.id) return "";
        a = a.__gsaExp.id;
        if (!fc(a)) return "";
        try {
            var b = Number(a());
            return isNaN(b) ? "" : X("gsaexp", b)
        } catch (c) {
            return ""
        }
    }

    function De(a) {
        function b(d, e) {
            e != null && c.push(d + "=" + encodeURIComponent(e))
        }
        if (!Rb()) return "";
        a = le(a);
        if (!a) return "";
        var c = [];
        b("&uaa", a.architecture);
        b("&uab", a.bitness);
        b("&uam", a.model);
        b("&uap", a.platform);
        b("&uapv", a.platformVersion);
        a.wow64 != null && b("&uaw", a.wow64 ? "1" : "0");
        a.fullVersionList && b("&uafvl", a.fullVersionList.map(function(d) {
            return encodeURIComponent(d.brand || "") + ";" + encodeURIComponent(d.version || "")
        }).join("|"));
        return c.join("")
    }

    function Be(a) {
        if (!a) return "";
        var b = "",
            c;
        for (c in a) a.hasOwnProperty(c) && (b += X(c, a[c]));
        return b
    }

    function xe(a) {
        return (a = a.google_gtm_experiments) && a.gbcov ? !0 : !1
    }

    function Le(a, b) {
        var c;
        if (c = !b.google_remarketing_only)
            if (b.google_transport_url || !J || K(19) != "375603261" && K(19) != "375603260") c = !1;
            else {
                b: {
                    if (!pe) {
                        zb("AzMBwcG8UIaKM1GV43UaxMDFsS7hsiLx0FXw9ULTOHJRGxkUVw+UPCxlzz5CudOm+WnidygXLcAHmad6rC6C9QEAAACUeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZWFkc2VydmljZXMuY29tOjQ0MyIsImZlYXR1cmUiOiJBdHRyaWJ1dGlvblJlcG9ydGluZ0Nyb3NzQXBwV2ViIiwiZXhwaXJ5IjoxNzE0NTIxNTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ\x3d\x3d", a);
                        if (!wc() && !zb(r("www.googleadservices.com", "endsWith").call("www.googleadservices.com", "google.com") ? "" : "A2kc5o2ErHAbqJvF2MHSdYtnc2Bp3n6Jn2kNeko6SgHH6zXBHn0+4BbAW2No9ylVJMkzJAPwMqCVHqXm+IF1DgQAAACKeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZWFkc2VydmljZXMuY29tOjQ0MyIsImZlYXR1cmUiOiJQcml2YWN5U2FuZGJveEFkc0FQSXMiLCJleHBpcnkiOjE2OTUxNjc5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9", a)) {
                            a = !1;
                            break b
                        }
                        pe = !0
                    }
                    a = wc()
                }
                c = a
            }
        c && (a = b.google_additional_conversion_params || {}, c = b.google_gtm_experiments, a.capi = c && c.apcm ? "2" : "1", b.google_additional_conversion_params =
            a)
    };
    var Pe = ma(["https://www.googletagmanager.com/debug/bootstrap"]),
        Re = !1,
        Se = document.currentScript && document.currentScript.src || "";

    function Te(a, b, c) {
        try {
            if (!Re && (Re = !0, !c.google_gtm)) {
                var d = void 0,
                    e = void 0,
                    f = fb(a.location.href, "gtm_debug");
                Ue(f) && (d = 2);
                d || b.referrer.indexOf("https://tagassistant.google.com/") !== 0 || (d = 3);
                !d && xa(b.cookie.split("; "), "__TAG_ASSISTANT=x") >= 0 && (d = 4);
                d || (e = b.documentElement.getAttribute("data-tag-assistant-present"), Ue(e) && (d = 5));
                if (d) {
                    var g = "AW-" + (c.google_conversion_id || "");
                    if (!a["google.tagmanager.debugui2.queue"]) {
                        a["google.tagmanager.debugui2.queue"] = [];
                        var h = qb(Pe),
                            k = new q.Map([
                                ["id", g],
                                ["src",
                                    "LEGACY"
                                ],
                                ["cond", d]
                            ]),
                            l = Va(h).toString(),
                            m = l.split(/[?#]/),
                            p = /[?]/.test(l) ? "?" + m[1] : "";
                        var t = rb(m[0], p, /[#]/.test(l) ? "#" + (p ? m[2] : m[1]) : "", k);
                        var u = Ab("SCRIPT", b);
                        $a(u, t);
                        var v = b.getElementsByTagName("script")[0];
                        v && v.parentNode && v.parentNode.insertBefore(u, v)
                    }
                    a["google.tagmanager.debugui2.queue"].push({
                        messageType: "LEGACY_CONTAINER_STARTING",
                        data: {
                            id: g,
                            scriptSource: Se
                        }
                    })
                }
            }
        } catch (Y) {}
    }

    function Ue(a) {
        if (a == null || a.length === 0) return !1;
        a = Number(a);
        var b = Date.now();
        return a < b + 3E5 && a > b - 9E5
    };

    function Ve(a) {
        return a.prerendering ? 3 : {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] || 0
    }

    function We(a) {
        var b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    }

    function Xe(a, b) {
        if (Ve(b) == 3) return !1;
        a();
        return !0
    }

    function Ye(a, b) {
        var c = c === void 0 ? !1 : c;
        if (!Xe(a, b))
            if (c) {
                var d = function() {
                    b.removeEventListener && b.removeEventListener("prerenderingchange", d, !1);
                    a()
                };
                b.addEventListener && b.addEventListener("prerenderingchange", d, !1)
            } else {
                var e = !1,
                    f = We(b),
                    g = function() {
                        !e && Xe(a, b) && (e = !0, b.removeEventListener && b.removeEventListener(f, g, !1))
                    };
                f && b.addEventListener && b.addEventListener(f, g, !1)
            }
    };

    function Ze(a) {
        var b = r(Object, "assign").call(Object, {}, a);
        a = a.id;
        b = (delete b.id, b);
        if (r(Object, "keys").call(Object, b).length) throw Error("Invalid attribute(s): " + r(Object, "keys").call(Object, b));
        return ob({
            id: a
        })
    };
    J = new function() {
        var a = [];
        var b = 0,
            c;
        for (c in Qb) a[b++] = Qb[c];
        a = a === void 0 ? [] : a;
        this.M = {};
        this.g = {};
        for (b = 0; b < a.length; ++b) this.g[a[b]] = ""
    };
    I(["466465925", "466465926"], Db, 20);
    Rb() && ne();
    J && I(["592230570", "592230571"], Cb, 16);
    Sb() && (Zb(1), $b());

    function $e(a, b, c, d) {
        function e(m, p, t) {
            t = t === void 0 ? function() {} : t;
            var u = new Image;
            u.onload = m;
            u.onerror = t;
            u.src = p
        }

        function f() {
            --g;
            if (g <= 0) {
                var m = yc(a, !1),
                    p = m[b];
                p && (delete m[b], (m = p[0]) && m.call && m())
            }
        }
        d = d === void 0 ? [] : d;
        var g = c.length + 1;
        if (c.length === 2) {
            var h = c[0],
                k = c[1];
            db(h, 0, "rmt_tld", h.search(eb)) >= 0 && db(h, 0, "ipr", h.search(eb)) >= 0 && !k.match(bb)[6] && (k += cb(h), c[1] = hb(k, "rmt_tld", "1"))
        }
        for (h = {
                v: 0
            }; h.v < c.length; h = {
                v: h.v
            }, h.v++) {
            k = c[h.v];
            var l = fb(k, "fmt");
            switch (Number(l)) {
                case 1:
                case 2:
                    (l = a.document.getElementById("goog_conv_iframe")) &&
                    !l.src ? qc(k, f, l) : e(f, k);
                    break;
                case 4:
                    Cc(a, a.document, k, f);
                    break;
                case 5:
                    if (a.navigator && a.navigator.sendBeacon)
                        if (a.navigator.sendBeacon(k, "")) {
                            f();
                            break
                        } else k = hb(k, "sendb", 2);
                    k = hb(k, "fmt", 3);
                    e(f, k);
                    break;
                default:
                    l = void 0, d && d[h.v] && (l = function(m) {
                        return function() {
                            uc(d[m.v]) && f()
                        }
                    }(h)), e(f, k, l)
            }
        }
        f()
    }
    var af = ["GooglemKTybQhCsO"],
        Z = B;
    af[0] in Z || typeof Z.execScript == "undefined" || Z.execScript("var " + af[0]);
    for (var bf; af.length && (bf = af.shift());) af.length || $e === void 0 ? Z[bf] && Z[bf] !== Object.prototype[bf] ? Z = Z[bf] : Z = Z[bf] = {} : Z[bf] = $e;
    (function(a, b, c) {
        if (a) {
            Te(a, c, a);
            try {
                if (Ie(a)) {
                    var d = Ke(a);
                    J && I(["375603260", "375603261"], Lb ? 1 : 0, 19);
                    J && I(["512247838", "512247839"], Mb ? 1 : 0, 22);
                    if (Ve(c) == 3) {
                        var e = "google_conversion_" + Math.floor(Math.random() * 1E9);
                        ab(c, Ze({
                            id: e
                        }));
                        Ye(function() {
                            try {
                                Le(c, d);
                                var f = c.getElementById(e);
                                if (f) {
                                    var g = jc(Ge(a, b, c, d));
                                    if (f.nodeType === 1 && /^(script|style)$/i.test(f.tagName)) throw Error("");
                                    f.innerHTML = Za(g)
                                }
                            } catch (h) {}
                        }, c)
                    } else Le(c, d), ab(c, jc(Ge(a, b, c, d)))
                }
            } catch (f) {}
            Je(a)
        }
    })(window, navigator, document);
}).call(this);